namespace LeadPilot.Application.Capacity;

public interface IDailyCapacityOrchestrator
{
    Task<CapacityOrchestrationResult> RunCycleAsync(Guid planId, CancellationToken ct);
}

public sealed record CapacityOrchestrationResult(
    Guid PlanId, int JobsCreated, int JobsSkippedAsDuplicate,
    int QuotasCompleted, int QuotasBehindSchedule, bool IsPlanCompleted);

public sealed record CapacitySearchJobPayload(
    Guid PlanId, Guid QuotaId, string GroupCode, Guid? ProjectId, string LogicalSlot);
