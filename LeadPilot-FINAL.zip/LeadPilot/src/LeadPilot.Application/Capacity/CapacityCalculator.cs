namespace LeadPilot.Application.Capacity;

/// <summary>
/// محاسبهٔ تعداد موردنیاز با نرخ‌های واقعی (نه فرضِ ۵۰٪): از رضایت هدف به عقب
/// تا سیگنالِ لازم، با جبرانِ تکراری‌ها و حاشیهٔ اطمینان.
/// </summary>
public sealed class CapacityCalculator
{
    public CapacityCalculationResult Calculate(
        int targetConsents, decimal observedConsentRate, decimal observedContactDiscoveryRate,
        decimal duplicateRate, decimal safetyMargin)
    {
        ValidateRate(observedConsentRate, nameof(observedConsentRate));
        ValidateRate(observedContactDiscoveryRate, nameof(observedContactDiscoveryRate));
        if (duplicateRate is < 0 or >= 1) throw new ArgumentOutOfRangeException(nameof(duplicateRate));
        if (safetyMargin is < 0 or > 1) throw new ArgumentOutOfRangeException(nameof(safetyMargin));

        int validContactsRequired = (int)Math.Ceiling(targetConsents / observedConsentRate);
        int contactsIncludingDuplicates = (int)Math.Ceiling(validContactsRequired / (1 - duplicateRate));
        int signalsRequired = (int)Math.Ceiling(contactsIncludingDuplicates / observedContactDiscoveryRate);
        int signalsWithSafetyMargin = (int)Math.Ceiling(signalsRequired * (1 + safetyMargin));

        return new CapacityCalculationResult(
            targetConsents, validContactsRequired, contactsIncludingDuplicates, signalsWithSafetyMargin);
    }

    private static void ValidateRate(decimal rate, string parameterName)
    {
        if (rate is <= 0 or > 1) throw new ArgumentOutOfRangeException(parameterName);
    }
}

public sealed record CapacityCalculationResult(
    int TargetConsents, int ValidContactsRequired, int ContactsIncludingDuplicateAllowance, int SignalsRequired);
