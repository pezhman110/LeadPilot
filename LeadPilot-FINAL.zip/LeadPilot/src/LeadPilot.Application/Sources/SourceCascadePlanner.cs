using LeadPilot.Domain.Sources;

namespace LeadPilot.Application.Sources;

/// <summary>
/// برنامه‌ریزِ آبشارِ منبع: ترتیبِ اجرا برای یک پروژه.
/// اصولِ سند: اول دادهٔ آماده/رایگان (رتبهٔ سرعت پایین‌تر = زودتر)، بعد پولی/گران؛
/// منابعِ فقط-شرکتی برای پروژهٔ شخصی حذف می‌شوند؛ نقشِ منبع (Phone/Signal) لحاظ می‌شود.
/// </summary>
public sealed class SourceCascadePlanner
{
    private readonly IReadOnlyList<SourceDefinition> _all;
    public SourceCascadePlanner(IReadOnlyList<SourceDefinition> all) => _all = all;

    /// <summary>
    /// آبشارِ کلی برای یک پروژه.
    /// projectIsPersonal=true → Google Maps/About/دایرکتوری/Provider شرکتی حذف می‌شوند.
    /// </summary>
    public IReadOnlyList<SourceDefinition> PlanFor(bool projectIsPersonal)
    {
        return _all
            .Where(s => s.IsEnabled)
            .Where(s => s.IsAllowedFor(projectIsPersonal))
            // اول سریع‌ترین/ارزان‌ترین (رتبهٔ ۱ = دادهٔ خودِ مجموعه)، بعد رتبه‌های بالاتر.
            .OrderBy(s => s.SpeedRank)
            // در هر رتبه: منابعِ بدونِ قرارداد (رایگان) قبل از قراردادی (پولی).
            .ThenBy(s => s.RequiresContract)
            // PhoneSource قبل از SignalSource (شماره مستقیم زودتر).
            .ThenBy(s => s.Role == SourceRole.SignalSource ? 1 : 0)
            .ToList();
    }

    /// <summary>
    /// ترتیبِ اختصاصیِ پروژه‌های تعریف‌شده در سند (بخش ۵).
    /// اگر پروژه در جدول نبود، به آبشارِ عمومی برمی‌گردد.
    /// </summary>
    public IReadOnlyList<SourceDefinition> PlanForProjectKind(ProjectSourceKind kind)
    {
        var order = kind switch
        {
            ProjectSourceKind.InvestmentBuySell => new[]
            {
                "crm", "referral_partner", "linkedin_lead_gen", "apollo", "business_marketplaces",
                "company_registry", "google_places", "funding_news", "investment_forums", "ai_search"
            },
            ProjectSourceKind.SalonHomeService => new[]
            {
                "crm", "booking_system", "instagram_lead_ads", "tiktok_instant_forms", "snapchat_lead_gen",
                "click_to_whatsapp", "google_lead_forms", "influencer_code", "landing_pages", "whatsapp_business"
            },
            ProjectSourceKind.FactorySupplierAgency => new[]
            {
                "business_directories", "google_places", "company_registry", "linkedin_lead_gen", "apollo",
                "exhibitor_lists", "chambers_commerce", "business_marketplaces", "news_api", "referral_partner"
            },
            ProjectSourceKind.FreelancerInfluencer => new[]
            {
                "web_forms", "meta_lead_ads", "influencer_marketplaces", "influencer_code",
                "instagram_lead_ads", "event_signup", "landing_pages"
            },
            _ => Array.Empty<string>()
        };

        bool personal = kind is ProjectSourceKind.SalonHomeService;
        var byCode = _all.ToDictionary(s => s.Code);
        var ordered = order
            .Where(byCode.ContainsKey)
            .Select(c => byCode[c])
            .Where(s => s.IsEnabled && s.IsAllowedFor(personal))
            .ToList();

        return ordered.Count > 0 ? ordered : PlanFor(personal);
    }
}

public enum ProjectSourceKind
{
    InvestmentBuySell = 0,
    SalonHomeService = 1,
    FactorySupplierAgency = 2,
    FreelancerInfluencer = 3
}
