using LeadPilot.Domain.Sources;

namespace LeadPilot.Application.Sources;

/// <summary>
/// کاتالوگِ اولیهٔ منابع (seed) مطابق ۱۴ گروهِ سند. رجیستری در زمان اجرا توسعه می‌یابد.
/// (Code, DisplayName, Group, Role, SpeedRank 1..6, CorporateOnly, RequiresContract)
/// </summary>
public static class SourceCatalog
{
    public static IReadOnlyList<SourceDefinition> Seed() =>
    [
        // گروه A — دادهٔ خودِ مجموعه (رتبهٔ ۱، سریع‌ترین، PhoneSource)
        new("crm", "CRM قبلی", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("web_forms", "فرم‌های وب‌سایت", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("booking_system", "سیستم رزرو", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("pos", "POS و فروش", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("online_store", "فروشگاه آنلاین", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("whatsapp_inbound", "WhatsApp ورودی", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("referral_partner", "Referral همکاران/شرکا", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),
        new("influencer_code", "کد اینفلوئنسر", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 1, false, false),

        // گروه B — فرم‌های رسمیِ پلتفرم (رتبهٔ ۴، خوداظهاری، PhoneSource)
        new("meta_lead_ads", "Meta Lead Ads", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("instagram_lead_ads", "Instagram Lead Ads", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("linkedin_lead_gen", "LinkedIn Lead Gen Forms", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("tiktok_instant_forms", "TikTok Instant Forms", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("snapchat_lead_gen", "Snapchat Lead Generation", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("google_lead_forms", "Google Ads Lead Forms", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("click_to_whatsapp", "Click-to-WhatsApp", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, true),
        new("landing_pages", "صفحات فرود", SourceGroup.B_PlatformLeadForms, SourceRole.PhoneSource, 4, false, false),

        // گروه C — پیام‌رسان‌ها (کانالِ opt-in)
        new("whatsapp_business", "WhatsApp Business", SourceGroup.C_Messaging, SourceRole.OptInChannel, 4, false, true),
        new("telegram_bot", "Telegram Bot", SourceGroup.C_Messaging, SourceRole.OptInChannel, 4, false, false),
        new("web_chat", "چت سایت", SourceGroup.C_Messaging, SourceRole.OptInChannel, 4, false, false),
        new("sms_gateway", "SMS Gateway", SourceGroup.C_Messaging, SourceRole.OptInChannel, 4, false, true),
        new("email_gateway", "Email Gateway", SourceGroup.C_Messaging, SourceRole.OptInChannel, 4, false, true),

        // گروه D — موتورهای جست‌وجو و وب عمومی (رتبهٔ ۵)
        new("google_search_api", "Google Search API", SourceGroup.D_SearchWeb, SourceRole.SignalSource, 5, false, true),
        new("bing_search", "Bing Web Search", SourceGroup.D_SearchWeb, SourceRole.SignalSource, 5, false, true),
        new("brave_search", "Brave Search API", SourceGroup.D_SearchWeb, SourceRole.SignalSource, 5, false, true),
        new("rss_feeds", "RSS و Sitemap", SourceGroup.D_SearchWeb, SourceRole.SignalSource, 5, false, false),

        // گروه E — نقشه‌ها/دایرکتوری (فقط شرکتی، رتبهٔ ۳)
        new("google_places", "Google Places", SourceGroup.E_MapsDirectories, SourceRole.PhoneSource, 3, true, true),
        new("bing_maps", "Bing Maps", SourceGroup.E_MapsDirectories, SourceRole.PhoneSource, 3, true, true),
        new("business_directories", "دایرکتوری تجاری", SourceGroup.E_MapsDirectories, SourceRole.PhoneSource, 3, true, false),
        new("yellow_pages", "Yellow Pages قراردادی", SourceGroup.E_MapsDirectories, SourceRole.PhoneSource, 3, true, true),

        // گروه F — شبکه‌های اجتماعی (SignalSource، رتبهٔ ۶)
        new("linkedin_public", "LinkedIn (عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("instagram_public", "Instagram (عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("tiktok_public", "TikTok (عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("snapchat_public", "Snapchat (عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("youtube_public", "YouTube (کامنت عمومی/API)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("facebook_public", "Facebook (گروه عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),
        new("x_public", "X/Twitter (عمومی)", SourceGroup.F_SocialPublic, SourceRole.SignalSource, 6, false, false),

        // گروه G — کامنت/انجمن/تالار (SignalSource، رتبهٔ ۶)
        new("reddit_api", "Reddit API", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),
        new("stackexchange_api", "Stack Exchange API", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),
        new("investment_forums", "انجمن‌های سرمایه‌گذاری", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),
        new("franchise_forums", "انجمن‌های فرانچایز", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),
        new("beauty_forums", "انجمن‌های زیبایی", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),
        new("expat_forums", "انجمن‌های مهاجران", SourceGroup.G_CommentsForums, SourceRole.SignalSource, 6, false, false),

        // گروه H — خبر/رسانه/رویداد (رتبهٔ ۵)
        new("news_api", "News API قراردادی", SourceGroup.H_NewsMedia, SourceRole.SignalSource, 5, false, true),
        new("funding_news", "اخبار جذب سرمایه", SourceGroup.H_NewsMedia, SourceRole.SignalSource, 5, false, false),
        new("ma_news", "اخبار ادغام و خرید", SourceGroup.H_NewsMedia, SourceRole.SignalSource, 5, false, false),
        new("event_calendar", "تقویم رویدادها/نمایشگاه", SourceGroup.H_NewsMedia, SourceRole.SignalSource, 5, false, false),

        // گروه I — ثبت شرکت و منابع رسمی B2B (فقط شرکتی)
        new("company_registry", "مراجع ثبت شرکت", SourceGroup.I_CompanyRegistries, SourceRole.PhoneSource, 3, true, false),
        new("free_zones", "مناطق آزاد", SourceGroup.I_CompanyRegistries, SourceRole.PhoneSource, 3, true, false),
        new("chambers_commerce", "اتاق‌های بازرگانی", SourceGroup.I_CompanyRegistries, SourceRole.PhoneSource, 3, true, false),
        new("exhibitor_lists", "فهرست غرفه‌داران", SourceGroup.I_CompanyRegistries, SourceRole.PhoneSource, 3, true, false),

        // گروه J — Providerهای قراردادی (رتبهٔ ۲، B2B)
        new("apollo", "Apollo", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),
        new("zoominfo", "ZoomInfo", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),
        new("cognism", "Cognism", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),
        new("lusha", "Lusha", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),
        new("hunter", "Hunter (ایمیل دامنه)", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),
        new("snov", "Snov.io", SourceGroup.J_ContractProviders, SourceRole.PhoneSource, 2, true, true),

        // گروه K — مارکت‌پلیس‌ها (با API/Feed/قرارداد)
        new("business_marketplaces", "مارکت‌پلیس خریدوفروش کسب‌وکار", SourceGroup.K_Marketplaces, SourceRole.SignalSource, 5, false, true),
        new("franchise_marketplaces", "مارکت‌پلیس فرانچایز", SourceGroup.K_Marketplaces, SourceRole.SignalSource, 5, false, true),
        new("influencer_marketplaces", "مارکت‌پلیس اینفلوئنسر", SourceGroup.K_Marketplaces, SourceRole.SignalSource, 5, false, true),
        new("freelancer_marketplaces", "مارکت‌پلیس فریلنسر", SourceGroup.K_Marketplaces, SourceRole.SignalSource, 5, false, true),

        // گروه L — اپ‌استورها (کشف شرکت، نه شمارهٔ کاربر)
        new("app_store_meta", "App Store metadata", SourceGroup.L_AppStores, SourceRole.SignalSource, 5, true, false),
        new("play_store_meta", "Google Play metadata", SourceGroup.L_AppStores, SourceRole.SignalSource, 5, true, false),

        // گروه M — خروجی AI (نه منبع مستقیم تلفن)
        new("ai_search", "AI Search (Query/تحلیل)", SourceGroup.M_AiOutputs, SourceRole.SignalSource, 5, false, true),
        new("ai_intent", "Intent Classification/Translation", SourceGroup.M_AiOutputs, SourceRole.SignalSource, 5, false, false),

        // گروه N — آفلاین
        new("business_card", "کارت ویزیت", SourceGroup.N_Offline, SourceRole.PhoneSource, 1, false, false),
        new("event_signup", "ثبت‌نام رویداد حضوری", SourceGroup.N_Offline, SourceRole.PhoneSource, 1, false, false),
        new("branch_intake", "فرم پذیرش شعبه", SourceGroup.N_Offline, SourceRole.PhoneSource, 1, false, false),
        new("partner_clinic", "کلینیک شریک", SourceGroup.N_Offline, SourceRole.PhoneSource, 1, true, false)
    ];
}
