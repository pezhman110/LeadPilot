using LeadPilot.Domain.Targets;

namespace LeadPilot.Application.Targets;

public interface ITargetRepository
{
    Task AddTargetAsync(ProjectTarget t, CancellationToken ct);
    Task<IReadOnlyList<ProjectTarget>> ListTargetsAsync(Guid projectId, CancellationToken ct);
    Task<ProjectFunnelSettings?> GetFunnelAsync(Guid projectId, CancellationToken ct);
    Task AddFunnelAsync(ProjectFunnelSettings f, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed record CreateTargetRequest(Guid ProjectId, string Name, int MetricType, int PeriodType,
    decimal TargetValue, DateTimeOffset StartsAtUtc, DateTimeOffset? EndsAtUtc);
public sealed record TargetResponse(Guid Id, string Name, string MetricType, string PeriodType,
    decimal TargetValue, decimal ActualValue, decimal AchievementPercentage, decimal RemainingValue);
public sealed record PlanRequest(Guid ProjectId, decimal RevenueTargetAed);

public sealed class TargetService(ITargetRepository repo)
{
    private readonly ReverseFunnelCalculator _calc = new();

    public async Task<TargetResponse> CreateAsync(CreateTargetRequest r, CancellationToken ct)
    {
        var t = new ProjectTarget(r.ProjectId, r.Name, (TargetMetricType)r.MetricType,
            (TargetPeriodType)r.PeriodType, r.TargetValue, r.StartsAtUtc, r.EndsAtUtc);
        await repo.AddTargetAsync(t, ct);
        await repo.SaveChangesAsync(ct);
        return Map(t);
    }

    public async Task<IReadOnlyList<TargetResponse>> ListAsync(Guid projectId, CancellationToken ct) =>
        (await repo.ListTargetsAsync(projectId, ct)).Select(Map).ToList();

    /// <summary>محاسبهٔ معکوس قیف: از هدف مالی تا سیگنالِ لازم.</summary>
    public async Task<FunnelPlan> PlanAsync(PlanRequest r, CancellationToken ct)
    {
        var f = await repo.GetFunnelAsync(r.ProjectId, ct);
        if (f is null)
        {
            f = new ProjectFunnelSettings(r.ProjectId);
            await repo.AddFunnelAsync(f, ct);
            await repo.SaveChangesAsync(ct);
        }
        return _calc.Calculate(r.RevenueTargetAed, f);
    }

    private static TargetResponse Map(ProjectTarget t) => new(
        t.Id, t.Name, t.MetricType.ToString(), t.PeriodType.ToString(),
        t.TargetValue, t.ActualValue, t.AchievementPercentage, t.RemainingValue);
}
