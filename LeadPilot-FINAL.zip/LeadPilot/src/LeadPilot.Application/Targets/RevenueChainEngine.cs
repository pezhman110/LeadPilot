using LeadPilot.Domain.Targets;

namespace LeadPilot.Application.Targets;

/// <summary>
/// موتور هدف/ظرفیت/زنجیرهٔ درآمد.
/// محاسبهٔ معکوسِ قیف: از هدف مالی/تعدادی به عقب تا تعداد سیگنالِ لازم.
/// اعداد تضمین نیستند؛ می‌گویند «با نرخ‌های فعلی چه حجمی لازم است».
/// </summary>
public sealed class ReverseFunnelCalculator
{
    public FunnelPlan Calculate(decimal revenueTargetAed, ProjectFunnelSettings f)
    {
        if (revenueTargetAed <= 0) throw new ArgumentOutOfRangeException(nameof(revenueTargetAed));
        if (f.AverageDealValueAed <= 0) throw new ArgumentException("متوسط ارزش قرارداد باید > 0 باشد.");

        // قرارداد لازم = هدف درآمد ÷ متوسط ارزش قرارداد
        var deals = Ceil(revenueTargetAed / f.AverageDealValueAed);
        // لید واجد شرایط = قرارداد ÷ نرخ بستن
        var qualified = DivRate(deals, f.ProposalToCloseRate);
        // رضایت = لید واجد شرایط ÷ نرخ رضایت→واجد شرایط
        var consented = DivRate(qualified, f.ConsentToQualifiedRate);
        // اطلاعات تماس = رضایت ÷ نرخ تماس→رضایت
        var contacts = DivRate(consented, f.ContactToConsentRate);
        // سیگنال = اطلاعات تماس ÷ نرخ سیگنال→تماس
        var signals = DivRate(contacts, f.SignalToContactRate);

        return new FunnelPlan(
            RevenueTargetAed: revenueTargetAed,
            RequiredDeals: deals,
            RequiredQualifiedLeads: qualified,
            RequiredConsents: consented,
            RequiredContacts: contacts,
            RequiredSignals: signals,
            IsEstimated: f.IsEstimated);
    }

    private static int Ceil(decimal v) => (int)Math.Ceiling(v);
    private static int DivRate(int count, decimal rate) =>
        rate <= 0 ? 0 : (int)Math.Ceiling(count / rate);
}

public sealed record FunnelPlan(
    decimal RevenueTargetAed,
    int RequiredDeals,
    int RequiredQualifiedLeads,
    int RequiredConsents,
    int RequiredContacts,
    int RequiredSignals,
    bool IsEstimated);
