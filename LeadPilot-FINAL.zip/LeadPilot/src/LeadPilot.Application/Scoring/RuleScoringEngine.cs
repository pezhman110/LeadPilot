using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Common;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Application.Scoring;

/// <summary>
/// موتور امتیازدهیِ قابل‌توضیح — بر اساس «قانون طلایی سرچِ» فایل سرمایه‌گذاری:
///   Personal Investor Intent + Budget Capacity + Dubai/UAE Relevance
///   + Investment Behavior + Real Estate/Business Interest + Consent-Safe Source
/// کلمهٔ «investor» به‌تنهایی کافی نیست؛ باید ترکیبِ نیت + بودجه + بافت باشد.
/// سه امتیاز مجزا: Intent / Fit / Compliance، هر کدام با شواهد و «دلیل».
/// </summary>
public sealed class RuleScoringEngine : IScoringEngine
{
    // نوع مشتری شخصی (فایل: کلمات سرمایه‌گذاری — Target investor type)
    private static readonly string[] PersonalMarkers =
    [
        "individual investor","private investor","personal investor","personal buyer","cash buyer",
        "expat investor","resident investor","high-net-worth","hnwi","hnw","self-funded","self funded",
        "private capital","business buyer","passive income seeker","ready investor","ready capital",
        "سرمایه گذار شخصی","سرمایه گذار خصوصی","خریدار شخصی","سرمایه شخصی","لدي رأس مال","مستثمر فردي"
    ];
    // نیت سرمایه‌گذاری/خرید (Investment Behavior Context)
    private static readonly string[] StrongIntent =
    [
        "looking to invest","want to invest","ready to invest","buy business","business acquisition",
        "buy a business","buy stake","silent partner","passive income","monthly income","managed business",
        "franchise","golden visa","property investment","income generating",
        "دنبال سرمایه گذاری","میخواهم سرمایه گذاری","خرید بیزینس","خرید کسب و کار","خرید سهم","شراکت",
        "درآمد ماهانه","کسب و کار مدیریت شده","گلدن ویزا","اقامت","درآمد پسیو",
        "أبحث عن استثمار","أريد الاستثمار","شراء مشروع","شراكة","دخل شهري"
    ];
    // ظرفیت بودجه (Budget Capacity Signal) — از ۵۰۰k تا ۲M+
    private static readonly string[] BudgetMarkers =
    [
        "500,000","500k","750,000","1 million","1m aed","1,000,000","1.5 million","2 million",
        "aed 500","aed 750","aed 1","half a million","million dirham","minimum investment",
        "investment budget","ready capital","cash investment","private capital",
        "۵۰۰ هزار درهم","۷۵۰ هزار","یک میلیون درهم","نیم میلیون","دو میلیون","مليون درهم","رأس مال"
    ];
    // ارتباط با دبی/امارات (Dubai / UAE Relevance)
    private static readonly string[] GeoMarkers =
        ["dubai","uae","emirates","abu dhabi","دبی","امارات","دبي","الإمارات","أبوظبي"];
    // علاقه به ملک/کسب‌وکار (Real Estate / Business Ownership Interest)
    private static readonly string[] AssetMarkers =
        ["property","real estate","apartment","villa","salon","restaurant","home service","franchise",
         "ملک","املاک","آپارتمان","ویلا","سالن","رستوران","فرانچایز","عقار"];
    // خوشهٔ منفی (فایل: Do not target) — VC/بانک/بروکر/وام/فارکس/شغل
    private static readonly string[] NegativeMarkers =
    [
        "vc fund","venture capital","institutional","broker","brokerage","agency","loan","mortgage seeker",
        "job","hiring","career","forex","crypto","crowdfunding","we offer","our clients","llc","fze",
        "corporate","bank ","just curious","no budget","student","internship",
        "وام","استخدام","فارکس","کریپتو","دلال","بنگاه","کارمند استخدام"
    ];

    public NormalizedSignal Score(RawSignal raw, Project project, ComplianceDecision compliance)
    {
        var text = raw.OriginalText.ToLowerInvariant();
        var ev = new List<SignalEvidence>();
        var reasons = new List<string>();

        // ── Intent (نیت شخصی + رفتار سرمایه‌گذاری، منهای منفی‌ها) ──
        int intent = 0;
        bool personal = Has(text, PersonalMarkers, ev, "personal", out var pm);
        if (personal) { intent += 30; reasons.Add($"مشتری شخصی: «{pm}» (+30)"); }
        bool hasIntent = Has(text, StrongIntent, ev, "intent", out var si);
        if (hasIntent) { intent += 25; reasons.Add($"نیت سرمایه‌گذاری/خرید: «{si}» (+25)"); }
        bool hasBudget = Has(text, BudgetMarkers, ev, "budget", out var bm);
        if (hasBudget) { intent += 20; reasons.Add($"ظرفیت بودجه: «{bm}» (+20)"); }
        if (Has(text, NegativeMarkers, ev, "negative", out var nm)) { intent -= 35; reasons.Add($"خوشهٔ منفی: «{nm}» (−35)"); }

        // ── Fit (دبی/امارات + علاقه به ملک/کسب‌وکار + سازگاری بودجه) ──
        int fit = 0;
        bool geo = Has(text, GeoMarkers, ev, "geo", out var gm);
        if (geo) { fit += 40; reasons.Add($"مرتبط با دبی/امارات: «{gm}» (+40)"); }
        if (Has(text, AssetMarkers, ev, "asset", out var am)) { fit += 20; reasons.Add($"علاقه به ملک/کسب‌وکار: «{am}» (+20)"); }
        if (hasBudget) { fit += 20; reasons.Add("بودجه با هدف پروژه سازگار است (+20)"); }

        // ── قانون طلایی: کلمهٔ investor به‌تنهایی کافی نیست ──
        // اگر فقط geo بدون نیت شخصی/بودجه → امتیاز نیت پایین می‌ماند (نتیجهٔ ضعیف).
        if (geo && !personal && !hasIntent && !hasBudget)
            reasons.Add("فقط اشارهٔ عمومی به دبی؛ بدون نیت/بودجهٔ شخصی → ضعیف.");

        int comp = compliance.ComplianceScore;
        reasons.Add($"Compliance: {compliance.Reason} ({comp})");

        intent = Clamp(intent); fit = Clamp(fit); comp = Clamp(comp);
        int srcQ = SourceQuality(raw.SourceType);
        int rec = Recency(raw.CollectedAtUtc);
        int final = (int)Math.Round(intent * 0.45 + fit * 0.30 + srcQ * 0.15 + rec * 0.10);

        return new NormalizedSignal
        {
            RawSignalId = raw.Id, ProjectId = raw.ProjectId, SearchRunId = raw.SearchRunId,
            SourceUrl = raw.SourceUrl, SourceType = raw.SourceType, QueryUsed = raw.QueryUsed,
            OriginalText = raw.OriginalText.Trim(),
            TranslatedSummaryFa = Summarize(personal || hasIntent, hasBudget, geo),
            Language = raw.Language,
            ComplianceStatus = compliance.Status, ComplianceReason = compliance.Reason,
            IntentScore = intent, FitScore = fit, ComplianceScore = comp, FinalScore = final,
            Evidence = ev, ReasonForScore = reasons, IsDemo = raw.IsDemo
        };
    }

    private static string Summarize(bool intent, bool budget, bool geo)
    {
        var p = new List<string>();
        if (intent) p.Add("نیت خرید/سرمایه‌گذاری شخصی");
        if (budget) p.Add("ظرفیت بودجه");
        if (geo) p.Add("مرتبط با دبی/امارات");
        return p.Count == 0 ? "سیگنالِ عمومی؛ نیاز به بررسی." : "خلاصه: " + string.Join("، ", p) + ".";
    }
    private static bool Has(string text, string[] terms, List<SignalEvidence> ev, string kind, out string? matched)
    {
        foreach (var t in terms)
        {
            var term = t.ToLowerInvariant();
            if (text.Contains(term)) { ev.Add(new() { Kind = kind, Matched = t }); matched = t; return true; }
        }
        matched = null; return false;
    }
    private static int SourceQuality(SourceType s) => s switch
    {
        SourceType.LeadForm or SourceType.OptIn => 100,
        SourceType.PartnerFeed => 90, SourceType.Event => 70,
        SourceType.PublicApi => 55, SourceType.DemoTest => 40, _ => 20
    };
    private static int Recency(DateTimeOffset at)
    {
        var d = (DateTimeOffset.UtcNow - at).TotalDays;
        return d <= 1 ? 100 : d <= 7 ? 80 : d <= 30 ? 60 : d <= 90 ? 40 : 20;
    }
    private static int Clamp(int v) => Math.Max(0, Math.Min(100, v));
}
