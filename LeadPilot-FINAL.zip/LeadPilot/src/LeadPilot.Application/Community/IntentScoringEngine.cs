namespace LeadPilot.Application.Community;

/// <summary>سیگنال‌های قصد (سند). فقط رفتاری/اعلامی؛ هیچ ویژگیِ حساسی نیست.</summary>
public enum IntentSignalKind
{
    AskedForPricing, MentionedBudget, AskedProviderRecommendation, StatedCityOrArea,
    SetServiceTime, RequestedBooking, ComparedProviders, WantsToBuyBusiness,
    AskedAboutReturns, RequestedCompanyContact,
    // ضعیف/منفی
    GeneralComment, NewsDiscussion, AcademicQuestion, OldExperience, IsSellerOrCompetitor
}

/// <summary>
/// موتورِ امتیازدهیِ قصدِ خرید. توضیح‌پذیر: هر امتیاز همراهِ دلیل. هرگز تیپِ روان‌شناختی،
/// درآمد، قومیت، مذهب یا ویژگیِ حساس را حدس نمی‌زند (سند).
/// </summary>
public sealed class IntentScoringEngine
{
    private static readonly Dictionary<IntentSignalKind, (int weight, string reason)> Weights = new()
    {
        [IntentSignalKind.AskedForPricing] = (18, "سؤال دربارهٔ قیمت"),
        [IntentSignalKind.MentionedBudget] = (16, "ذکر بودجه"),
        [IntentSignalKind.AskedProviderRecommendation] = (16, "درخواست معرفیِ ارائه‌دهنده"),
        [IntentSignalKind.StatedCityOrArea] = (12, "اعلامِ شهر/منطقه"),
        [IntentSignalKind.SetServiceTime] = (12, "تعیینِ زمانِ خدمت"),
        [IntentSignalKind.RequestedBooking] = (18, "درخواستِ رزرو/جلسه"),
        [IntentSignalKind.ComparedProviders] = (10, "مقایسهٔ چند ارائه‌دهنده"),
        [IntentSignalKind.WantsToBuyBusiness] = (20, "قصدِ خریدِ کسب‌وکارِ فعال"),
        [IntentSignalKind.AskedAboutReturns] = (10, "سؤال دربارهٔ بازده/فرایندِ معامله"),
        [IntentSignalKind.RequestedCompanyContact] = (14, "درخواستِ تماس از یک شرکت"),
        // منفی
        [IntentSignalKind.GeneralComment] = (-8, "اظهارنظرِ عمومی"),
        [IntentSignalKind.NewsDiscussion] = (-8, "بحثِ خبری"),
        [IntentSignalKind.AcademicQuestion] = (-10, "سؤالِ تحقیقاتی"),
        [IntentSignalKind.OldExperience] = (-8, "تجربهٔ قدیمی"),
        [IntentSignalKind.IsSellerOrCompetitor] = (-40, "خودِ فرد فروشنده/رقیب است")
    };

    public IntentScore Score(IReadOnlyList<IntentSignalKind> signals)
    {
        int raw = 0;
        var reasons = new List<string>();
        foreach (var s in signals.Distinct())
        {
            if (!Weights.TryGetValue(s, out var w)) continue;
            raw += w.weight;
            reasons.Add((w.weight >= 0 ? "+ " : "− ") + w.reason);
        }
        int score = Math.Clamp(raw, 0, 100);
        var urgency = score >= 75 ? "High" : score >= 45 ? "Medium" : "Low";
        return new IntentScore(score, urgency, reasons);
    }
}

public sealed record IntentScore(int Score, string Urgency, IReadOnlyList<string> Reasons);
