using LeadPilot.Domain.Community;

namespace LeadPilot.Application.Community;

/// <summary>
/// خطِ تبدیلِ مشاهدهٔ خام به Opportunity (سند):
/// Raw observation → Source validation → Personal-data classification →
/// Allowed-field filtering → Deduplication → Opportunity record.
/// فیلدهای شخصی (نام واقعی/ایمیل/تلفن/نام مستعارِ قابلِ ردیابی) حذف می‌شوند؛ فقط دادهٔ عمومیِ
/// Thread می‌ماند. سیستم به‌صورت پیش‌فرض هویتِ واقعیِ کاربر را از Enrichment درخواست نمی‌کند.
/// </summary>
public sealed class OpportunityIngestionService
{
    public IngestionResult Ingest(CommunitySource source, RawObservation obs, bool isDuplicate)
    {
        if (!source.CanMonitor)
            return new IngestionResult(false, null, "منبع تأییدِ پایش ندارد.");

        // فیلترِ فیلدهای مجاز: هر فیلدِ شخصی کنار گذاشته می‌شود.
        // (نام واقعی/ایمیل/تلفن/username هرگز وارد Opportunity نمی‌شوند.)
        if (isDuplicate)
            return new IngestionResult(false, null, "تکراری.");

        var opp = new Opportunity(source.TenantId, source.Id, source.Platform, obs.Community,
            obs.PublicThreadUrl, obs.PublicPostId, obs.Topic, obs.QuestionSummary,
            obs.Language, obs.Industry, obs.DeclaredLocation, obs.IntentScore, obs.PublishedAtUtc);

        return new IngestionResult(true, opp, null);
    }
}

/// <summary>مشاهدهٔ خام — فقط دادهٔ عمومیِ مجاز. هیچ فیلدِ هویتیِ شخصی اینجا نیست.</summary>
public sealed record RawObservation(
    string Community, string PublicThreadUrl, string? PublicPostId, string Topic,
    string QuestionSummary, string Language, string Industry, string? DeclaredLocation,
    int IntentScore, DateTimeOffset PublishedAtUtc);

public sealed record IngestionResult(bool Ok, Opportunity? Opportunity, string? Reason);
