namespace LeadPilot.Application.Community;

/// <summary>
/// کنترلِ کیفیت/اعتبارِ برند پیش از انتشارِ پاسخ (سند). AI می‌تواند لحن را طبیعی کند، ولی
/// هرگز تجربه/هویت/رابطه را جعل نمی‌کند. حسابِ جعلیِ «نجات‌دهندهٔ دلسوز» مطلقاً رد است.
/// </summary>
public static class ResponseQualityGuard
{
    public static QualityDecision Check(ResponseDraft d)
    {
        var problems = new List<string>();
        if (!d.SpecialistIdentityDisclosed) problems.Add("هویتِ کارشناس/وابستگی به شرکت باید شفاف باشد.");
        if (d.ClaimsToBeCustomer) problems.Add("ادعای مشتری‌بودنِ جعلی ممنوع است.");
        if (d.GuaranteesResultOrProfit) problems.Add("تضمینِ سود/نتیجه ممنوع است.");
        if (d.DisparagesCompetitor) problems.Add("تخریبِ رقیب ممنوع است.");
        if (d.PressuresForPhone) problems.Add("فشار برای گرفتنِ شماره ممنوع است.");
        if (!d.RelevantToQuestion) problems.Add("پاسخ باید با سؤال مرتبط باشد.");
        if (d.IsDuplicateAcrossThreads) problems.Add("پاسخِ یکسان زیرِ ده‌ها پست ممنوع است.");
        if (!d.LinksToOfficialDomainOnly) problems.Add("لینک فقط به دامنهٔ رسمیِ شرکت.");
        return new QualityDecision(problems.Count == 0, problems);
    }
}

public sealed record ResponseDraft(
    bool SpecialistIdentityDisclosed, bool ClaimsToBeCustomer, bool GuaranteesResultOrProfit,
    bool DisparagesCompetitor, bool PressuresForPhone, bool RelevantToQuestion,
    bool IsDuplicateAcrossThreads, bool LinksToOfficialDomainOnly);

public sealed record QualityDecision(bool Approved, IReadOnlyList<string> Problems);
