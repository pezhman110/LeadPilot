using LeadPilot.Domain.Communications;

namespace LeadPilot.Application.Communications;

/// <summary>
/// اتوماسیونِ کامنتِ اینستاگرام (ManyChat-style، فقط API رسمی). یک کامنتِ ورودی روی پستِ
/// اکانتِ Business خودِ شرکت را با قواعد می‌سنجد. حالت Automatic → پاسخِ خودکار (دعوتِ opt-in)؛
/// حالت Manual → در صف برای تأییدِ کارشناس. هیچ داده‌ای بدونِ رضایت به مرحلهٔ تماس نمی‌رود.
/// </summary>
public sealed class InstagramCommentAutomationService
{
    public CommentAutomationDecision Evaluate(IReadOnlyList<InstagramCommentRule> rules, string commentText)
    {
        foreach (var rule in rules)
        {
            if (!rule.Matches(commentText)) continue;
            rule.RecordMatch();
            return rule.Mode == OutreachMode.Automatic
                ? new CommentAutomationDecision(true, rule.Id, rule.Mode,
                    rule.PublicReplyTemplateRef, rule.DmInviteTemplateRef,
                    "پاسخِ خودکار از طریق API رسمی (دعوتِ opt-in).")
                : new CommentAutomationDecision(true, rule.Id, rule.Mode,
                    rule.PublicReplyTemplateRef, rule.DmInviteTemplateRef,
                    "در صفِ تأییدِ کارشناس (حالت دستی).");
        }
        return new CommentAutomationDecision(false, null, OutreachMode.Manual, null, null, "قاعدهٔ منطبقی نبود.");
    }
}

public sealed record CommentAutomationDecision(
    bool Matched, Guid? RuleId, OutreachMode Mode,
    string? PublicReplyTemplateRef, string? DmInviteTemplateRef, string Note);
