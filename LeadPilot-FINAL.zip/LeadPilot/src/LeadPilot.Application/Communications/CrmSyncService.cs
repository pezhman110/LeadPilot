using LeadPilot.Domain.Crm;

namespace LeadPilot.Application.Communications;

/// <summary>ارسالِ نتیجهٔ عملکردِ کارشناس به CRM انتخاب‌شده (HubSpot/Salesforce/Zoho/Pipedrive/Webhook).</summary>
public sealed class CrmSyncService(
    IEnumerable<ICrmConnector> connectors,
    Application.Security.ISecretStore secretStore,
    ICommunicationStore store)
{
    private readonly IReadOnlyDictionary<CrmProvider, ICrmConnector> _connectors =
        connectors.ToDictionary(x => x.Provider);

    public async Task<CrmSyncRecord> PushAsync(CrmConnection connection, Guid prospectId, string outcome, CancellationToken ct)
    {
        var record = new CrmSyncRecord(connection.TenantId, connection.Id, prospectId, outcome);

        if (connection.Status != CrmConnectionStatus.Connected)
        {
            record.MarkFailed("اتصالِ CRM آماده نیست.");
            await store.SaveCrmSyncAsync(record, ct);
            return record;
        }

        if (!_connectors.TryGetValue(connection.Provider, out var connector))
        {
            record.MarkFailed($"Connector برای {connection.Provider} ثبت نشده است.");
            await store.SaveCrmSyncAsync(record, ct);
            return record;
        }

        string? secret = connection.SecretReference is null
            ? null : await secretStore.GetAsync(connection.SecretReference, ct);

        var result = await connector.PushOutcomeAsync(
            new CrmPushRequest(connection.TenantId, prospectId, outcome, secret, connection.BaseUrl), ct);

        if (result.Ok) record.MarkPushed(result.ExternalId ?? "unknown");
        else record.MarkFailed(result.Error ?? "ارسال به CRM ناموفق بود.");

        await store.SaveCrmSyncAsync(record, ct);
        return record;
    }
}
