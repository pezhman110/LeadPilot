using LeadPilot.Domain.Communications;

namespace LeadPilot.Application.Communications;

/// <summary>
/// سرویسِ کنسولِ ارتباطاتِ کارشناسِ فروش. قاعدهٔ سخت (آبروی شرکت):
///  • فقط مخاطبانِ دارای اکانت و رضایتِ همان کانال قابلِ ارتباط‌اند؛
///  • گیتِ رضایت/opt-out در دامنه اجرا می‌شود؛ هیچ مسیری دورش نمی‌زند؛
///  • هر تلاش (حتی مسدودشده) برای Audit ثبت می‌شود.
/// حالت Manual: کارشناس متن را تأیید/می‌فرستد. حالت Automatic: قاعده‌محور، فقط با API رسمی.
/// </summary>
public sealed class CommunicationsService(
    IContactConsentQuery consentQuery,
    IEnumerable<IChannelSender> senders,
    ICommunicationStore store)
{
    private readonly IReadOnlyDictionary<CommunicationChannel, IChannelSender> _senders =
        senders.ToDictionary(x => x.Channel);

    public async Task<OutreachAttempt> ContactAsync(
        Guid tenantId, Guid prospectId, Guid contactPointId, CommunicationChannel channel,
        OutreachMode mode, Guid agentId, string messageRef, string messageBody, CancellationToken ct)
    {
        // ۱) گیتِ رضایت/opt-out — منبعِ حقیقت لایهٔ Consent است.
        var snap = await consentQuery.GetAsync(contactPointId, channel, ct);

        var attempt = OutreachAttempt.Create(tenantId, prospectId, contactPointId, channel, mode, agentId,
            messageRef, snap.ChannelConsent, snap.IsSuppressed, snap.IsOnSuppressionList);

        // ۲) اگر گیت رد شد، فقط برای Audit ذخیره و بازگشت — هرگز ارسال نمی‌شود.
        if (!attempt.IsSendable)
        {
            await store.SaveAttemptAsync(attempt, ct);
            return attempt;
        }

        // ۳) فرستندهٔ اختصاصیِ کانال (API رسمی).
        if (!_senders.TryGetValue(channel, out var sender))
        {
            attempt.MarkFailed($"فرستندهٔ کانالِ {channel} ثبت نشده است.");
            await store.SaveAttemptAsync(attempt, ct);
            return attempt;
        }

        var result = await sender.SendAsync(
            new ChannelSendRequest(tenantId, prospectId, snap.DestinationRef, messageBody, mode), ct);

        if (result.Ok) attempt.MarkSent();
        else attempt.MarkFailed(result.Error ?? "ارسال ناموفق بود.");

        await store.SaveAttemptAsync(attempt, ct);
        return attempt;
    }
}
