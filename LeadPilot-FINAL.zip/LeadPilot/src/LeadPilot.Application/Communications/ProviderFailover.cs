using LeadPilot.Domain.Communications;

namespace LeadPilot.Application.Communications;

/// <summary>
/// یک ابزارِ پیام‌رسان (ManyChat/Respond.io/WATI/…). هر کدام کانال‌هایی را پشتیبانی می‌کند و
/// فقط با API رسمیِ خودش کار می‌کند. نسخهٔ واقعی با کلید در build اضافه می‌شود.
/// </summary>
public interface IMessagingProvider
{
    MessagingProviderCode Provider { get; }
    bool Supports(CommunicationChannel channel);
    Task<ProviderSendResult> SendAsync(ChannelSendRequest request, CancellationToken ct);
}

public sealed record ProviderSendResult(bool Ok, string? ExternalMessageId, string? Error);

/// <summary>
/// مسیریابِ Failover: برای یک کانال، ابزارها را به ترتیبِ اولویت امتحان می‌کند؛ اگر یکی
/// ناموفق شد یا در دسترس نبود، بعدی را می‌فرستد — «وقتی از یکی نشد، از اون یکی».
/// </summary>
public sealed class ProviderFailoverRouter(IEnumerable<IMessagingProvider> providers)
{
    private readonly IReadOnlyDictionary<MessagingProviderCode, IMessagingProvider> _map =
        providers.ToDictionary(x => x.Provider);

    public async Task<FailoverOutcome> SendAsync(
        CommunicationChannel channel, IReadOnlyList<ChannelProviderConfig> orderedConfigs,
        ChannelSendRequest request, CancellationToken ct)
    {
        var tried = new List<string>();

        foreach (var cfg in orderedConfigs
                     .Where(c => c.IsEnabled && c.Channel == channel)
                     .OrderBy(c => c.Priority))
        {
            if (!_map.TryGetValue(cfg.Provider, out var provider) || !provider.Supports(channel))
            {
                tried.Add($"{cfg.Provider}: در دسترس/سازگار نیست");
                continue;
            }

            ProviderSendResult result;
            try { result = await provider.SendAsync(request, ct); }
            catch (Exception ex) { tried.Add($"{cfg.Provider}: خطا ({ex.Message})"); continue; }

            if (result.Ok)
                return new FailoverOutcome(true, cfg.Provider, result.ExternalMessageId, tried);

            tried.Add($"{cfg.Provider}: {result.Error}");
        }

        return new FailoverOutcome(false, null, null, tried);
    }
}

public sealed record FailoverOutcome(
    bool Ok, MessagingProviderCode? UsedProvider, string? ExternalMessageId, IReadOnlyList<string> Attempts);
