using LeadPilot.Domain.Communications;

namespace LeadPilot.Application.Communications;

/// <summary>
/// موتورِ مسیریابیِ کانالِ کنترل‌شده (سند). «اگر از این مسیر نشد، از مسیرِ دیگر» — ولی
/// نه کورکورانه: کانالِ جایگزین باید رضایتِ مستقل و مجوزِ ارتباط داشته باشد.
/// ترتیب: Preferred channel → Permitted fallback → Human review.
/// Fallback فقط در خطای فنی یا ترجیحِ ثبت‌شده؛ نه برای دورزدنِ block/opt-out/rate-limit/پنجرهٔ پلتفرم.
/// </summary>
public sealed class ChannelRoutingEngine
{
    /// <summary>یک کانال را برای یک هدفِ تجاری ارزیابی می‌کند (۹ گامِ سند).</summary>
    public RoutingStatus EvaluateChannel(ChannelRoutingInput i, CommunicationChannel channel)
    {
        var cap = ChannelCapability.For(channel);
        if (!cap.OutboundSupported) return RoutingStatus.NeedsHumanApproval; // مثل تیک‌تاک: فقط انتقال

        // ۱) هویت: حساب متعلق به همان فرد و تأییدشده باشد.
        if (!i.IdentityOwnershipConfirmed) return RoutingStatus.NeedsHumanApproval;

        // ۶) Global Suppression / opt-out (اولویت بر همه).
        if (i.GloballySuppressedChannels.Contains(channel)) return RoutingStatus.Blocked;

        // ۲و۳) رضایتِ مستقلِ همین کانال برای همین هدف.
        if (!i.ChannelConsentGranted.Contains(channel)) return RoutingStatus.NeedsConsent;

        // ۸) سلامتِ Connector.
        if (!i.HealthyChannels.Contains(channel)) return RoutingStatus.ProviderUnavailable;

        // ۷) پیامِ تکراریِ اخیر.
        if (i.RecentlyMessagedChannels.Contains(channel)) return RoutingStatus.DuplicateRecent;

        // ۵) پنجره/قوانینِ پلتفرم.
        if (cap.RequiresIncomingWindow && !i.OpenIncomingWindowChannels.Contains(channel))
            return RoutingStatus.PlatformWindowClosed;
        if (cap.RequiresApprovedTemplate && !i.HasApprovedTemplateChannels.Contains(channel)
            && !i.OpenIncomingWindowChannels.Contains(channel))
            return RoutingStatus.NeedsHumanApproval; // واتساپ خارج از پنجره بدونِ Template

        return RoutingStatus.Permitted;
    }

    /// <summary>
    /// تصمیمِ نهایی: کانالِ ترجیحی → اولین fallbackِ مجاز → در غیر این صورت بررسیِ انسانی.
    /// </summary>
    public RoutingDecision Decide(ChannelRoutingInput i)
    {
        // ترتیب: کانالِ ترجیحیِ کاربر اول، بعد بقیهٔ مجازها.
        var order = new List<CommunicationChannel>();
        if (i.PreferredChannel is { } pref) order.Add(pref);
        order.AddRange(i.PermittedFallbackOrder.Where(c => c != i.PreferredChannel));

        var trail = new List<(CommunicationChannel channel, RoutingStatus status)>();
        foreach (var ch in order)
        {
            var status = EvaluateChannel(i, ch);
            trail.Add((ch, status));
            if (status == RoutingStatus.Permitted)
            {
                bool isFallback = i.PreferredChannel is { } p && ch != p;
                // ۹) اتوماسیونِ خودکار فقط اگر مجاز باشد؛ وگرنه پیشنهاد به کارشناس.
                var mode = i.AutomationAllowed && !isFallback ? SendMode.Automatic : SendMode.HumanReview;
                return new RoutingDecision(ch, mode,
                    isFallback ? "کانالِ جایگزینِ مجاز (رضایتِ مستقل دارد)." : "کانالِ ترجیحیِ مجاز.",
                    trail);
            }
        }
        return new RoutingDecision(null, SendMode.HumanReview, "هیچ کانالِ مجازِ خودکاری نبود؛ بررسیِ کارشناس لازم است.", trail);
    }
}

public enum SendMode { Manual = 0, AiAssisted = 1, Automatic = 2, HumanReview = 3 }

public sealed record ChannelRoutingInput(
    bool IdentityOwnershipConfirmed,
    CommunicationChannel? PreferredChannel,
    IReadOnlyList<CommunicationChannel> PermittedFallbackOrder,
    IReadOnlySet<CommunicationChannel> ChannelConsentGranted,
    IReadOnlySet<CommunicationChannel> GloballySuppressedChannels,
    IReadOnlySet<CommunicationChannel> HealthyChannels,
    IReadOnlySet<CommunicationChannel> RecentlyMessagedChannels,
    IReadOnlySet<CommunicationChannel> OpenIncomingWindowChannels,
    IReadOnlySet<CommunicationChannel> HasApprovedTemplateChannels,
    bool AutomationAllowed);

public sealed record RoutingDecision(
    CommunicationChannel? ChosenChannel, SendMode Mode, string Reason,
    IReadOnlyList<(CommunicationChannel Channel, RoutingStatus Status)> Trail);
