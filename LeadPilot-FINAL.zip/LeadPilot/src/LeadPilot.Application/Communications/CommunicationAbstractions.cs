using LeadPilot.Domain.Communications;

namespace LeadPilot.Application.Communications;

/// <summary>
/// فرستندهٔ اختصاصیِ هر کانال. هر سوشیال/پیام‌رسان یک پیاده‌سازیِ جدا دارد و فقط با API رسمیِ
/// همان پلتفرم کار می‌کند. نسخهٔ واقعی با کلید/دسترسیِ رسمی در build اضافه می‌شود.
/// </summary>
public interface IChannelSender
{
    CommunicationChannel Channel { get; }
    Task<ChannelSendResult> SendAsync(ChannelSendRequest request, CancellationToken ct);
}

public sealed record ChannelSendRequest(
    Guid TenantId, Guid ProspectId, string DestinationRef, string MessageBody, OutreachMode Mode);

public sealed record ChannelSendResult(bool Ok, string? ExternalMessageId, string? Error);

/// <summary>خواندنِ وضعیتِ رضایت/Suppress برای گیتِ ارسال. از لایهٔ Consent می‌آید.</summary>
public interface IContactConsentQuery
{
    Task<ContactConsentSnapshot> GetAsync(Guid contactPointId, CommunicationChannel channel, CancellationToken ct);
}

public sealed record ContactConsentSnapshot(
    ChannelConsentStatus ChannelConsent, bool IsSuppressed, bool IsOnSuppressionList, string DestinationRef);

/// <summary>اتصالِ CRM — ارسالِ نتیجهٔ عملکرد به HubSpot/Salesforce/… .</summary>
public interface ICrmConnector
{
    Domain.Crm.CrmProvider Provider { get; }
    Task<CrmPushResult> PushOutcomeAsync(CrmPushRequest request, CancellationToken ct);
}

public sealed record CrmPushRequest(Guid TenantId, Guid ProspectId, string Outcome, string? SecretValue, string? BaseUrl);
public sealed record CrmPushResult(bool Ok, string? ExternalId, string? Error);

/// <summary>ذخیره‌گاهِ ماژولِ ارتباطات.</summary>
public interface ICommunicationStore
{
    Task SaveAttemptAsync(OutreachAttempt attempt, CancellationToken ct);
    Task SaveCrmSyncAsync(Domain.Crm.CrmSyncRecord record, CancellationToken ct);
}
