using LeadPilot.Domain.Content;

namespace LeadPilot.Application.Content;

// ── مغزِ تولید محتوا (متن/اسکریپت/سناریو) ──
// این interface را یک سرویسِ LLM پیاده می‌کند. ورودی: ۴ عاملِ سند.
// خروجی: متن، اسکریپت صحنه‌به‌صحنهٔ ویدیو، اسکریپت پادکست، بریف موشن.
// نکته: تولیدِ متن است؛ فایلِ نهاییِ ویدیو/صوت/تصویر را موتورهای بیرونی می‌سازند.
public interface IAiContentBrain
{
    Task<GeneratedContent> GenerateAsync(ContentGenerationInput input, CancellationToken ct);
}

public sealed record ContentGenerationInput(
    string Heading,               // سرفصل
    string AudienceGroup,         // گروه مخاطب (تیپ شخصیتی)
    string Language,
    string PriorAdModel,          // مدل/طرح تبلیغاتیِ قبلیِ همان گروه
    string MarketTrends,          // ترندهای روز بازار
    ContentAssetType targetType);

public sealed record GeneratedContent(
    string AdCopy,                // متن آگهی
    string BannerText,            // متن بنر
    string CarouselText,          // متن کاروسل
    IReadOnlyList<VideoScene> VideoScript,   // اسکریپت ویدیو صحنه‌به‌صحنه
    string PodcastScript,         // اسکریپت پادکست/صوت
    string MotionBrief);          // بریف موشن

public sealed record VideoScene(int Order, string Visual, string VoiceOver, int DurationSeconds);

// ── موتورهای تولیدِ فایلِ نهایی (بیرونی؛ ارکستراسیون توسط ماژول) ──
// این‌ها را Claude (مدل متن) خودش اجرا نمی‌کند؛ به سرویس بیرونی وصل می‌شوند.
public interface IImageEngine   { Task<string> RenderAsync(string prompt, string language, CancellationToken ct); }  // Canva/image → storageRef
public interface IAudioEngine   { Task<string> SynthesizeAsync(string script, string language, CancellationToken ct); } // TTS → storageRef
public interface IVideoEngine   { Task<string> ProduceAsync(IReadOnlyList<VideoScene> scenes, string language, CancellationToken ct); } // video API → storageRef

// ── مخزن محتوا ──
public interface IContentRepository
{
    Task AddHeadingAsync(ContentHeading h, CancellationToken ct);
    Task<IReadOnlyList<ContentHeading>> ListHeadingsAsync(Guid projectId, CancellationToken ct);
    Task AddAssetAsync(ContentAsset a, CancellationToken ct);
    Task<IReadOnlyList<ContentAsset>> ListAssetsAsync(Guid projectId, CancellationToken ct);
    Task AddLandingAsync(LandingPage p, CancellationToken ct);
    Task AddCampaignAsync(Campaign c, CancellationToken ct);
    Task<Campaign?> GetCampaignAsync(Guid id, CancellationToken ct);
    Task AddPresentationAsync(Presentation p, CancellationToken ct);
    Task<Presentation?> GetPresentationAsync(Guid id, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}
