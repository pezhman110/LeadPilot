using LeadPilot.Domain.Content;

namespace LeadPilot.Application.Content;

/// <summary>
/// ماژول محتوا — مغزِ متفکر و ارکستراتور. ساخت سرفصل، بررسیِ موجودی (غریال)،
/// تولید محتوا (متن/اسکریپت توسط AI؛ فایل نهایی توسط موتورهای بیرونی)،
/// صفحهٔ فرود، کمپین، و پرزنت اختصاصی.
/// </summary>
public sealed class ContentService(
    IContentRepository repo,
    IAiContentBrain brain)
{
    public async Task<Guid> AddHeadingAsync(Guid projectId, string title, string audienceGroup, string language, CancellationToken ct)
    {
        var h = new ContentHeading(projectId, title, audienceGroup, language);
        await repo.AddHeadingAsync(h, ct); await repo.SaveChangesAsync(ct);
        return h.Id;
    }

    /// <summary>
    /// «غریال»: بررسی موجودیِ محتوا → گزارشِ «چه داریم / چه کم داریم».
    /// برای هر ترکیبِ (نوع محتوا × زبان)، اگر asset تأییدشده نداریم = کمبود.
    /// </summary>
    public async Task<InventoryReport> ReviewInventoryAsync(Guid projectId, IReadOnlyList<string> languages, CancellationToken ct)
    {
        var assets = await repo.ListAssetsAsync(projectId, ct);
        var have = new List<string>();
        var missing = new List<string>();

        foreach (ContentAssetType type in Enum.GetValues<ContentAssetType>())
        {
            foreach (var lang in languages)
            {
                bool exists = assets.Any(a => a.Type == type && a.Language == lang
                    && a.Status is ContentStatus.Approved or ContentStatus.Published);
                var label = $"{type} · {lang}";
                if (exists) have.Add(label); else missing.Add(label);
            }
        }
        return new InventoryReport(projectId, assets.Count, have, missing);
    }

    /// <summary>
    /// تولید محتوا برای یک سرفصل و گروه. مغزِ AI متن/اسکریپت می‌سازد؛
    /// asset با وضعیت Draft ثبت می‌شود و مرجعِ فایل بعداً از موتور بیرونی می‌آید.
    /// </summary>
    public async Task<GeneratedContent> GenerateAsync(
        Guid projectId, string heading, string audienceGroup, string language,
        string priorAdModel, string marketTrends, ContentAssetType targetType, CancellationToken ct)
    {
        var input = new ContentGenerationInput(heading, audienceGroup, language, priorAdModel, marketTrends, targetType);
        var generated = await brain.GenerateAsync(input, ct);

        var asset = new ContentAsset(projectId, targetType, language, heading, storageRef: null);
        asset.MarkAiGenerated();
        await repo.AddAssetAsync(asset, ct);
        await repo.SaveChangesAsync(ct);
        return generated;
    }

    public async Task<Guid> CreateLandingAsync(Guid projectId, string slug, string templateCode, string language, string headline, CancellationToken ct)
    {
        var p = new LandingPage(projectId, slug, templateCode, language, headline);
        await repo.AddLandingAsync(p, ct); await repo.SaveChangesAsync(ct);
        return p.Id;
    }

    public async Task<Guid> CreateCampaignAsync(Guid projectId, string name, CampaignScope scope, Guid landingPageId, CancellationToken ct)
    {
        var c = new Campaign(projectId, name, scope, landingPageId);
        await repo.AddCampaignAsync(c, ct); await repo.SaveChangesAsync(ct);
        return c.Id;
    }

    public async Task<bool> StartCampaignAsync(Guid campaignId, CancellationToken ct)
    {
        var c = await repo.GetCampaignAsync(campaignId, ct);
        if (c is null) return false;
        c.Start(); await repo.SaveChangesAsync(ct); return true;
    }

    /// <summary>پرزنت اختصاصی برای یک فرد؛ اسکریپت را مغزِ AI می‌سازد.</summary>
    public async Task<Guid> BuildPresentationAsync(
        Guid prospectId, Guid projectId, PresenterKind presenter, string language,
        string heading, string audienceGroup, string priorAdModel, string marketTrends, CancellationToken ct)
    {
        var p = new Presentation(prospectId, projectId, presenter, language);
        var input = new ContentGenerationInput(heading, audienceGroup, language, priorAdModel, marketTrends, ContentAssetType.Text);
        var generated = await brain.GenerateAsync(input, ct);
        // اسکریپت اختصاصی از متنِ تولیدشده ساخته می‌شود (مرجع در نسخهٔ واقعی ذخیره می‌شود).
        p.AttachScript(generated.PodcastScript);
        await repo.AddPresentationAsync(p, ct); await repo.SaveChangesAsync(ct);
        return p.Id;
    }

    public async Task<bool> EvaluatePresentationAsync(Guid presentationId, int qualityScore, CancellationToken ct)
    {
        var p = await repo.GetPresentationAsync(presentationId, ct);
        if (p is null) return false;
        p.Evaluate(qualityScore); await repo.SaveChangesAsync(ct); return true;
    }
}

public sealed record InventoryReport(Guid ProjectId, int TotalAssets, IReadOnlyList<string> Have, IReadOnlyList<string> Missing);
