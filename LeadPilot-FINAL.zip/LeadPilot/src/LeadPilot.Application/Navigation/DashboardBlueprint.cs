using LeadPilot.Domain.Navigation;

namespace LeadPilot.Application.Navigation;

/// <summary>
/// نقشهٔ کانونیِ داشبورد: همهٔ ماژول‌های ساخته‌شده روی «مسیرِ فرآیند/خرید» چیده می‌شوند.
/// منبعِ واحدِ حقیقت برای منو؛ UI هرگز دکمه hardcode نمی‌کند و از این نقشه می‌خواند.
/// اصولِ سند: به ۷۰ دکمه نرسیم (گروه‌بندی)، موارد کم‌اهمیت جلوی صفحه نباشند (IsPrimary=false → پشتِ گروه/تنظیمات).
/// </summary>
public static class DashboardBlueprint
{
    public static IReadOnlyList<NavItem> AllItems { get; } =
    [
        // ۱) Discovery — کشف
        new("source-discovery",  "کشف منبع",            "Source discovery",       ProcessStage.Discovery, DashboardRole.Manager, true,  "radar"),
        new("communities",       "انجمن‌ها و فروم‌ها",   "Communities & forums",   ProcessStage.Discovery, DashboardRole.Seller,  true,  "users"),
        new("intent-signals",    "سیگنال‌های قصد",       "Intent signals",         ProcessStage.Discovery, DashboardRole.Seller,  true,  "activity"),
        new("competitor-research","تحلیل رقبا",          "Competitor research",    ProcessStage.Discovery, DashboardRole.Manager, false, "search"),

        // ۲) Capture & Consent — دریافت و رضایت
        new("lead-magnets",      "Lead Magnetها",        "Lead magnets",           ProcessStage.CaptureConsent, DashboardRole.Manager, true,  "gift"),
        new("landing-forms",     "لندینگ و فرم رضایت",   "Landing & consent forms",ProcessStage.CaptureConsent, DashboardRole.Manager, true,  "form"),
        new("csv-import",        "ورود CSV/CRM",         "CSV/CRM import",         ProcessStage.CaptureConsent, DashboardRole.Manager, false, "upload"),
        new("consent",           "رضایت‌ها",             "Consents",               ProcessStage.CaptureConsent, DashboardRole.Manager, false, "check"),

        // ۳) Governance — حاکمیت
        new("quarantine",        "قرنطینه",              "Quarantine",             ProcessStage.Governance, DashboardRole.Manager, true,  "shield"),
        new("provider-approval", "تأیید Providerها",     "Provider approvals",     ProcessStage.Governance, DashboardRole.Manager, false, "badge"),
        new("enrichment",        "غنی‌سازی (B2B)",       "Enrichment (B2B)",       ProcessStage.Governance, DashboardRole.Manager, false, "database"),

        // ۴) Assignment — تخصیص
        new("agent-workspace",   "میزکار فروشنده",       "Agent workspace",        ProcessStage.Assignment, DashboardRole.Seller,  true,  "briefcase"),
        new("assignments",       "تخصیص شماره",          "Contact assignments",    ProcessStage.Assignment, DashboardRole.Manager, false, "link"),
        new("targets",           "اهداف",                "Targets",                ProcessStage.Assignment, DashboardRole.Manager, false, "target"),

        // ۵) Communication — ارتباطات
        new("inbox",             "صندوق یکپارچه",        "Unified inbox",          ProcessStage.Communication, DashboardRole.Seller,  true,  "inbox"),
        new("ig-automation",     "اتوماسیون کامنت",      "Comment automation",     ProcessStage.Communication, DashboardRole.Seller,  false, "robot"),
        new("routing",           "مسیریابی کانال",       "Channel routing",        ProcessStage.Communication, DashboardRole.Manager, false, "route"),

        // ۶) Conversion & CRM — تبدیل
        new("outcomes",          "نتیجه تماس",           "Outcomes",               ProcessStage.Conversion, DashboardRole.Seller,  true,  "flag"),
        new("crm-sync",          "همگام‌سازی CRM",       "CRM sync",               ProcessStage.Conversion, DashboardRole.Manager, false, "sync"),

        // ۷) Reports & Compliance — گزارش و انطباق
        new("reports",           "گزارش عملکرد",         "Performance reports",    ProcessStage.ReportsCompliance, DashboardRole.Manager, true,  "chart"),
        new("audit",             "ممیزی",                "Audit trail",            ProcessStage.ReportsCompliance, DashboardRole.Manager, false, "list"),
        new("suppression",       "فهرست توقف",           "Suppression list",       ProcessStage.ReportsCompliance, DashboardRole.Manager, false, "ban"),
        new("retention",         "نگهداری و حذف",        "Retention & deletion",   ProcessStage.ReportsCompliance, DashboardRole.Manager, false, "clock"),

        // Settings — تُنُک، پشتِ صفحه (هیچ‌کدام Primary نیست)
        new("connections",      "اتصالات",              "Connections",            ProcessStage.Settings, DashboardRole.Admin, false, "plug"),
        new("templates",        "قالب‌ها",              "Templates",              ProcessStage.Settings, DashboardRole.Manager, false, "template"),
        new("roles",            "نقش‌ها و دسترسی",      "Roles & permissions",    ProcessStage.Settings, DashboardRole.Admin, false, "key"),
        new("vendor-reviews",   "بازبینی Vendor",       "Vendor reviews",         ProcessStage.Settings, DashboardRole.Manager, false, "clipboard"),
    ];

    /// <summary>منوی یک نقش: فقط آیتم‌های مجاز، گروه‌بندی‌شده بر اساسِ مرحله (نه ۷۰ دکمهٔ صاف).</summary>
    public static IReadOnlyList<StageGroup> MenuFor(DashboardRole role) =>
        AllItems.Where(i => i.VisibleTo(role))
            .GroupBy(i => i.Stage)
            .OrderBy(g => (int)g.Key)
            .Select(g => new StageGroup(g.Key,
                g.OrderByDescending(i => i.IsPrimary).ToList()))
            .ToList();

    public static IReadOnlyList<StageCostEstimate> CostEstimates { get; } =
    [
        new(ProcessStage.Discovery,      "Apify/Monitoring (پایش منابع)",          30,  300, "per month"),
        new(ProcessStage.CaptureConsent, "Landing/Forms (میزبانی + فرم)",          0,   50,  "per month"),
        new(ProcessStage.Governance,     "Enrichment: Apollo/Lusha (B2B)",         50,  100, "per seat/month"),
        new(ProcessStage.Assignment,     "داخلی (بدون هزینهٔ خارجی)",              0,   0,   "—"),
        new(ProcessStage.Communication,  "WhatsApp Cloud + ManyChat/Respond.io",   50,  400, "seat + per-conversation"),
        new(ProcessStage.Conversion,     "CRM: HubSpot/Zoho (پلن)",                0,   500, "per month (tier)"),
        new(ProcessStage.ReportsCompliance,"داخلی (بدون هزینهٔ خارجی)",            0,   0,   "—"),
    ];
}

public sealed record StageGroup(ProcessStage Stage, IReadOnlyList<NavItem> Items);
