using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Common;

namespace LeadPilot.Application.Reporting;

/// <summary>
/// گزارش مدیریتیِ «یک نگاه» — کلِ پروژه در یک تصویر، دوزبانه.
/// هر لید یک «لینک منبعِ قابل‌کلیک» دارد (از کجا انتخاب شد) با نمرهٔ آن.
/// </summary>
public sealed class ManagementReportService(ISignalRepository signals)
{
    public async Task<ProjectReport> BuildAsync(Guid projectId, CancellationToken ct)
    {
        var all = await signals.ListByProjectAsync(projectId, ct);

        int total = all.Count;
        int blocked = all.Count(s => s.ComplianceStatus == ComplianceStatus.Blocked);
        int high = all.Count(s => s.FinalScore >= 90);
        int mid = all.Count(s => s.FinalScore is >= 50 and < 90);
        int low = all.Count(s => s.FinalScore < 50);

        var byLanguage = all.GroupBy(s => s.Language.ToString())
            .ToDictionary(g => g.Key, g => g.Count());
        var bySource = all.GroupBy(s => s.SourceType.ToString())
            .ToDictionary(g => g.Key, g => g.Count());

        // هر لید با provenanceِ قابل‌کلیک.
        var leads = all.OrderByDescending(s => s.FinalScore).Take(200).Select(s => new LeadRow(
            Id: s.Id,
            Summary: s.TranslatedSummaryFa,
            Score: s.FinalScore,
            IntentScore: s.IntentScore,
            FitScore: s.FitScore,
            ComplianceScore: s.ComplianceScore,
            Language: s.Language.ToString(),
            Source: s.SourceType.ToString(),
            // «از کجا انتخاب شد» — لینک قابل‌کلیک + Query.
            ProvenanceUrl: s.SourceUrl,
            QueryUsed: s.QueryUsed,
            Route: Route(s.FinalScore),
            Reasons: s.ReasonForScore
        )).ToList();

        return new ProjectReport(projectId, total, high, mid, low, blocked, byLanguage, bySource, leads);
    }

    // مسیریابی نمره (تأییدشدهٔ گردش‌کار): بالا → کارشناس، ۵۰–۸۹ → AI، زیر ۵۰ → عدم پیگیری.
    private static string Route(int score) =>
        score >= 90 ? "HumanExpert" : score >= 50 ? "AiNurture" : "NoPursuit";
}

public sealed record ProjectReport(
    Guid ProjectId,
    int Total, int High, int Mid, int Low, int Blocked,
    IReadOnlyDictionary<string, int> ByLanguage,
    IReadOnlyDictionary<string, int> BySource,
    IReadOnlyList<LeadRow> Leads);

public sealed record LeadRow(
    Guid Id, string Summary, int Score, int IntentScore, int FitScore, int ComplianceScore,
    string Language, string Source,
    string ProvenanceUrl, string QueryUsed, string Route,
    IReadOnlyList<string> Reasons);
