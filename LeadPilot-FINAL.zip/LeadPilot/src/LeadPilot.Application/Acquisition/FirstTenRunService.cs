using LeadPilot.Application.Connections;
using LeadPilot.Application.Dedup;
using LeadPilot.Domain.Acquisition;
using LeadPilot.Domain.Dedup;
using LeadPilot.Domain.Sources;

namespace LeadPilot.Application.Acquisition;

/// <summary>
/// موتور «۱۰ نتیجهٔ اول». جریان کامل (سند بخش خروجی مرحله):
/// سلامت اتصالات → کاندیدها → آبشار رایگان→پولی → نرمال/Dedup →
/// ContactPoint با ManagerOnly → ۱۰ نتیجهٔ یکتا و واجدِ شرایط → توقف خودکار.
/// </summary>
public sealed class FirstTenRunService(
    IConnectorHealthService healthService,
    ITestCandidateProvider candidateProvider,
    IContactEnrichmentCascade cascade,
    DeduplicationService dedup,
    IFirstTenRunStore store,
    FirstResultsQualifier qualifier,
    TimeProvider timeProvider) : IFirstTenRunService
{
    public async Task<FirstTenRunResponse> StartAsync(StartFirstTenRunCommand command, CancellationToken ct)
    {
        var now = timeProvider.GetUtcNow();
        var run = new FirstTenRun(command.TenantId, command.ProjectId, command.ProjectCode,
            command.IsCorporateProject, command.TargetCount, command.MaximumCandidates,
            command.MaximumCostAed, command.StartedBy, now);

        // ۱) گیتِ واقعیِ آمادگیِ اتصالات (سند بخش ۱۴) — بدون اتصالِ سالمِ حیاتی و بدون
        //    حداقل یک منبعِ کشفِ قابل‌استفاده، اجرا شروع نمی‌شود.
        run.MarkWaitingForConnections();
        var readiness = await healthService.CheckStartupReadinessAsync(command.TenantId, ct);
        if (!readiness.CanStart)
        {
            run.Fail("اتصال‌های حیاتی آماده نیستند: " + string.Join(", ", readiness.BlockingConnectors), now);
            await store.SaveAsync(run, ct);
            return ToResponse(run);
        }

        // ۲) کاندیدهای واقعیِ پروژه (سیگنال).
        var candidates = await candidateProvider.GetCandidatesAsync(
            command.TenantId, command.ProjectId, command.IsCorporateProject, command.MaximumCandidates, ct);
        if (candidates.Count == 0)
        {
            run.Queue(1); run.Start(now);
            run.CompleteWithShortage("کاندیدی برای این پروژه یافت نشد.", now);
            await store.SaveAsync(run, ct);
            return ToResponse(run);
        }

        run.Queue(candidates.Count);
        run.Start(now);

        // ۳) آبشار برای هر کاندید تا رسیدن به هدف یا پایان کاندیدها/بودجه.
        foreach (var candidate in candidates)
        {
            if (!run.CanAcceptResult()) break;
            decimal remaining = run.MaximumCostAed - run.ConsumedCostAed;

            var outcome = await cascade.RunAsync(candidate, command.IsCorporateProject, remaining, ct);
            if (!outcome.Found)
            {
                run.RecordCandidateProcessed(wasDuplicate: false, wasInvalid: true, costAed: outcome.CostAed);
                continue;
            }

            var contactType = outcome.ContactType.Equals("EMAIL", StringComparison.OrdinalIgnoreCase)
                ? ContactType.Email : ContactType.Phone;

            // ۴) نرمال/Dedup — شمارهٔ روزهای گذشته دوباره ساخته/خریده نشود.
            var dedupResult = await dedup.RegisterAsync(command.TenantId, contactType, outcome.RawValue!, outcome.SourceCode, ct);
            bool isDuplicate = !dedupResult.IsNew;

            // ۵) شرطِ ۱۰ نتیجه — تکراری/بدون‌منبع/شرکتی‌برای‌شخصی/ساختگی رد.
            var masked = MaskValue(contactType, outcome.RawValue!);
            var qualification = qualifier.Qualify(new ContactQualificationInput(
                IsNormalized: true, Hash: dedupResult.ContactRecordId.ToString(), IsDuplicate: isDuplicate,
                SourceReference: outcome.SourceReference, Classification: MapClass(outcome.Classification),
                ProjectRuleSatisfied: !(command.IsCorporateProject == false && outcome.Classification == ContactClassification.Corporate),
                MaskedValue: masked, ContactRecordCreated: true,
                IsAiFabricated: outcome.SourceCode.Equals("AI", StringComparison.OrdinalIgnoreCase),
                IsSuppressed: false, IsExtractedFromDisallowedPersonalSource: false));

            run.RecordCandidateProcessed(isDuplicate, wasInvalid: !outcome.IsValid, costAed: outcome.CostAed);

            if (!qualification.IsQualified) continue;

            // ۶) ContactPoint (ManagerOnly/Hidden) + ثبت نتیجه (فقط ماسک‌شده).
            var contactPointId = await store.CreateManagerOnlyContactPointAsync(
                command.TenantId, command.ProjectId, candidate.ProspectId, contactType,
                outcome.RawValue!, outcome.SourceCode, ct);

            var result = new FirstTenRunResult(run.Id, candidate.ProspectId, contactPointId,
                outcome.ContactType, masked, outcome.SourceCode, outcome.SourceReference,
                outcome.SourceUrl, outcome.ConfidenceScore, outcome.CostAed, now);
            run.AddResult(result, now);
        }

        // ۷) پایان: اگر به هدف نرسید، کمبود. Jobهای باقی‌مانده منطقاً لغو (اینجا حلقه پایان یافته).
        if (run.Status == FirstTenRunStatus.Running)
            run.CompleteWithShortage("کاندیدها/بودجه پیش از رسیدن به هدف تمام شد.", now);

        await store.SaveAsync(run, ct);
        return ToResponse(run);
    }

    public async Task<FirstTenRunResponse?> GetAsync(Guid runId, CancellationToken ct)
    {
        var run = await store.GetAsync(runId, ct);
        return run is null ? null : ToResponse(run);
    }

    public async Task CancelAsync(Guid runId, CancellationToken ct)
    {
        var run = await store.GetAsync(runId, ct);
        if (run is null) return;
        run.Cancel(timeProvider.GetUtcNow());
        await store.SaveAsync(run, ct);
    }

    private static ContactClass MapClass(ContactClassification c) => c switch
    {
        ContactClassification.Corporate => ContactClass.Corporate,
        ContactClassification.PublicBusiness => ContactClass.PublicBusiness,
        ContactClassification.PersonalSelfSubmitted => ContactClass.PersonalSelfSubmitted,
        ContactClassification.PartnerSupplied => ContactClass.PartnerSupplied,
        _ => ContactClass.Unknown
    };

    private static string MaskValue(ContactType type, string raw)
    {
        if (type == ContactType.Email)
        {
            var at = raw.IndexOf('@');
            if (at <= 1) return "***" + (at >= 0 ? raw[at..] : "");
            return raw[0] + "***" + raw[(at - 1)..];
        }
        var digits = new string(raw.Where(char.IsDigit).ToArray());
        return digits.Length <= 6 ? "****" : digits[..5] + "****" + digits[^2..];
    }

    private static FirstTenRunResponse ToResponse(FirstTenRun run) => new(
        run.Id, run.Status.ToString(), run.ResultCount, run.TargetCount,
        run.CandidatesProcessed, run.DuplicateCount, run.InvalidCount, run.ConsumedCostAed,
        run.FailureReason,
        run.Results.Select(r => new FirstTenRunResultView(
            r.ContactType, r.MaskedValue, r.SourceCode, r.SourceReference, r.SourceUrl,
            r.ConfidenceScore, r.CostAed)).ToList());
}

/// <summary>ذخیره‌سازِ اجرای آزمایشی + ساختِ ContactPoint با ManagerOnly.</summary>
public interface IFirstTenRunStore
{
    Task SaveAsync(FirstTenRun run, CancellationToken ct);
    Task<FirstTenRun?> GetAsync(Guid runId, CancellationToken ct);
    Task<Guid> CreateManagerOnlyContactPointAsync(
        Guid tenantId, Guid projectId, Guid prospectId, ContactType type,
        string rawValue, string sourceCode, CancellationToken ct);
}
