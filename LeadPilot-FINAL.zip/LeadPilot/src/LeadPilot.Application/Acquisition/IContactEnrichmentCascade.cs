using LeadPilot.Domain.Sources;

namespace LeadPilot.Application.Acquisition;

/// <summary>
/// آبشارِ دریافتِ تلفن/ایمیل برای یک کاندید: اول رایگان/ارزان، بعد پولی.
/// خروجی: مقدارِ خام (برای hash/رمزنگاری)، منبع، هزینه، و اعتبار.
/// نسخهٔ واقعی به Connectorهای واقعی وصل می‌شود؛ فعلاً Adapter آزمایشی.
/// </summary>
public interface IContactEnrichmentCascade
{
    Task<EnrichmentOutcome> RunAsync(AcquisitionCandidate candidate, bool isCorporateProject,
        decimal remainingBudgetAed, CancellationToken ct);
}

public sealed record EnrichmentOutcome(
    bool Found, string? RawValue, string ContactType, string SourceCode, string SourceReference,
    string? SourceUrl, ContactClassification Classification, int ConfidenceScore, decimal CostAed, bool IsValid);
