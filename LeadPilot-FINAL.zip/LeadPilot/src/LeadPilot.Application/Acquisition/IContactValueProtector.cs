namespace LeadPilot.Application.Acquisition;

/// <summary>رمزنگاری/رمزگشاییِ مقدارِ تماس. پیاده‌سازی در Infrastructure.</summary>
public interface IContactValueProtector
{
    string Protect(string plaintext);
    string Unprotect(string ciphertext);
}
