namespace LeadPilot.Application.Acquisition;

/// <summary>منبعِ کاندیدهای آزمایشی (سیگنال‌های واقعیِ پروژه). نه شمارهٔ آماده.</summary>
public interface ITestCandidateProvider
{
    Task<IReadOnlyList<AcquisitionCandidate>> GetCandidatesAsync(
        Guid tenantId, Guid projectId, bool isCorporateProject, int maximumCandidates, CancellationToken ct);
}

public sealed record AcquisitionCandidate(
    Guid ProspectId, string? PersonName, string? CompanyName, string? CompanyDomain,
    string? SourceProfileUrl, string LanguageCode, string CountryCode,
    string SourceCode, string SourceReference, bool NeedsPhone, bool NeedsEmail);

public interface IFirstTenRunService
{
    Task<FirstTenRunResponse> StartAsync(StartFirstTenRunCommand command, CancellationToken ct);
    Task<FirstTenRunResponse?> GetAsync(Guid runId, CancellationToken ct);
    Task CancelAsync(Guid runId, CancellationToken ct);
}

public sealed record StartFirstTenRunCommand(
    Guid TenantId, Guid ProjectId, string ProjectCode, bool IsCorporateProject,
    int TargetCount, int MaximumCandidates, decimal MaximumCostAed, string StartedBy);

public sealed record FirstTenRunResponse(
    Guid RunId, string Status, int ResultCount, int TargetCount,
    int CandidatesProcessed, int DuplicateCount, int InvalidCount, decimal ConsumedCostAed,
    string? FailureReason, IReadOnlyList<FirstTenRunResultView> Results);

public sealed record FirstTenRunResultView(
    string ContactType, string MaskedValue, string SourceCode, string SourceReference,
    string? SourceUrl, int ConfidenceScore, decimal CostAed);
