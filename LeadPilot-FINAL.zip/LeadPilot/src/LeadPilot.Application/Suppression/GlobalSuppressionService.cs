using LeadPilot.Domain.Suppression;

namespace LeadPilot.Application.Suppression;

public interface IGlobalSuppressionStore
{
    Task<IReadOnlyList<GlobalSuppressionEntry>> GetForIdentityAsync(Guid tenantId, string identityHash, CancellationToken ct);
    Task AddAsync(GlobalSuppressionEntry entry, CancellationToken ct);
}

/// <summary>
/// بررسیِ Global Suppression پیش از هر ارسال (اولویت بر همهٔ Connectorها). اگر مخاطب در هر
/// کانال/CRM توقف خواسته و دامنه‌اش AllMarketing است، همهٔ کانال‌ها بسته می‌شوند؛ اگر ChannelOnly
/// است، فقط همان کانال.
/// </summary>
public sealed class GlobalSuppressionService(IGlobalSuppressionStore store)
{
    public async Task<bool> IsBlockedAsync(Guid tenantId, string identityHash, string targetChannel, CancellationToken ct)
    {
        var entries = await store.GetForIdentityAsync(tenantId, identityHash, ct);
        return entries.Any(e => e.Blocks(targetChannel));
    }

    public async Task SuppressAsync(Guid tenantId, string identityHash, SuppressionScope scope,
        string? channel, string reason, string source, CancellationToken ct)
    {
        var entry = new GlobalSuppressionEntry(tenantId, identityHash, scope, channel, reason, source);
        await store.AddAsync(entry, ct);
    }
}
