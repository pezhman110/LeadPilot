using LeadPilot.Domain.Identity;

namespace LeadPilot.Application.Identity;

/// <summary>
/// اتصالِ حساب‌های یک مشتری فقط با شواهدِ معتبر. شباهتِ عکس/نام هرگز ادغام نمی‌شود.
/// اتصالِ کم‌اطمینان (NeedsReview) نیازمندِ تأییدِ کارشناس/مدیر است.
/// </summary>
public sealed class IdentityResolutionService
{
    public IdentityLink Propose(Guid tenantId, Guid unifiedProfileId, string channel, string handle, IdentityEvidence evidence)
        => new(tenantId, unifiedProfileId, channel, handle, evidence);

    /// <summary>آیا این اتصال بدونِ دخالتِ انسان قابلِ استفاده برای ادغام است؟</summary>
    public bool CanAutoMerge(IdentityLink link) => link.IsUsableForMerge;

    /// <summary>آیا نیازمندِ تأییدِ انسانی است؟ (NeedsReview یا HighConfidenceِ تأییدنشده)</summary>
    public bool RequiresHumanApproval(IdentityLink link) =>
        link.Confidence == IdentityConfidence.NeedsReview ||
        (link.Confidence == IdentityConfidence.HighConfidence && !link.IsConfirmed);
}
