using LeadPilot.Domain.Connections;

namespace LeadPilot.Application.Connections;

/// <summary>
/// قراردادِ Adapterِ هر اتصال. هر منبعِ واقعی (Search/Provider/LeadForm/…) یک Adapter دارد
/// که فقط با API رسمی و طبقِ ToS کار می‌کند. مطابق سند بخش ۳.
/// </summary>
public interface IConnectorAdapter
{
    string ConnectorCode { get; }
    Task<ConnectorTestResult> TestAsync(ConnectorRuntimeConfiguration configuration, CancellationToken cancellationToken);
}

public sealed record ConnectorRuntimeConfiguration(
    string ConnectorCode, string? BaseUrl, string? SecretValue,
    int TimeoutSeconds, int RequestsPerMinute, int MaximumConcurrency);

public sealed record ConnectorTestResult(
    ConnectorStatus Status, TimeSpan Latency, int? RemainingDailyQuota, string? ErrorCode, string? Message)
{
    public bool IsUsable => Status is ConnectorStatus.Healthy or ConnectorStatus.Degraded;
}
