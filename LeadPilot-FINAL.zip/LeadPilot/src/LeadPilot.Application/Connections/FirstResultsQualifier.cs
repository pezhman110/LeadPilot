namespace LeadPilot.Application.Connections;

/// <summary>
/// شرطِ شمارشِ «۱۰ شمارهٔ اول» (سند بخش ۱۱). یک شماره فقط وقتی معتبر است که
/// هر ۸ شرط برقرار باشد. موارد ساختگیِ AI/بدون‌منبع/تکراری/Suppressed/شرکتی‌برای‌شخصی شمرده نمی‌شوند.
/// </summary>
public sealed class FirstResultsQualifier
{
    public QualificationResult Qualify(ContactQualificationInput c)
    {
        var failed = new List<string>();

        if (!c.IsNormalized) failed.Add("استانداردسازی نشده");
        if (string.IsNullOrWhiteSpace(c.Hash)) failed.Add("Hash ساخته نشده");
        if (c.IsDuplicate) failed.Add("تکراری است");
        if (string.IsNullOrWhiteSpace(c.SourceReference)) failed.Add("منبع ثبت نشده");
        if (c.Classification == ContactClass.Unknown) failed.Add("نوع شخصی/شرکتی مشخص نیست");
        if (!c.ProjectRuleSatisfied) failed.Add("قانون پروژه رعایت نشده (مثلاً شرکتی برای مشتری شخصی)");
        if (string.IsNullOrWhiteSpace(c.MaskedValue)) failed.Add("ماسک نشده");
        if (!c.ContactRecordCreated) failed.Add("پرونده الکترونیکی ساخته نشده");

        // موارد ردِ صریحِ سند
        if (c.IsAiFabricated) failed.Add("دادهٔ ساختگی AI");
        if (c.IsSuppressed) failed.Add("Suppressed");
        if (c.IsExtractedFromDisallowedPersonalSource) failed.Add("شمارهٔ شخصیِ استخراج‌شده از منبع غیرمجاز");

        return new QualificationResult(failed.Count == 0, failed);
    }
}

public enum ContactClass { Unknown = 0, Corporate = 1, PublicBusiness = 2, PersonalSelfSubmitted = 3, PartnerSupplied = 4 }

public sealed record ContactQualificationInput(
    bool IsNormalized, string Hash, bool IsDuplicate, string SourceReference,
    ContactClass Classification, bool ProjectRuleSatisfied, string MaskedValue, bool ContactRecordCreated,
    bool IsAiFabricated, bool IsSuppressed, bool IsExtractedFromDisallowedPersonalSource);

public sealed record QualificationResult(bool IsQualified, IReadOnlyList<string> FailedConditions);
