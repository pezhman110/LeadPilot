using LeadPilot.Domain.Connections;

namespace LeadPilot.Application.Connections;

/// <summary>یک نمای سبک از وضعیت اتصال برای محاسبهٔ آمادگی (بدونِ وابستگی به دیتابیس).</summary>
public readonly record struct ConnectorReadinessSnapshot(
    string Code, ConnectorCategory Category, ConnectorStatus Status, bool IsCritical);

/// <summary>
/// منطقِ خالصِ گیتِ آمادگیِ شروع (سند بخش ۵/۱۴). قابل‌تست بدونِ دیتابیس.
/// قواعد:
///  • هر اتصالِ حیاتی که Healthy/Degraded نباشد → Blocking.
///  • هر اتصالِ غیرحیاتیِ غیرِ Healthy → Warning.
///  • اگر هیچ منبعِ کشفِ قابل‌استفاده‌ای نباشد → Blocking (NO_USABLE_DISCOVERY_SOURCE)،
///    چون بدونِ آن، «۱۰ نتیجهٔ اول» ممکن نیست.
/// </summary>
public static class StartupReadinessCalculator
{
    public static StartupReadinessResult Compute(IReadOnlyList<ConnectorReadinessSnapshot> connectors)
    {
        var blocking = connectors
            .Where(x => x.IsCritical && x.Status is not ConnectorStatus.Healthy and not ConnectorStatus.Degraded)
            .Select(x => x.Code)
            .ToList();

        var warnings = connectors
            .Where(x => !x.IsCritical && x.Status is not ConnectorStatus.Healthy)
            .Select(x => $"{x.Code}: {x.Status}")
            .ToArray();

        bool hasUsableDiscoverySource = connectors.Any(x =>
            (x.Category is ConnectorCategory.InternalData or ConnectorCategory.Search
                or ConnectorCategory.ContactProvider or ConnectorCategory.LeadForm)
            && x.Status is ConnectorStatus.Healthy or ConnectorStatus.Degraded);

        if (!hasUsableDiscoverySource)
            blocking.Add("NO_USABLE_DISCOVERY_SOURCE");

        return new StartupReadinessResult(
            CanStart: blocking.Count == 0,
            Healthy: connectors.Count(x => x.Status == ConnectorStatus.Healthy),
            Degraded: connectors.Count(x => x.Status == ConnectorStatus.Degraded),
            Failed: connectors.Count(x => x.Status is ConnectorStatus.AuthenticationFailed
                or ConnectorStatus.QuotaExceeded or ConnectorStatus.Unavailable),
            BlockingConnectors: blocking.Distinct().ToArray(),
            Warnings: warnings);
    }
}
