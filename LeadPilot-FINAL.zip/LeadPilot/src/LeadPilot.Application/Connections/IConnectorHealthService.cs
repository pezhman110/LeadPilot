namespace LeadPilot.Application.Connections;

/// <summary>سرویسِ مرکزیِ Health Check + گیتِ آمادگیِ شروع. مطابق سند بخش ۵.</summary>
public interface IConnectorHealthService
{
    Task<ConnectorHealthResponse> TestAsync(Guid connectorId, CancellationToken cancellationToken);
    Task<IReadOnlyList<ConnectorHealthResponse>> TestAllAsync(Guid tenantId, CancellationToken cancellationToken);
    Task<StartupReadinessResult> CheckStartupReadinessAsync(Guid tenantId, CancellationToken cancellationToken);
}

public sealed record ConnectorHealthResponse(
    Guid ConnectorId, string ConnectorCode, string DisplayName, string Status,
    bool IsUsable, bool IsCritical, long LatencyMilliseconds,
    int? RemainingDailyQuota, string? ErrorCode, string? Message, DateTimeOffset CheckedAtUtc);

public sealed record StartupReadinessResult(
    bool CanStart, int Healthy, int Degraded, int Failed,
    IReadOnlyList<string> BlockingConnectors, IReadOnlyList<string> Warnings);
