using LeadPilot.Domain.Consent;

namespace LeadPilot.Application.Consent;

/// <summary>قرارداد ذخیره‌سازیِ رضایت (پیاده‌سازی در Infrastructure).</summary>
public interface IConsentRepository
{
    Task AddContactAsync(ProtectedContactPoint cp, CancellationToken ct);
    Task<ProtectedContactPoint?> GetContactAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyList<ProtectedContactPoint>> ListByProspectAsync(Guid prospectId, CancellationToken ct);
    Task AddJourneyAsync(InvitationJourney j, CancellationToken ct);
    Task<InvitationJourney?> GetJourneyAsync(Guid id, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed record CreateContactRequest(Guid ProspectId, int Channel, string EncryptedValue,
    string Provider, string LawfulBasis, string CountryScope);
public sealed record ContactResponse(Guid Id, Guid ProspectId, string Channel, string Visibility,
    bool ManagerBlocked, string? ManagerBlockReason, string Provider);
public sealed record InviteRequest(Guid ProspectId, int Score, string Channel);
public sealed record JourneyResponse(Guid Id, Guid ProspectId, int Score, string State, string? Route, int FollowUpCount);

/// <summary>
/// سرویس رضایت: ذخیرهٔ تماس (Hidden)، دعوت opt-in، سه حاصل، آزادسازیِ خودکار،
/// و اختیارِ جلوگیریِ مدیر.
/// </summary>
public sealed class ConsentService(IConsentRepository repo)
{
    private const int SalesThreshold = 90; // نمرهٔ بالا → کارشناس

    public async Task<ContactResponse> AddContactAsync(CreateContactRequest r, CancellationToken ct)
    {
        var cp = new ProtectedContactPoint(r.ProspectId, (ContactChannel)r.Channel, r.EncryptedValue,
            r.Provider, r.LawfulBasis, r.CountryScope);
        await repo.AddContactAsync(cp, ct);
        await repo.SaveChangesAsync(ct);
        return Map(cp);
    }

    public async Task<IReadOnlyList<ContactResponse>> ListContactsAsync(Guid prospectId, CancellationToken ct) =>
        (await repo.ListByProspectAsync(prospectId, ct)).Select(Map).ToList();

    public async Task<JourneyResponse> InviteAsync(InviteRequest r, CancellationToken ct)
    {
        var j = new InvitationJourney(r.ProspectId, r.Score, r.Channel);
        await repo.AddJourneyAsync(j, ct);
        await repo.SaveChangesAsync(ct);
        return Map(j);
    }

    /// <summary>رضایت آمد → journey به Consented، و همهٔ تماس‌های آن prospect خودکار آزاد می‌شوند.</summary>
    public async Task<JourneyResponse?> ConsentAsync(Guid journeyId, CancellationToken ct)
    {
        var j = await repo.GetJourneyAsync(journeyId, ct);
        if (j is null) return null;
        j.Consented(SalesThreshold);
        foreach (var cp in await repo.ListByProspectAsync(j.ProspectId, ct))
            cp.MakeUsableAfterConsent(); // مدیرِ Block‌کرده override می‌شود
        await repo.SaveChangesAsync(ct);
        return Map(j);
    }

    public async Task<JourneyResponse?> DeclineAsync(Guid journeyId, CancellationToken ct)
    {
        var j = await repo.GetJourneyAsync(journeyId, ct);
        if (j is null) return null;
        j.Declined();
        foreach (var cp in await repo.ListByProspectAsync(j.ProspectId, ct)) cp.Suppress();
        await repo.SaveChangesAsync(ct);
        return Map(j);
    }

    public async Task<JourneyResponse?> NoResponseAsync(Guid journeyId, CancellationToken ct)
    {
        var j = await repo.GetJourneyAsync(journeyId, ct);
        if (j is null) return null;
        j.NoResponse();
        await repo.SaveChangesAsync(ct);
        return Map(j);
    }

    /// <summary>اختیارِ جلوگیریِ مدیر روی یک تماس.</summary>
    public async Task<ContactResponse?> ManagerBlockAsync(Guid contactId, string reason, CancellationToken ct)
    {
        var cp = await repo.GetContactAsync(contactId, ct);
        if (cp is null) return null;
        cp.ManagerBlock(reason);
        await repo.SaveChangesAsync(ct);
        return Map(cp);
    }
    public async Task<ContactResponse?> ManagerUnblockAsync(Guid contactId, CancellationToken ct)
    {
        var cp = await repo.GetContactAsync(contactId, ct);
        if (cp is null) return null;
        cp.ManagerUnblock();
        await repo.SaveChangesAsync(ct);
        return Map(cp);
    }

    private static ContactResponse Map(ProtectedContactPoint cp) => new(
        cp.Id, cp.ProspectId, cp.Channel.ToString(), cp.Visibility.ToString(),
        cp.ManagerBlocked, cp.ManagerBlockReason, cp.Provider);
    private static JourneyResponse Map(InvitationJourney j) => new(
        j.Id, j.ProspectId, j.Score, j.State.ToString(), j.Route?.ToString(), j.FollowUpCount);
}
