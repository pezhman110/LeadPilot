using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Projects;

namespace LeadPilot.Application.Projects;

// ── Contracts (DTOs) ────────────────────────────────────────────
public sealed record GeographyDto(string CountryCode, string? City, int Priority);

public sealed record CreateProjectRequest(
    string PersianName,
    string EnglishName,
    int CustomerType,
    decimal? MinimumBudgetAed,
    int MinimumSignalScore,
    int ManagerReviewScore,
    int SalesAssignmentScore,
    List<string> Languages,
    List<GeographyDto> Geographies);

public sealed record ProjectResponse(
    Guid Id,
    string PersianName,
    string EnglishName,
    int CustomerType,
    string Status,
    decimal? MinimumBudgetAed,
    int MinimumSignalScore,
    int ManagerReviewScore,
    int SalesAssignmentScore,
    IReadOnlyList<string> Languages,
    IReadOnlyList<GeographyDto> Geographies,
    DateTimeOffset CreatedAtUtc,
    DateTimeOffset? UpdatedAtUtc);

public static class ProjectMapping
{
    public static ProjectResponse ToResponse(this Project p) => new(
        p.Id, p.PersianName, p.EnglishName, (int)p.CustomerType, p.Status.ToString(),
        p.MinimumBudgetAed, p.MinimumSignalScore, p.ManagerReviewScore, p.SalesAssignmentScore,
        p.Languages.Select(l => l.Code).ToList(),
        p.Geographies.Select(g => new GeographyDto(g.CountryCode, g.City, g.Priority)).ToList(),
        p.CreatedAtUtc, p.UpdatedAtUtc);
}

// ── Application service ─────────────────────────────────────────
public sealed class ProjectService(IProjectRepository repository)
{
    public async Task<ProjectResponse> CreateAsync(CreateProjectRequest req, CancellationToken ct)
    {
        var project = new Project(
            req.PersianName,
            req.EnglishName,
            (CustomerType)req.CustomerType,
            req.MinimumBudgetAed,
            req.MinimumSignalScore,
            req.ManagerReviewScore,
            req.SalesAssignmentScore);

        foreach (var code in req.Languages ?? [])
            project.AddLanguage(code);
        foreach (var g in req.Geographies ?? [])
            project.AddGeography(g.CountryCode, g.City, g.Priority);

        await repository.AddAsync(project, ct);
        await repository.SaveChangesAsync(ct);
        return project.ToResponse();
    }

    public async Task<IReadOnlyList<ProjectResponse>> ListAsync(CancellationToken ct) =>
        (await repository.ListAsync(ct)).Select(p => p.ToResponse()).ToList();

    public async Task<ProjectResponse?> GetAsync(Guid id, CancellationToken ct) =>
        (await repository.GetAsync(id, ct))?.ToResponse();

    public async Task<ProjectResponse?> ActivateAsync(Guid id, CancellationToken ct)
    {
        var p = await repository.GetAsync(id, ct);
        if (p is null) return null;
        p.Activate();
        await repository.SaveChangesAsync(ct);
        return p.ToResponse();
    }

    public async Task<ProjectResponse?> PauseAsync(Guid id, CancellationToken ct)
    {
        var p = await repository.GetAsync(id, ct);
        if (p is null) return null;
        p.Pause();
        await repository.SaveChangesAsync(ct);
        return p.ToResponse();
    }
}
