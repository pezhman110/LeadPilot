using LeadPilot.Domain.Processing;

namespace LeadPilot.Application.Processing;

public interface IProcessingJobRepository
{
    Task<bool> EnqueueAsync(ProcessingJob job, CancellationToken ct);
    Task<IReadOnlyList<ProcessingJob>> ClaimBatchAsync(
        string workerId, IReadOnlyCollection<string> jobTypes, int batchSize,
        TimeSpan leaseDuration, CancellationToken ct);
    Task RenewLeaseAsync(Guid jobId, string workerId, TimeSpan leaseDuration, CancellationToken ct);
    Task CompleteAsync(Guid jobId, string workerId, CancellationToken ct);
    Task FailAsync(Guid jobId, string workerId, string errorCode, string error, bool isTransient, CancellationToken ct);
    Task<ProcessingSummary> GetSummaryAsync(CancellationToken ct);
}

public sealed record ProcessingSummary(
    int Pending, int Processing, int RetryScheduled, int CompletedToday,
    int DeadLetter, int OldestPendingAgeSeconds);

/// <summary>قرارداد Handlerها — هر نوع Job یک Handler دارد.</summary>
public interface IProcessingJobHandler
{
    string JobType { get; }
    Task<ProcessingJobExecutionResult> ExecuteAsync(ProcessingJob job, CancellationToken ct);
}

public sealed record ProcessingJobExecutionResult(
    bool Succeeded, bool IsTransientFailure, string? ErrorCode, string? ErrorMessage)
{
    public static ProcessingJobExecutionResult Success() => new(true, false, null, null);
    public static ProcessingJobExecutionResult TransientFailure(string code, string msg) => new(false, true, code, msg);
    public static ProcessingJobExecutionResult PermanentFailure(string code, string msg) => new(false, false, code, msg);
}

/// <summary>محاسبهٔ فاصلهٔ Retry فزاینده (مطابق سند).</summary>
public static class RetryPolicy
{
    private static readonly int[] DelaysSeconds = [15, 60, 300, 900, 1800, 3600];
    public static TimeSpan CalculateDelay(int attemptCount)
    {
        int index = Math.Clamp(attemptCount - 1, 0, DelaysSeconds.Length - 1);
        double jitter = Random.Shared.NextDouble() * 10;
        return TimeSpan.FromSeconds(DelaysSeconds[index] + jitter);
    }
}
