using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Application.Search;

/// <summary>
/// از تعریف پروژه (خوشه‌های نیت + جغرافیا) برای هر زبانِ فعال یک Query می‌سازد.
/// شش زبان: ar, en, fa, hi, fr, ru.
/// </summary>
public sealed class QueryBuilder : IQueryBuilder
{
    private static readonly Dictionary<string, string> IntentByLang = new()
    {
        ["en"] = "looking to invest buy business Dubai",
        ["ar"] = "أبحث عن استثمار شراء مشروع دبي",
        ["fa"] = "دنبال سرمایه گذاری خرید کسب و کار دبی",
        ["hi"] = "Dubai business invest karna chahta hoon",
        ["fr"] = "chercher investir acheter entreprise Dubai",
        ["ru"] = "инвестировать купить бизнес Дубай"
    };

    public IReadOnlyList<(string LanguageCode, string Query)> Build(Project project)
    {
        var result = new List<(string, string)>();
        var geo = project.Geographies.OrderBy(g => g.Priority)
            .Select(g => g.City ?? g.CountryCode).FirstOrDefault() ?? "Dubai";

        foreach (var lang in project.Languages.Select(l => l.Code))
        {
            var baseQuery = IntentByLang.TryGetValue(lang, out var q) ? q : IntentByLang["en"];
            result.Add((lang, $"{baseQuery} {geo}".Trim()));
        }
        return result;
    }
}

public sealed class LanguageDetector : ILanguageDetector
{
    public DetectedLanguage Detect(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return DetectedLanguage.Unknown;
        bool ar = text.Any(c => c >= '\u0600' && c <= '\u06FF');
        bool fa = text.Any(c => c is 'پ' or 'چ' or 'ژ' or 'گ' or 'ک' or 'ی');
        bool hi = text.Any(c => c >= '\u0900' && c <= '\u097F');
        bool ru = text.Any(c => c >= '\u0400' && c <= '\u04FF');
        bool la = text.Any(c => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z');
        if (hi) return DetectedLanguage.Hindi;
        if (ru) return DetectedLanguage.Russian;
        if (ar) return fa ? DetectedLanguage.Persian : DetectedLanguage.Arabic;
        if (la) return DetectedLanguage.English;
        return DetectedLanguage.Unknown;
    }
}
