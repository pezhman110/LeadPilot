using System.Collections.Concurrent;
using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Common;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Application.Search;

/// <summary>
/// ارکستراتور جست‌وجو (فاز دو). موارد ۴ تا ۱۰ سند را پیاده می‌کند:
///   • اجرای موازی Connectorها
///   • ذخیرهٔ نتیجهٔ خام + انتشار زنده
///   • ثبت URL/زمان/منبع/Query
///   • جلوگیری از نتیجهٔ تکراری (dedup در سطح اجرا)
///   • توقف/ادامه
///   • Rate Limit هر منبع
/// هر سیگنال قبل از امتیازدهی از ComplianceGateway رد می‌شود.
/// </summary>
public sealed class SearchOrchestrator
{
    private readonly IEnumerable<ISignalConnector> _connectors;
    private readonly IQueryBuilder _queryBuilder;
    private readonly IComplianceGateway _gateway;
    private readonly IScoringEngine _scorer;
    private readonly ILanguageDetector _lang;
    private readonly ISignalRepository _signals;
    private readonly ISearchRunRepository _runs;
    private readonly ILiveNotifier _notifier;

    public SearchOrchestrator(
        IEnumerable<ISignalConnector> connectors, IQueryBuilder queryBuilder,
        IComplianceGateway gateway, IScoringEngine scorer, ILanguageDetector lang,
        ISignalRepository signals, ISearchRunRepository runs, ILiveNotifier notifier)
    {
        _connectors = connectors; _queryBuilder = queryBuilder; _gateway = gateway;
        _scorer = scorer; _lang = lang; _signals = signals; _runs = runs; _notifier = notifier;
    }

    public async Task<Guid> RunAsync(Project project, Func<bool>? isPausedCheck, CancellationToken ct)
    {
        var run = new SearchRun(project.Id);
        await _runs.AddAsync(run, ct);
        await _runs.SaveChangesAsync(ct);
        await _notifier.RunStatusAsync(run);

        var queries = _queryBuilder.Build(project);
        var seen = new ConcurrentDictionary<string, byte>(); // dedup در سطح اجرا
        var lastHit = new ConcurrentDictionary<string, DateTimeOffset>(); // rate limit هر منبع

        // اجرای موازیِ Connectorها؛ هر Connector × هر Query.
        var tasks = new List<Task>();
        foreach (var connector in _connectors)
        {
            foreach (var (langCode, query) in queries)
            {
                tasks.Add(ProcessConnectorQueryAsync(
                    connector, langCode, query, project, run, seen, lastHit, isPausedCheck, ct));
            }
        }
        try { await Task.WhenAll(tasks); run.Complete(); }
        catch (OperationCanceledException) { run.Fail(); }
        catch { run.Fail(); }

        await _runs.SaveChangesAsync(ct);
        await _notifier.RunStatusAsync(run);
        return run.Id;
    }

    private async Task ProcessConnectorQueryAsync(
        ISignalConnector connector, string langCode, string query, Project project, SearchRun run,
        ConcurrentDictionary<string, byte> seen, ConcurrentDictionary<string, DateTimeOffset> lastHit,
        Func<bool>? isPausedCheck, CancellationToken ct)
    {
        run.CountQuery();
        var ctx = new SearchContext(run.Id, project.Id, query, langCode);

        await foreach (var raw in connector.FetchAsync(project, ctx, ct))
        {
            ct.ThrowIfCancellationRequested();

            // توقف/ادامه: اگر Pause فعال است، منتظر بمان.
            while (isPausedCheck?.Invoke() == true)
                await Task.Delay(300, ct);

            // Rate Limit هر منبع.
            if (lastHit.TryGetValue(connector.Name, out var prev))
            {
                var wait = connector.MinRequestInterval - (DateTimeOffset.UtcNow - prev);
                if (wait > TimeSpan.Zero) await Task.Delay(wait, ct);
            }
            lastHit[connector.Name] = DateTimeOffset.UtcNow;

            run.CountFound();
            raw.Language = _lang.Detect(raw.OriginalText);

            // جلوگیری از نتیجهٔ تکراری.
            if (!seen.TryAdd(raw.DedupeKey(), 1)) { run.CountDuplicate(); continue; }

            // Compliance gate.
            var decision = _gateway.Evaluate(raw, project);
            if (decision.Status == ComplianceStatus.Blocked) { run.CountBlocked(); continue; }

            // امتیازدهی + ذخیره + انتشار زنده.
            var normalized = _scorer.Score(raw, project, decision);
            await _signals.AddNormalizedAsync(normalized, ct);
            await _signals.SaveChangesAsync(ct);
            run.CountProcessed();
            await _notifier.SignalProcessedAsync(normalized);
        }
    }
}
