namespace LeadPilot.Application.Security;

/// <summary>
/// درگاهِ خواندنِ Secret با نام (SecretReference). مطابق سند بخش ۴.
/// در Production با Azure Key Vault / AWS Secrets Manager / HashiCorp Vault / Docker Secrets جایگزین می‌شود.
/// </summary>
public interface ISecretStore
{
    Task<string?> GetAsync(string secretReference, CancellationToken cancellationToken);
}
