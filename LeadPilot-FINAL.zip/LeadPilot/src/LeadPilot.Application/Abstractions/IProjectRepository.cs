using LeadPilot.Domain.Projects;

namespace LeadPilot.Application.Abstractions;

public interface IProjectRepository
{
    Task<Project?> GetAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyList<Project>> ListAsync(CancellationToken ct);
    Task AddAsync(Project project, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}
