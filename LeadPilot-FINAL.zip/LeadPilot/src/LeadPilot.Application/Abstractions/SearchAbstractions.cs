using LeadPilot.Domain.Common;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Application.Abstractions;

/// <summary>یک Connector فقط از منابع مجاز می‌خواند؛ scrape خصوصی/enrichment بدون مبنا ممنوع.</summary>
public interface ISignalConnector
{
    string Name { get; }
    bool IsDemo { get; }
    /// <summary>حداکثر درخواست در دقیقه (Rate Limit هر منبع).</summary>
    int RatePerMinute { get; }
    IAsyncEnumerable<ConnectorHit> FetchAsync(ProjectSearchProfile profile, SearchContext ctx, CancellationToken ct);
}

public sealed record SearchContext(Guid SearchRunId, string Query, string LanguageCode);
public sealed record ConnectorHit(string SourceUrl, SourceType SourceType, string Text);

public interface IComplianceGateway
{
    ComplianceDecision Evaluate(RawSignal signal, ProjectSearchProfile profile);
}
public sealed record ComplianceDecision(ComplianceStatus Status, string Reason, int ComplianceScore);

public interface IScoringEngine
{
    Signal Score(RawSignal raw, ProjectSearchProfile profile, ComplianceDecision compliance);
}

public interface ILanguageDetector { DetectedLanguage Detect(string text); }

/// <summary>ساختِ Query برای شش زبان از پروفایل جست‌وجو.</summary>
public interface IQueryBuilder
{
    IReadOnlyList<SearchQuery> Build(ProjectSearchProfile profile);
}
public sealed record SearchQuery(string LanguageCode, string Text);

/// <summary>انتشار زندهٔ پیشرفت (Blazor از IProgress استفاده می‌کند؛ SignalR برای کلاینت‌های دیگر).</summary>
public interface ILiveNotifier
{
    Task SignalAsync(Signal signal);
    Task StatusAsync(Guid runId, string status, int queries, int found, int duplicates, int blocked, int processed);
}

public interface ISearchRunRepository
{
    Task AddAsync(SearchRun run, CancellationToken ct);
    Task UpdateAsync(SearchRun run, CancellationToken ct);
    Task<SearchRun?> GetAsync(Guid id, CancellationToken ct);
}

public interface ISignalRepository
{
    Task AddRawAsync(RawSignal raw, CancellationToken ct);
    Task AddSignalAsync(Signal signal, CancellationToken ct);
    Task<bool> ExistsByHashAsync(Guid projectId, string dedupHash, CancellationToken ct);
    Task<IReadOnlyList<Signal>> ListByProjectAsync(Guid projectId, CancellationToken ct);
}
