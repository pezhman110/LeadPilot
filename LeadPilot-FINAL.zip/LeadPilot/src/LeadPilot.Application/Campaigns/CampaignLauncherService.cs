using LeadPilot.Domain.Campaigns;

namespace LeadPilot.Application.Campaigns;

/// <summary>
/// «موتورِ پشتِ دکمه». با انتخابِ زمینه (هتل/برج/مال/…) + شهر + بودجه، یک مسیرِ کاملِ آمادهٔ اجرا
/// می‌سازد: تاکتیک‌های پیش‌فرضِ همان زمینه + گام‌های استانداردِ رضایت‌محور. هدف: کاربر فقط سه‌چیز
/// می‌دهد (زمینه، شهر، سقفِ هزینه)، و بقیهٔ برنامه‌ریزی خودکار پشتِ همان یک دکمه انجام می‌شود —
/// نه ۷۰ فرمِ تودرتو.
/// </summary>
public sealed class CampaignLauncherService
{
    /// <summary>تاکتیک‌های پیش‌فرضِ هر زمینه (نسخهٔ قانونیِ ۳۵ روش).</summary>
    public static IReadOnlyList<LaunchTactic> DefaultTactics(CampaignContext context) => context switch
    {
        CampaignContext.Hotels =>
            [LaunchTactic.ContextualAds, LaunchTactic.QrNfcOptIn, LaunchTactic.PartnerReferral, LaunchTactic.LandingLeadForm],
        CampaignContext.ResidentialTowers =>
            [LaunchTactic.PartnerReferral, LaunchTactic.CommunityTransparentPost, LaunchTactic.QrNfcOptIn, LaunchTactic.SurveyLotteryOptIn, LaunchTactic.LandingLeadForm],
        CampaignContext.Malls =>
            [LaunchTactic.ContextualAds, LaunchTactic.LoyaltyRewardCoupon, LaunchTactic.QrNfcOptIn, LaunchTactic.LandingLeadForm],
        CampaignContext.Investment =>
            [LaunchTactic.B2bCompanyEnrichment, LaunchTactic.CommunityTransparentPost, LaunchTactic.ContextualAds, LaunchTactic.LandingLeadForm],
        CampaignContext.Salon =>
            [LaunchTactic.ContextualAds, LaunchTactic.CommunityTransparentPost, LaunchTactic.SurveyLotteryOptIn, LaunchTactic.LandingLeadForm],
        CampaignContext.HomeService =>
            [LaunchTactic.PartnerReferral, LaunchTactic.CommunityTransparentPost, LaunchTactic.NewsletterCtaAd, LaunchTactic.LandingLeadForm],
        _ => [LaunchTactic.LandingLeadForm]
    };

    /// <summary>مسیرِ استانداردِ رضایت‌محور که پشتِ هر دکمه اجرا می‌شود (سند).</summary>
    private static readonly string[] StandardPipeline =
    [
        "SelectApprovedSources",   // منابعِ تأییدشدهٔ همان زمینه/شهر
        "RunTacticsToLanding",     // اجرای تاکتیک‌ها → همه به لندینگِ رسمی
        "VoluntaryOptIn",          // مخاطب خودش تماس را می‌دهد
        "CaptureConsentEvidence",  // ثبتِ مدرکِ رضایت
        "AssignToSpecialist",      // تخصیص به کارشناس
        "SyncToCrm"                // HubSpot/Zoho
    ];

    public LaunchPlan BuildPlan(CampaignPreset preset)
    {
        // گاردِ تاکتیکِ ممنوع: اگر تاکتیکی خارج از enumِ مجاز درخواست شده باشد، اصلاً نمی‌تواند
        // اینجا برسد چون enum فقط تاکتیک‌های قانونی را تعریف می‌کند. مسیر همیشه به لندینگ/opt-in ختم می‌شود.
        var steps = new List<LaunchStep>();
        int order = 1;
        foreach (var t in preset.Tactics)
            steps.Add(new LaunchStep(order++, "Tactic:" + t, TacticNote(t)));
        foreach (var s in StandardPipeline)
            steps.Add(new LaunchStep(order++, s, null));

        return new LaunchPlan(preset.Context, preset.City, preset.MonthlyBudgetUsd,
            preset.MaxCostPerLeadUsd, steps);
    }

    private static string TacticNote(LaunchTactic t) => t switch
    {
        LaunchTactic.ContextualAds => "تبلیغِ مرتبط، نه شناساییِ بازدیدکننده.",
        LaunchTactic.QrNfcOptIn => "QR/NFC → لندینگ → opt-in داوطلبانه.",
        LaunchTactic.LoyaltyRewardCoupon => "برنامهٔ وفاداریِ رسمی.",
        LaunchTactic.SurveyLotteryOptIn => "ارائهٔ داوطلبانهٔ تماس با پاداش.",
        LaunchTactic.PartnerReferral => "ارجاعِ رسمی با رضایتِ همان کانال.",
        LaunchTactic.CommunityTransparentPost => "پاسخِ شفافِ کارشناس (نه حساب جعلی).",
        LaunchTactic.NewsletterCtaAd => "فضای CTA اجاره‌ای در خبرنامه.",
        LaunchTactic.B2bCompanyEnrichment => "سطحِ شرکت؛ Provider تأییدشده + رضایت.",
        LaunchTactic.LandingLeadForm => "فرمِ رضایتِ رسمی با رضایتِ مجزای هر کانال.",
        _ => ""
    };
}

public sealed record LaunchStep(int Order, string Key, string? Note);
public sealed record LaunchPlan(CampaignContext Context, string City, decimal MonthlyBudgetUsd,
    decimal MaxCostPerLeadUsd, IReadOnlyList<LaunchStep> Steps);
