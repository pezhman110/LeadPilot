using LeadPilot.Domain.Dedup;

namespace LeadPilot.Application.Dedup;

public interface IDeduplicationRepository
{
    Task<ContactRecord?> FindByHashAsync(Guid tenantId, ContactType type, string hash, CancellationToken ct);
    Task AddAsync(ContactRecord record, CancellationToken ct);
    Task<bool> ReservationExistsAsync(string key, CancellationToken ct);
    Task AddReservationAsync(EnrichmentReservation r, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed record DedupResult(bool IsNew, Guid ContactRecordId, string Reason);

/// <summary>
/// سرویسِ جلوگیری از دریافت/پرداختِ مجدد. مطابق سند:
/// قبل از خرید، hash بررسی می‌شود؛ اگر موجود بود فقط Observation ثبت می‌شود
/// و خریدِ دوباره انجام نمی‌شود؛ اگر جدید بود، پرونده ساخته می‌شود.
/// </summary>
public sealed class DeduplicationService(IDeduplicationRepository repo, byte[] hashKey)
{
    /// <summary>
    /// ثبتِ یک شمارهٔ کشف‌شده. اگر تکراری بود، Observation جدید (بدون خرید مجدد).
    /// </summary>
    public async Task<DedupResult> RegisterAsync(Guid tenantId, ContactType type, string rawValue, string source, CancellationToken ct)
    {
        var hash = ContactNormalizer.Hash(type, rawValue, hashKey);
        var existing = await repo.FindByHashAsync(tenantId, type, hash, ct);
        if (existing is not null)
        {
            existing.AddObservation(source); // فقط مشاهده؛ نه ContactPoint جدید، نه خرید مجدد
            await repo.SaveChangesAsync(ct);
            return new DedupResult(false, existing.Id, "تکراری — مشاهدهٔ جدید ثبت شد، خرید مجدد نشد.");
        }
        var record = new ContactRecord(tenantId, type, hash, source);
        await repo.AddAsync(record, ct);
        await repo.SaveChangesAsync(ct);
        return new DedupResult(true, record.Id, "جدید — پرونده ساخته شد.");
    }

    /// <summary>
    /// آیا اجازهٔ خرید از Provider هست؟ اگر رزرو قبلاً وجود دارد، خیر (جلوگیری از پرداخت دوباره).
    /// </summary>
    public async Task<bool> TryReserveEnrichmentAsync(Guid prospectId, string providerCode, string purpose, CancellationToken ct)
    {
        var reservation = new EnrichmentReservation(prospectId, providerCode, purpose);
        if (await repo.ReservationExistsAsync(reservation.Key, ct))
            return false; // Worker دیگری همین را رزرو کرده
        await repo.AddReservationAsync(reservation, ct);
        await repo.SaveChangesAsync(ct);
        return true;
    }
}
