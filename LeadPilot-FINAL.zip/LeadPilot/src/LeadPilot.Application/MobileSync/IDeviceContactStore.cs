namespace LeadPilot.Application.MobileSync;

/// <summary>
/// درگاهِ ذخیره روی موبایلِ کاری (Adapter). پیاده‌سازیِ واقعی به سرویس/اپ موبایل وصل می‌شود.
/// LeadPilot فقط ارکستراسیون می‌کند؛ خودِ ذخیره روی دستگاه بیرون از این هسته است.
/// </summary>
public interface IDeviceContactStore
{
    Task<string> UpsertAsync(string deviceLabel, string displayName, string phoneOrEmail, CancellationToken ct);
    Task RemoveAsync(string deviceLabel, string deviceContactRef, CancellationToken ct);
}
