using LeadPilot.Domain.Discovery;

namespace LeadPilot.Application.Discovery;

/// <summary>
/// حاکمیتِ enrichment: یک تصمیمِ واحد که سه شرط را با هم اعمال می‌کند —
///  (۱) Provider باید تأییدِ Enrichment داشته باشد (ProviderApproval)،
///  (۲) گاردِ دادهٔ سازمانی/شخصی باید اجازه دهد (DataClassGuard)،
///  (۳) برای هر تماسِ شخصی، رضایتِ اثبات‌شده لازم است.
/// این یعنی Apollo/Lusha/ZoomInfo می‌توانند دادهٔ سطحِ شرکت را غنی کنند، ولی «جیمیلِ شخصی →
/// موبایلِ بدونِ رضایت» و هویت‌یابیِ مخفی از Cookie/Fingerprint هرگز از اینجا نمی‌گذرد.
/// </summary>
public sealed class EnrichmentGovernanceService
{
    public EnrichmentDecision Evaluate(
        ProviderApproval approval, DataFieldKind sourceField, DataFieldKind targetField, bool hasProvenConsent)
    {
        if (!approval.CanEnrich)
            return new EnrichmentDecision(false, "PROVIDER_NOT_APPROVED",
                $"{approval.Provider} تأییدِ Enrichment ندارد (وضعیت: {approval.State}).");

        var guard = DataClassGuard.EvaluateEnrichment(sourceField, targetField, hasProvenConsent);
        if (!guard.Allowed)
            return new EnrichmentDecision(false, "DATA_CLASS_BLOCKED", guard.Reason);

        var targetClass = DataClassGuard.Classify(targetField);
        return new EnrichmentDecision(true,
            targetClass == DataClass.Company ? "COMPANY_ENRICHMENT_OK" : "CONSENTED_PERSONAL_OK",
            targetClass == DataClass.Company
                ? "غنی‌سازیِ سطحِ شرکت مجاز است."
                : "غنی‌سازیِ دادهٔ شخصیِ دارای رضایتِ اثبات‌شده مجاز است.");
    }
}

public sealed record EnrichmentDecision(bool Allowed, string Code, string Reason);
