using LeadPilot.Domain.Discovery;

namespace LeadPilot.Application.Discovery;

/// <summary>ردهٔ داده: سازمانی (B2B) در برابرِ شخصی.</summary>
public enum DataClass { Company = 0, Personal = 1 }

/// <summary>نوعِ فیلد برای طبقه‌بندی.</summary>
public enum DataFieldKind
{
    CompanyName, CompanyDomain, Industry, CompanySize, CompanyLocation, BusinessRole, CompanyIntent,
    PersonalEmail, PersonalPhone, CrossPlatformIdentity, BrowsingHistory, MobileAdvertisingId, CookieIdentity
}

/// <summary>
/// گاردِ سند: دادهٔ سازمانی برای B2B مجاز؛ دادهٔ شخصی کنترلِ سخت دارد. LeadPilot هرگز
/// «تبدیلِ Gmail شخصی به تلفن»، جست‌وجوی فردی برای کشفِ تماس، یا استفاده از داده‌های اپراتور/
/// کوکیِ شخصِ ثالث بدونِ رضایت را انجام نمی‌دهد. Intent در سطحِ شرکت/تجمیعی معنا دارد، نه مدرکِ
/// قطعیِ علاقهٔ یک فردِ خاص.
/// </summary>
public static class DataClassGuard
{
    public static DataClass Classify(DataFieldKind field) => field switch
    {
        DataFieldKind.PersonalEmail or DataFieldKind.PersonalPhone or DataFieldKind.CrossPlatformIdentity
            or DataFieldKind.BrowsingHistory or DataFieldKind.MobileAdvertisingId or DataFieldKind.CookieIdentity
            => DataClass.Personal,
        _ => DataClass.Company
    };

    /// <summary>آیا این عملیاتِ enrichment مجاز است؟</summary>
    public static GuardDecision EvaluateEnrichment(DataFieldKind sourceField, DataFieldKind targetField, bool hasProvenConsent)
    {
        // تبدیلِ هرگونه دادهٔ شخصی به تماسِ شخصیِ دیگر بدونِ رضایتِ اثبات‌شده → رد.
        bool targetIsPersonalContact = targetField is DataFieldKind.PersonalEmail or DataFieldKind.PersonalPhone;
        if (targetIsPersonalContact && !hasProvenConsent)
            return new GuardDecision(false, "تبدیلِ خودکار به تماسِ شخصی بدونِ رضایتِ اثبات‌شده مجاز نیست (مثلِ Gmail→تلفن).");

        // هویتِ چندپلتفرمی/کوکی/شناسهٔ تبلیغاتی به‌عنوان کشفِ تماسِ شخصی → همیشه رد.
        if (sourceField is DataFieldKind.CrossPlatformIdentity or DataFieldKind.CookieIdentity
            or DataFieldKind.MobileAdvertisingId or DataFieldKind.BrowsingHistory && targetIsPersonalContact)
            return new GuardDecision(false, "کشفِ تماسِ شخصی از هویتِ دیجیتال/کوکی/مرور مجاز نیست.");

        return new GuardDecision(true, "داده‌ی سازمانی یا دارای رضایت — مجاز.");
    }

    /// <summary>Intent در سطح فرد نمایش داده نشود؛ فقط سطحِ شرکت/تجمیعی.</summary>
    public static bool IsIntentUsableAsPersonProof() => false;
}

public sealed record GuardDecision(bool Allowed, string Reason);
