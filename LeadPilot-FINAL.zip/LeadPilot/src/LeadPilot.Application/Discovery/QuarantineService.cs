using LeadPilot.Domain.Discovery;

namespace LeadPilot.Application.Discovery;

/// <summary>
/// خطِ قرنطینهٔ Import را اجرا می‌کند (سند). هیچ رکوردی بدونِ منبع/منشأ/رضایتِ معتبر و بدونِ
/// عبور از بازبینیِ انسانی، Approved نمی‌شود.
/// </summary>
public sealed class QuarantineService
{
    public QuarantineStage RunPipeline(ImportRecord r, bool sourceValid, bool isDuplicate, bool humanApproved)
    {
        r.Advance(QuarantineStage.SourceValidation);
        if (!sourceValid) { r.Reject("منبع نامعتبر."); return r.Stage; }

        r.Advance(QuarantineStage.ProvenanceValidation);
        if (!r.HasProvenance) { r.Quarantine("منشأ (Provenance) ثبت نشده."); return r.Stage; }

        r.Advance(QuarantineStage.ConsentClassification);
        if (!r.HasConsentEvidence) { r.Quarantine("مدرکِ رضایت وجود ندارد."); return r.Stage; }

        r.Advance(QuarantineStage.Deduplication);
        if (isDuplicate) { r.MarkDuplicate(); r.Reject("تکراری."); return r.Stage; }

        r.Advance(QuarantineStage.HumanReview);
        if (!humanApproved) { r.Quarantine("در انتظارِ بازبینیِ انسانی."); return r.Stage; }

        r.Approve();
        return r.Stage;
    }
}
