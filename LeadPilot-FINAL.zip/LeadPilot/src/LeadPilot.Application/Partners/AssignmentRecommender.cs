using LeadPilot.Domain.Partners;

namespace LeadPilot.Application.Partners;

/// <summary>
/// پیشنهادِ «بهتر است این لید به چه همکاری داده شود».
/// معیارها: تطبیق زبان، تطبیق طبقهٔ مبلغ با توانمندی، و نمرهٔ عملکردِ قبلی.
/// خروجی: فهرست مرتب‌شدهٔ همکاران با دلیلِ هر امتیاز (قابل‌توضیح).
/// </summary>
public sealed class AssignmentRecommender
{
    public IReadOnlyList<PartnerMatch> Recommend(LeadContext lead, IReadOnlyList<Partner> partners)
    {
        var matches = new List<PartnerMatch>();

        foreach (var p in partners.Where(x => x.IsActive))
        {
            int score = 0;
            var reasons = new List<string>();

            // 1) زبان — اگر لید کاور نشده، فقط AI؛ در غیر این‌صورت تطبیق زبان مهم است.
            bool langMatch = p.Languages.Contains(lead.LanguageCode.ToLowerInvariant());
            if (langMatch) { score += 30; reasons.Add($"زبان {lead.LanguageCode} را پوشش می‌دهد (+30)"); }
            else reasons.Add($"زبان {lead.LanguageCode} را ندارد (0)");

            // 2) توانمندی متناسب با طبقهٔ مبلغ.
            var neededSkill = SkillForTier(lead.Tier);
            if (neededSkill is not null && p.Skills.Contains(neededSkill))
            { score += 25; reasons.Add($"توانمندیِ «{neededSkill}» را دارد (+25)"); }

            // 3) نمرهٔ عملکردِ قبلی (وزن ۴۵٪).
            int perf = (int)Math.Round(p.PerformanceScore * 0.45);
            score += perf; reasons.Add($"نمرهٔ عملکردِ قبلی {p.PerformanceScore} → +{perf}");

            // 4) طبقهٔ بالا (High/Purchase/Sale) نیازمند نمرهٔ بالاست.
            if (lead.Tier is DealTier.InvestmentHigh or DealTier.Purchase or DealTier.BusinessSale
                && p.PerformanceScore < 80)
            { score -= 20; reasons.Add("طبقهٔ بزرگ اما نمرهٔ همکار زیر ۸۰ (−۲۰)"); }

            matches.Add(new PartnerMatch(p.Id, p.FullName, Math.Max(0, Math.Min(100, score)), reasons));
        }

        return matches.OrderByDescending(m => m.MatchScore).ToList();
    }

    private static string? SkillForTier(DealTier tier) => tier switch
    {
        DealTier.InvestmentLow or DealTier.InvestmentMid or DealTier.InvestmentHigh => "investment",
        DealTier.Purchase => "acquisition",
        DealTier.BusinessSale => "business-sale",
        _ => null
    };
}

public sealed record LeadContext(string LanguageCode, DealTier Tier, int LeadScore);
public sealed record PartnerMatch(Guid PartnerId, string PartnerName, int MatchScore, IReadOnlyList<string> Reasons);
