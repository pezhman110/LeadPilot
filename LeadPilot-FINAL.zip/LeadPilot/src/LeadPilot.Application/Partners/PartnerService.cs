using LeadPilot.Domain.Partners;

namespace LeadPilot.Application.Partners;

public interface IPartnerRepository
{
    Task AddAsync(Partner p, CancellationToken ct);
    Task<Partner?> GetAsync(Guid id, CancellationToken ct);
    Task<IReadOnlyList<Partner>> ListAsync(CancellationToken ct);
    Task AddAgreementAsync(PartnerAgreement a, CancellationToken ct);
    Task<PartnerAgreement?> GetAgreementAsync(Guid id, CancellationToken ct);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed record CreatePartnerRequest(string FullName, int Type, int PerformanceScore,
    List<string> Languages, List<string> Skills);
public sealed record PartnerResponse(Guid Id, string FullName, string Type, int PerformanceScore,
    IReadOnlyCollection<string> Languages, IReadOnlyCollection<string> Skills, bool IsActive);
public sealed record RecommendRequest(string LanguageCode, int DealKind, decimal AmountAed, int LeadScore);
public sealed record CreateAgreementRequest(Guid PartnerId, decimal CommissionPercent, decimal? BonusAed, string Terms);
public sealed record ApproveAgreementRequest(string ManagerName, string ContractRef);

public sealed class PartnerService(IPartnerRepository repo)
{
    private readonly AssignmentRecommender _recommender = new();

    public async Task<PartnerResponse> CreateAsync(CreatePartnerRequest r, CancellationToken ct)
    {
        var p = new Partner(r.FullName, (PartnerType)r.Type, r.PerformanceScore);
        foreach (var l in r.Languages ?? []) p.AddLanguage(l);
        foreach (var s in r.Skills ?? []) p.AddSkill(s);
        await repo.AddAsync(p, ct);
        await repo.SaveChangesAsync(ct);
        return Map(p);
    }

    public async Task<IReadOnlyList<PartnerResponse>> ListAsync(CancellationToken ct) =>
        (await repo.ListAsync(ct)).Select(Map).ToList();

    /// <summary>«این لید به چه همکاری برسد» — با طبقه‌بندیِ مبلغ و پیشنهادِ قابل‌توضیح.</summary>
    public async Task<IReadOnlyList<PartnerMatch>> RecommendAsync(RecommendRequest r, CancellationToken ct)
    {
        var tier = DealClassifier.Classify((DealKind)r.DealKind, r.AmountAed);
        var lead = new LeadContext(r.LanguageCode, tier, r.LeadScore);
        var partners = await repo.ListAsync(ct);
        return _recommender.Recommend(lead, partners);
    }

    public async Task<Guid> CreateAgreementAsync(CreateAgreementRequest r, CancellationToken ct)
    {
        var a = new PartnerAgreement(r.PartnerId, r.CommissionPercent, r.Terms);
        if (r.BonusAed.HasValue) a.SetBonus(r.BonusAed.Value);
        await repo.AddAgreementAsync(a, ct);
        await repo.SaveChangesAsync(ct);
        return a.Id;
    }

    /// <summary>فعال‌سازیِ توافق فقط با تأیید مدیر + ارجاع قرارداد (Audit).</summary>
    public async Task<bool> ApproveAgreementAsync(Guid agreementId, ApproveAgreementRequest r, CancellationToken ct)
    {
        var a = await repo.GetAgreementAsync(agreementId, ct);
        if (a is null) return false;
        a.Activate(r.ManagerName, r.ContractRef);
        await repo.SaveChangesAsync(ct);
        return true;
    }

    private static PartnerResponse Map(Partner p) => new(
        p.Id, p.FullName, p.Type.ToString(), p.PerformanceScore, p.Languages, p.Skills, p.IsActive);
}
