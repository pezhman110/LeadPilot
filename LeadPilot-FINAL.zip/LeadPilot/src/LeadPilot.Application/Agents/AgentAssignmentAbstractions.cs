using LeadPilot.Domain.Agents;

namespace LeadPilot.Application.Agents;

public interface IAgentAssignmentStore
{
    Task<AgentProfile?> GetAgentAsync(Guid agentProfileId, CancellationToken ct);
    Task<ContactAssignment?> GetActiveAssignmentAsync(Guid contactPointId, CancellationToken ct);
    Task AddAssignmentAsync(ContactAssignment assignment, CancellationToken ct);
    Task SaveAsync(CancellationToken ct);
    Task<IReadOnlyList<ContactAssignment>> QueryAgentAssignmentsAsync(
        Guid agentProfileId, bool? hasAccount, bool? hasEmail, bool? hasPhone, bool activeOnly, CancellationToken ct);
}

public sealed record AssignmentResult(bool Ok, Guid? AssignmentId, string? Reason);
