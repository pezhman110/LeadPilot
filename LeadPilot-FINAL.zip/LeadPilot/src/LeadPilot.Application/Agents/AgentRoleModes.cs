using LeadPilot.Application.Communications;

namespace LeadPilot.Application.Agents;

/// <summary>نقشِ کارشناس؛ حالت‌های ارتباطیِ مجاز از آن مشتق می‌شوند (سند).</summary>
public enum AgentRole { JuniorSales = 0, SeniorSales = 1, Supervisor = 2, Administrator = 3 }

public static class AgentRolePolicy
{
    /// <summary>
    /// Junior: فقط دستی. Senior: دستی + کمک‌یارِ هوشمند. Supervisor: + اتوماسیونِ تأییدشده.
    /// Administrator: همه + دسترسیِ پیکربندی.
    /// </summary>
    public static IReadOnlySet<SendMode> AllowedModes(AgentRole role) => role switch
    {
        AgentRole.JuniorSales => new HashSet<SendMode> { SendMode.Manual },
        AgentRole.SeniorSales => new HashSet<SendMode> { SendMode.Manual, SendMode.AiAssisted },
        AgentRole.Supervisor => new HashSet<SendMode> { SendMode.Manual, SendMode.AiAssisted, SendMode.Automatic },
        AgentRole.Administrator => new HashSet<SendMode> { SendMode.Manual, SendMode.AiAssisted, SendMode.Automatic },
        _ => new HashSet<SendMode> { SendMode.Manual }
    };

    public static bool IsModeAllowed(AgentRole role, SendMode mode) => AllowedModes(role).Contains(mode);
    public static bool CanConfigure(AgentRole role) => role == AgentRole.Administrator;
}
