using LeadPilot.Domain.Agents;

namespace LeadPilot.Application.Agents;

/// <summary>
/// تخصیصِ شماره به فروشنده با قواعد:
///  • خدمتِ شماره باید در فهرستِ خدماتِ فروشنده باشد (فروشندهٔ ۱ فقط بانکِ خودش)؛
///  • قفلِ انحصاری: اگر شماره تخصیصِ Active به فروشندهٔ دیگری دارد → رد (تا یک شماره دو جا نرود)؛
///  • بازیابیِ دوباره بر اساسِ ویژگی (دارای اکانت/ایمیل/تلفن) فقط برای مالکِ تخصیص.
/// </summary>
public sealed class AgentAssignmentService(IAgentAssignmentStore store)
{
    public async Task<AssignmentResult> AssignAsync(
        Guid tenantId, Guid contactPointId, Guid prospectId, Guid agentProfileId, string serviceCode,
        bool hasAccount, bool hasEmail, bool hasPhone, CancellationToken ct)
    {
        var agent = await store.GetAgentAsync(agentProfileId, ct);
        if (agent is null) return new AssignmentResult(false, null, "فروشنده یافت نشد.");

        if (!agent.HandlesService(serviceCode))
            return new AssignmentResult(false, null, $"این خدمت ({serviceCode}) در حیطهٔ این فروشنده نیست.");

        // قفلِ انحصاری — شماره نباید همزمان جای دیگری Active باشد.
        var existing = await store.GetActiveAssignmentAsync(contactPointId, ct);
        if (existing is not null && existing.AgentProfileId != agentProfileId)
            return new AssignmentResult(false, null, "این شماره هم‌اکنون به فروشندهٔ دیگری تخصیص فعال دارد.");
        if (existing is not null)
            return new AssignmentResult(true, existing.Id, "قبلاً به همین فروشنده تخصیص یافته است.");

        var assignment = new ContactAssignment(tenantId, contactPointId, prospectId, agentProfileId,
            serviceCode, hasAccount, hasEmail, hasPhone);
        await store.AddAssignmentAsync(assignment, ct);
        await store.SaveAsync(ct);
        return new AssignmentResult(true, assignment.Id, null);
    }

    /// <summary>بازیابیِ دوبارهٔ بانکِ یک فروشنده بر اساسِ ویژگی (پس از ارسال به CRM هم قابلِ استفاده).</summary>
    public Task<IReadOnlyList<ContactAssignment>> RetrieveBankAsync(
        Guid agentProfileId, bool? hasAccount, bool? hasEmail, bool? hasPhone, bool activeOnly, CancellationToken ct) =>
        store.QueryAgentAssignmentsAsync(agentProfileId, hasAccount, hasEmail, hasPhone, activeOnly, ct);

    /// <summary>پس از ارسالِ نتیجه به CRM، تخصیص آزاد می‌شود (سابقه می‌ماند).</summary>
    public async Task ReleaseAfterCrmAsync(Guid contactPointId, string crmRef, CancellationToken ct)
    {
        var active = await store.GetActiveAssignmentAsync(contactPointId, ct);
        if (active is null) return;
        active.ReleaseAfterCrmPush(crmRef);
        await store.SaveAsync(ct);
    }
}
