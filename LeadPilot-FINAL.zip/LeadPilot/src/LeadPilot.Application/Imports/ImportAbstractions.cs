namespace LeadPilot.Application.Imports;

/// <summary>برای هر سطر، مخاطبِ موجود پیدا یا مخاطبِ جدید ساخته می‌شود (قید یکتاییِ ExternalId).</summary>
public interface IImportProspectResolver
{
    Task<Guid> ResolveAsync(ImportProspectRequest request, CancellationToken cancellationToken);
}

public sealed record ImportProspectRequest(
    Guid TenantId, Guid ProjectId, string ProjectCode, string ExternalId,
    string? FullName, string? CompanyName, string LanguageCode, string SourceCode, string SourceReference);

/// <summary>
/// ذخیرهٔ امنِ مقدارِ تماس. مقدارِ خام فقط رمزنگاری‌شده به‌عنوان ProtectedContactPoint (ManagerOnly)
/// ذخیره می‌شود؛ نه در جدولِ Import، نه در Log. Hash برای dedup.
/// </summary>
public interface IImportContactSink
{
    /// <returns>true اگر ذخیره شد، false اگر تکراری بود.</returns>
    Task<bool> StoreManagerOnlyAsync(ImportContactCommand command, CancellationToken cancellationToken);
}

public sealed record ImportContactCommand(
    Guid TenantId, Guid ProjectId, Guid ProspectId, string ChannelKind,
    string RawValue, string SourceReference, string LawfulSourceReference);
