namespace LeadPilot.Application.Imports;

/// <summary>
/// قراردادِ سطرِ CSV رسمی (سند). ستون‌های اجباری: external_id, project_code, country_code,
/// source_reference, lawful_source_reference و حداقل یکی از phone یا email.
/// </summary>
public sealed class ContactCsvRow
{
    public string ExternalId { get; set; } = string.Empty;
    public string ProjectCode { get; set; } = string.Empty;
    public string? FullName { get; set; }
    public string? CompanyName { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string CountryCode { get; set; } = string.Empty;
    public string LanguageCode { get; set; } = string.Empty;
    public string SourceReference { get; set; } = string.Empty;
    public string LawfulSourceReference { get; set; } = string.Empty;

    public bool IsValid(out string error)
    {
        if (string.IsNullOrWhiteSpace(ExternalId)) { error = "external_id خالی است."; return false; }
        if (string.IsNullOrWhiteSpace(ProjectCode)) { error = "project_code خالی است."; return false; }
        if (string.IsNullOrWhiteSpace(CountryCode)) { error = "country_code خالی است."; return false; }
        if (string.IsNullOrWhiteSpace(SourceReference)) { error = "source_reference خالی است."; return false; }
        if (string.IsNullOrWhiteSpace(LawfulSourceReference)) { error = "lawful_source_reference خالی است."; return false; }
        if (string.IsNullOrWhiteSpace(Phone) && string.IsNullOrWhiteSpace(Email))
        { error = "حداقل یکی از phone یا email لازم است."; return false; }
        error = string.Empty; return true;
    }
}
