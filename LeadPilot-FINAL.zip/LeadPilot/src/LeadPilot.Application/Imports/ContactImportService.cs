using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using LeadPilot.Domain.Imports;

namespace LeadPilot.Application.Imports;

/// <summary>
/// سرویسِ واردکردنِ CSV (سند). برای هر سطر: اعتبارسنجی → resolve مخاطب → ذخیرهٔ امنِ
/// ManagerOnly (رمزنگاری + Hash + حذف تکراری). مقدارِ خام هرگز در Batch/Log نمی‌ماند.
/// </summary>
public sealed class ContactImportService(IImportProspectResolver resolver, IImportContactSink sink)
{
    public async Task<ContactImportBatch> ImportAsync(
        ContactImportBatch batch, Stream csvStream, CancellationToken ct)
    {
        batch.BeginProcessing();
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = true,
            MissingFieldFound = null,
            HeaderValidated = null,
            TrimOptions = TrimOptions.Trim
        };

        using var reader = new StreamReader(csvStream);
        using var csv = new CsvReader(reader, config);
        csv.Context.RegisterClassMap<ContactCsvRowMap>();

        await foreach (var row in csv.GetRecordsAsync<ContactCsvRow>(ct))
        {
            if (!row.IsValid(out _)) { batch.CountRow(false, false, invalid: true); continue; }

            var prospectId = await resolver.ResolveAsync(new ImportProspectRequest(
                batch.TenantId, batch.ProjectId, batch.ProjectCode, row.ExternalId,
                row.FullName, row.CompanyName, row.LanguageCode, batch.SourceCode, row.SourceReference), ct);

            bool anyStored = false, anyDuplicate = false;

            if (!string.IsNullOrWhiteSpace(row.Phone))
            {
                bool stored = await sink.StoreManagerOnlyAsync(new ImportContactCommand(
                    batch.TenantId, batch.ProjectId, prospectId, "Phone",
                    row.Phone, row.SourceReference, row.LawfulSourceReference), ct);
                anyStored |= stored; anyDuplicate |= !stored;
            }
            if (!string.IsNullOrWhiteSpace(row.Email))
            {
                bool stored = await sink.StoreManagerOnlyAsync(new ImportContactCommand(
                    batch.TenantId, batch.ProjectId, prospectId, "Email",
                    row.Email, row.SourceReference, row.LawfulSourceReference), ct);
                anyStored |= stored; anyDuplicate |= !stored;
            }

            batch.CountRow(anyStored, duplicate: !anyStored && anyDuplicate, invalid: false);
        }

        batch.Complete();
        return batch;
    }
}

public sealed class ContactCsvRowMap : ClassMap<ContactCsvRow>
{
    public ContactCsvRowMap()
    {
        Map(m => m.ExternalId).Name("external_id");
        Map(m => m.ProjectCode).Name("project_code");
        Map(m => m.FullName).Name("full_name").Optional();
        Map(m => m.CompanyName).Name("company_name").Optional();
        Map(m => m.Phone).Name("phone").Optional();
        Map(m => m.Email).Name("email").Optional();
        Map(m => m.CountryCode).Name("country_code");
        Map(m => m.LanguageCode).Name("language_code").Optional();
        Map(m => m.SourceReference).Name("source_reference");
        Map(m => m.LawfulSourceReference).Name("lawful_source_reference");
    }
}
