using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Common;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Application.Compliance;

/// <summary>
/// دروازهٔ قانونی. هر سیگنال پیش از تحلیل از اینجا رد می‌شود.
/// منبع غیرمجاز، نشانهٔ دایرکتوری/شرکتی، یا URL نامعتبر → Blocked.
/// این تضمین می‌کند «تماس بدون رضایت» از نظر فنی ممکن نشود.
/// </summary>
public sealed class ComplianceGateway : IComplianceGateway
{
    private static readonly string[] DirectoryMarkers =
    [
        "contact us", "about us", "google maps", "gmb", "directory",
        "تماس با ما", "درباره ما", "اتصل بنا", "من نحن"
    ];

    // منابع مجاز نسخهٔ اول (طبق سند): API عمومی، فرم، رویداد، Partner Feed، Opt-in.
    private static readonly SourceType[] Allowed =
    [
        SourceType.PublicApi, SourceType.LeadForm, SourceType.Event,
        SourceType.PartnerFeed, SourceType.OptIn, SourceType.DemoTest
    ];

    public ComplianceDecision Evaluate(RawSignal signal, Project project)
    {
        if (!Allowed.Contains(signal.SourceType))
            return new(ComplianceStatus.Blocked, $"منبع {signal.SourceType} مجاز نیست.", 0);

        if (string.IsNullOrWhiteSpace(signal.SourceUrl) ||
            (!signal.IsDemo && !Uri.TryCreate(signal.SourceUrl, UriKind.Absolute, out _)))
            return new(ComplianceStatus.Blocked, "سیگنال بدون URL معتبر رد شد.", 0);

        var lower = signal.OriginalText.ToLowerInvariant();
        foreach (var m in DirectoryMarkers)
            if (lower.Contains(m))
                return new(ComplianceStatus.Blocked, $"نشانهٔ منبع دایرکتوری/شرکتی: «{m}».", 10);

        // منابع رضایت‌محور امن‌ترین‌اند.
        var consent = signal.SourceType is
            SourceType.LeadForm or SourceType.OptIn or SourceType.PartnerFeed;

        return consent
            ? new(ComplianceStatus.Safe, "منبع رضایت‌محور/شریک.", 100)
            : new(ComplianceStatus.NeedsReview,
                "سیگنالِ عمومیِ مجاز؛ بدون رضایت فقط به Opt-in هدایت شود.", 85);
    }
}
