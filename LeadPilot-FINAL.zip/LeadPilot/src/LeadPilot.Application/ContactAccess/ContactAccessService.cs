using LeadPilot.Domain.Consent;

namespace LeadPilot.Application.ContactAccess;

/// <summary>
/// مرجعِ واحدِ اجازهٔ دیدن/استفاده از شماره. اصلاح امنیتیِ سند:
/// دسترسیِ مدیرِ مجاز (با Audit) **قبل از** بررسیِ Freeze/Suppressed/Status است.
/// توقفِ مسیر فقط استفادهٔ عملیاتیِ فروشنده/AI/کمپین را می‌بندد، نه کنترلِ مدیر را.
/// </summary>
public sealed class ContactAccessService(IContactAccessAudit audit)
{
    public ContactAccessDecision Authorize(ContactAccessRequest request, ProtectedContactPoint contact)
    {
        // ۱) مدیرِ مجاز: همیشه می‌تواند برای بررسیِ پرونده ببیند (با Audit) —
        //    حتی اگر Hidden/ManagerBlocked/Suppressed باشد. این «اجازهٔ تماس» نیست.
        if (request.IsAuthorizedManager)
        {
            audit.AddRevealAudit(request.ActorId, contact.Id, "مشاهدهٔ پرونده توسط مدیر مجاز.");
            return new ContactAccessDecision(true, "MANAGER_CASE_REVIEW",
                "دسترسی مدیریتی همراه با Audit مجاز است.", IsOperationalUse: false);
        }

        // ۲) از اینجا به بعد، کاربران/سرویس‌های عملیاتی (فروشنده/AI/کمپین).
        if (contact.Visibility == ContactVisibility.Suppressed)
            return Deny("SUPPRESSED", "این پرونده Suppressed است و استفادهٔ عملیاتی ندارد.");

        if (contact.ManagerBlocked)
            return Deny("MANAGER_BLOCKED", "مدیر این پرونده را برای استفادهٔ عملیاتی متوقف کرده است.");

        if (contact.Visibility == ContactVisibility.Hidden)
            return Deny("NOT_CONSENTED", "هنوز رضایت نیامده؛ شماره برای عملیات آزاد نیست.");

        // ۳) Usable و بدون توقف → استفادهٔ عملیاتی مجاز.
        return new ContactAccessDecision(true, "OPERATIONAL_ALLOWED",
            "شماره پس از رضایت برای استفادهٔ عملیاتی آزاد است.", IsOperationalUse: true);
    }

    private static ContactAccessDecision Deny(string code, string reason) =>
        new(false, code, reason, IsOperationalUse: false);
}

public interface IContactAccessAudit
{
    void AddRevealAudit(string actorId, Guid contactId, string reason);
}

public sealed record ContactAccessRequest(string ActorId, bool IsAuthorizedManager, string Purpose);
public sealed record ContactAccessDecision(bool IsAllowed, string DecisionCode, string Reason, bool IsOperationalUse);
