using LeadPilot.Application.Capacity;
using LeadPilot.Domain.Capacity;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Worker;

/// <summary>
/// هر ۳۰ ثانیه Orchestrator را برای برنامه‌های فعال اجرا می‌کند.
/// برای جلوگیری از اجرای هم‌زمانِ چند Planner، از قفلِ توزیع‌شدهٔ Postgres
/// (pg_try_advisory_lock) استفاده می‌شود؛ اگر قفل نگرفت، آن چرخه را رد می‌کند.
/// </summary>
public sealed class CapacityPlannerWorker(
    IServiceScopeFactory scopeFactory, ILogger<CapacityPlannerWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(30));
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                await using var scope = scopeFactory.CreateAsyncScope();
                var db = scope.ServiceProvider.GetRequiredService<LeadPilotDbContext>();
                var orchestrator = scope.ServiceProvider.GetRequiredService<IDailyCapacityOrchestrator>();

                var activePlanIds = await db.DailyCapacityPlans.AsNoTracking()
                    .Where(x => x.Status == DailyCapacityPlanStatus.Scheduled || x.Status == DailyCapacityPlanStatus.Running)
                    .Select(x => x.Id).ToArrayAsync(stoppingToken);

                foreach (var planId in activePlanIds)
                {
                    // قفلِ توزیع‌شده بر پایهٔ hashِ planId (Postgres advisory lock)
                    long lockKey = BitConverter.ToInt64(planId.ToByteArray(), 0);
                    bool locked = await TryAdvisoryLockAsync(db, lockKey, stoppingToken);
                    if (!locked) continue; // Planner دیگری این برنامه را می‌چرخاند
                    try { await orchestrator.RunCycleAsync(planId, stoppingToken); }
                    finally { await AdvisoryUnlockAsync(db, lockKey, stoppingToken); }
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception ex) { logger.LogError(ex, "Daily capacity planner cycle failed."); }
        }
    }

    private static async Task<bool> TryAdvisoryLockAsync(LeadPilotDbContext db, long key, CancellationToken ct)
    {
        // pg_try_advisory_lock فوری true/false برمی‌گرداند (بدون انتظار).
        var result = await db.Database
            .SqlQuery<bool>($"SELECT pg_try_advisory_lock({key}) AS \"Value\"")
            .ToListAsync(ct);
        return result.Count > 0 && result[0];
    }

    private static async Task AdvisoryUnlockAsync(LeadPilotDbContext db, long key, CancellationToken ct)
    {
        await db.Database.ExecuteSqlAsync($"SELECT pg_advisory_unlock({key})", ct);
    }
}
