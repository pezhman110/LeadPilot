using LeadPilot.Application.Processing;
using LeadPilot.Domain.Processing;

namespace LeadPilot.Worker;

/// <summary>
/// Workerِ مستقل: Jobها را از صف برمی‌دارد و با Handlerِ مربوط اجرا می‌کند.
/// هر Job در Scope مجزا (DbContext مشترک نمی‌شود). موازیِ محدود.
/// </summary>
public sealed class ProcessingWorker(
    IServiceScopeFactory scopeFactory,
    ILogger<ProcessingWorker> logger,
    IConfiguration configuration) : BackgroundService
{
    private readonly string _workerId = $"{Environment.MachineName}-{Guid.NewGuid():N}";

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        int batchSize = configuration.GetValue("Worker:BatchSize", 25);
        int leaseSeconds = configuration.GetValue("Worker:LeaseSeconds", 120);
        int idleDelayMs = configuration.GetValue("Worker:IdleDelayMilliseconds", 1000);
        int concurrency = configuration.GetValue("Worker:Concurrency", 8);
        var leaseDuration = TimeSpan.FromSeconds(leaseSeconds);

        string[] supportedJobTypes =
        [
            ProcessingJobTypes.ContactDiscovery,
            ProcessingJobTypes.Search,
            ProcessingJobTypes.ConsentInvitation,
            ProcessingJobTypes.AiTextWarming,
            ProcessingJobTypes.VoiceCall
        ];

        logger.LogInformation("Worker {WorkerId} started.", _workerId);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await using var scope = scopeFactory.CreateAsyncScope();
                var repository = scope.ServiceProvider.GetRequiredService<IProcessingJobRepository>();

                var jobs = await repository.ClaimBatchAsync(_workerId, supportedJobTypes, batchSize, leaseDuration, stoppingToken);
                if (jobs.Count == 0)
                {
                    await Task.Delay(idleDelayMs, stoppingToken);
                    continue;
                }

                await Parallel.ForEachAsync(jobs,
                    new ParallelOptions { MaxDegreeOfParallelism = concurrency, CancellationToken = stoppingToken },
                    async (job, ct) => await ProcessJobAsync(job, ct));
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception ex)
            {
                logger.LogError(ex, "Worker loop failed.");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }

    private async Task ProcessJobAsync(ProcessingJob claimedJob, CancellationToken ct)
    {
        await using var scope = scopeFactory.CreateAsyncScope();
        var repository = scope.ServiceProvider.GetRequiredService<IProcessingJobRepository>();
        var handlers = scope.ServiceProvider.GetServices<IProcessingJobHandler>().ToArray();
        var handler = handlers.SingleOrDefault(x => x.JobType == claimedJob.JobType);

        if (handler is null)
        {
            await repository.FailAsync(claimedJob.Id, _workerId, "HANDLER_NOT_FOUND",
                $"Handler برای {claimedJob.JobType} ثبت نشده است.", isTransient: false, ct);
            return;
        }

        ProcessingJobExecutionResult result;
        try { result = await handler.ExecuteAsync(claimedJob, ct); }
        catch (Exception ex) { result = ProcessingJobExecutionResult.TransientFailure("UNHANDLED_WORKER_ERROR", ex.Message); }

        if (result.Succeeded)
            await repository.CompleteAsync(claimedJob.Id, _workerId, ct);
        else
            await repository.FailAsync(claimedJob.Id, _workerId,
                result.ErrorCode ?? "UNKNOWN", result.ErrorMessage ?? "خطای نامشخص", result.IsTransientFailure, ct);
    }
}
