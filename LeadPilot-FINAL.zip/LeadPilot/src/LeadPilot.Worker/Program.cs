using LeadPilot.Infrastructure;
using LeadPilot.Worker;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddHostedService<ProcessingWorker>();
builder.Services.AddHostedService<CapacityPlannerWorker>();
var host = builder.Build();
await host.RunAsync();
