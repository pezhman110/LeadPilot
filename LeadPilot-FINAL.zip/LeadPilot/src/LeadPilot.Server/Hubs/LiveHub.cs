using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Signals;
using Microsoft.AspNetCore.SignalR;

namespace LeadPilot.Server.Hubs;

/// <summary>Hub زندهٔ داشبورد (جست‌وجوی زنده).</summary>
public sealed class LiveHub : Hub { }

/// <summary>پیاده‌سازی ILiveNotifier روی SignalR.</summary>
public sealed class SignalRLiveNotifier(IHubContext<LiveHub> hub) : ILiveNotifier
{
    public Task SignalProcessedAsync(NormalizedSignal s) =>
        hub.Clients.All.SendAsync("signal", new
        {
            id = s.Id,
            url = s.SourceUrl,
            source = s.SourceType.ToString(),
            query = s.QueryUsed,
            language = s.Language.ToString(),
            intent = s.IntentScore,
            fit = s.FitScore,
            compliance = s.ComplianceScore,
            final = s.FinalScore,
            complianceStatus = s.ComplianceStatus.ToString(),
            isDemo = s.IsDemo,
            text = s.OriginalText,
            summaryFa = s.TranslatedSummaryFa,
            reasons = s.ReasonForScore
        });

    public Task RunStatusAsync(SearchRun r) =>
        hub.Clients.All.SendAsync("runStatus", new
        {
            id = r.Id, status = r.Status.ToString(),
            queries = r.QueriesExecuted, found = r.RawFound,
            blocked = r.Blocked, processed = r.Processed, duplicates = r.Duplicates
        });
}
