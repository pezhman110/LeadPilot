using LeadPilot.Application.Communications;
using LeadPilot.Application.Identity;
using LeadPilot.Application.Suppression;
using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Identity;
using LeadPilot.Domain.Suppression;
using LeadPilot.Infrastructure.Persistence;

namespace LeadPilot.Server.Endpoints;

/// <summary>موتور مسیریابیِ کانال + هویت + Suppression سراسری.</summary>
public static class RoutingEndpoints
{
    public static void MapRoutingEndpoints(this IEndpointRouteBuilder app)
    {
        // تصمیمِ مسیریابی برای یک مخاطب/هدف
        app.MapPost("/api/routing/decide", (RoutingRequest req, ChannelRoutingEngine engine) =>
        {
            static IReadOnlySet<CommunicationChannel> Parse(string[]? a) =>
                (a ?? []).Select(Enum.Parse<CommunicationChannel>).ToHashSet();
            var input = new ChannelRoutingInput(
                req.IdentityOwnershipConfirmed,
                string.IsNullOrWhiteSpace(req.PreferredChannel) ? null : Enum.Parse<CommunicationChannel>(req.PreferredChannel),
                (req.FallbackOrder ?? []).Select(Enum.Parse<CommunicationChannel>).ToList(),
                Parse(req.ConsentGranted), Parse(req.Suppressed), Parse(req.Healthy),
                Parse(req.RecentlyMessaged), Parse(req.OpenWindow), Parse(req.HasTemplate),
                req.AutomationAllowed);
            var d = engine.Decide(input);
            return Results.Ok(new { chosen = d.ChosenChannel?.ToString(), mode = d.Mode.ToString(), d.Reason,
                trail = d.Trail.Select(t => new { channel = t.Channel.ToString(), status = t.Status.ToString() }) });
        }).WithTags("Routing");

        // پیشنهاد اتصالِ هویت با شواهد
        app.MapPost("/api/identity/link", async (IdentityLinkRequest req, IdentityResolutionService svc,
            LeadPilotDbContext db, CancellationToken ct) =>
        {
            var link = svc.Propose(req.TenantId, req.UnifiedProfileId, req.Channel, req.AccountHandle,
                Enum.Parse<IdentityEvidence>(req.Evidence));
            db.IdentityLinks.Add(link);
            await db.SaveChangesAsync(ct);
            return Results.Ok(new { link.Id, Confidence = link.Confidence.ToString(),
                needsApproval = svc.RequiresHumanApproval(link), canMerge = svc.CanAutoMerge(link) });
        }).WithTags("Identity");

        // توقفِ سراسری (opt-out) با دامنه
        app.MapPost("/api/suppression", async (SuppressionRequest req, GlobalSuppressionService svc, CancellationToken ct) =>
        {
            await svc.SuppressAsync(req.TenantId, req.IdentityHash,
                Enum.Parse<SuppressionScope>(req.Scope), req.Channel, req.Reason, req.Source, ct);
            return Results.Ok();
        }).WithTags("Suppression");

        app.MapGet("/api/suppression/check", async (Guid tenantId, string identityHash, string channel,
            GlobalSuppressionService svc, CancellationToken ct) =>
            Results.Ok(new { blocked = await svc.IsBlockedAsync(tenantId, identityHash, channel, ct) }))
            .WithTags("Suppression");
    }
}

public sealed record RoutingRequest(bool IdentityOwnershipConfirmed, string? PreferredChannel, string[]? FallbackOrder,
    string[]? ConsentGranted, string[]? Suppressed, string[]? Healthy, string[]? RecentlyMessaged,
    string[]? OpenWindow, string[]? HasTemplate, bool AutomationAllowed);
public sealed record IdentityLinkRequest(Guid TenantId, Guid UnifiedProfileId, string Channel, string AccountHandle, string Evidence);
public sealed record SuppressionRequest(Guid TenantId, string IdentityHash, string Scope, string? Channel, string Reason, string Source);
