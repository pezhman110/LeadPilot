using LeadPilot.Application.Abstractions;
using LeadPilot.Application.Search;

namespace LeadPilot.Server.Endpoints;

public static class SearchEndpoints
{
    public static void MapSearchEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/projects/{projectId:guid}").WithTags("Search");

        // اجرای جست‌وجوی زنده روی یک پروژه (نتایج از SignalR می‌آید)
        g.MapPost("/search", async (Guid projectId, IProjectRepository projects,
            SearchOrchestrator orchestrator, CancellationToken ct) =>
        {
            var project = await projects.GetAsync(projectId, ct);
            if (project is null) return Results.NotFound();
            var runId = await orchestrator.RunAsync(project, isPausedCheck: null, ct);
            return Results.Ok(new { runId });
        });

        // فهرست سیگنال‌های یک پروژه (مرتب بر اساس امتیاز)
        g.MapGet("/signals", async (Guid projectId, ISignalRepository signals, CancellationToken ct) =>
            Results.Ok(await signals.ListByProjectAsync(projectId, ct)));
    }
}
