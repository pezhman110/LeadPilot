using LeadPilot.Application.Reporting;

namespace LeadPilot.Server.Endpoints;

public static class ReportEndpoints
{
    public static void MapReportEndpoints(this IEndpointRouteBuilder app)
    {
        // گزارش مدیریتیِ «یک نگاه» برای یک پروژه
        app.MapGet("/api/projects/{projectId:guid}/report",
            async (Guid projectId, ManagementReportService svc, CancellationToken ct) =>
                Results.Ok(await svc.BuildAsync(projectId, ct)))
           .WithTags("Reporting");
    }
}
