using LeadPilot.Application.Community;
using LeadPilot.Domain.Community;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>ماژول Communities & Forums: منابع، Opportunity Feed، امتیازدهی، پاسخِ شفاف.</summary>
public static class CommunityEndpoints
{
    public static void MapCommunityEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/community").WithTags("Community");

        // مدیریت منابع
        g.MapPost("/sources", async (CreateCommunitySourceRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var s = new CommunitySource(r.TenantId, r.Name, Enum.Parse<CommunityPlatform>(r.Platform), r.Url,
                r.Country, r.City, r.Language, r.Industries, r.CommercialResponsesAllowed,
                r.DirectMessagesAllowed, r.OfficialApiAvailable, r.DailyRequestLimit, r.RetentionDays);
            db.CommunitySources.Add(s); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/community/sources/{s.Id}", new { s.Id, Status = s.Status.ToString() });
        });
        g.MapPost("/sources/{id:guid}/transition", async (Guid id, TransitionSourceRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var s = await db.CommunitySources.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (s is null) return Results.NotFound();
            s.Transition(Enum.Parse<CommunitySourceStatus>(r.ToStatus)); await db.SaveChangesAsync(ct);
            return Results.Ok(new { s.Id, Status = s.Status.ToString(), s.CanMonitor, s.CanPublicRespond, s.CanPublish });
        });
        g.MapGet("/sources/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.CommunitySources.AsNoTracking().Where(x => x.TenantId == tenantId)
                .Select(x => new { x.Id, x.Name, Platform = x.Platform.ToString(), Status = x.Status.ToString(),
                    x.CommercialResponsesAllowed, x.OfficialApiAvailable }).ToListAsync(ct)));

        // امتیازدهیِ توضیح‌پذیرِ قصد
        g.MapPost("/intent-score", (IntentScoreRequest r, IntentScoringEngine engine) =>
        {
            var signals = (r.Signals ?? []).Select(Enum.Parse<IntentSignalKind>).ToList();
            var s = engine.Score(signals);
            return Results.Ok(new { s.Score, s.Urgency, s.Reasons });
        });

        // ورودِ مشاهده → Opportunity (فیلترِ دادهٔ شخصی)
        g.MapPost("/opportunities/ingest", async (IngestRequest r, OpportunityIngestionService svc,
            LeadPilotDbContext db, CancellationToken ct) =>
        {
            var source = await db.CommunitySources.FirstOrDefaultAsync(x => x.Id == r.SourceId, ct);
            if (source is null) return Results.NotFound();
            bool dup = await db.CommunityOpportunities.AnyAsync(x => x.TenantId == source.TenantId && x.PublicThreadUrl == r.PublicThreadUrl, ct);
            var res = svc.Ingest(source, new RawObservation(r.Community, r.PublicThreadUrl, r.PublicPostId,
                r.Topic, r.QuestionSummary, r.Language, r.Industry, r.DeclaredLocation, r.IntentScore, r.PublishedAtUtc), dup);
            if (!res.Ok) return Results.Ok(new { ingested = false, res.Reason });
            db.CommunityOpportunities.Add(res.Opportunity!); await db.SaveChangesAsync(ct);
            return Results.Ok(new { ingested = true, res.Opportunity!.Id, contactable = res.Opportunity!.IsContactable });
        });

        // Opportunity Feed
        g.MapGet("/opportunities/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.CommunityOpportunities.AsNoTracking().Where(x => x.TenantId == tenantId)
                .OrderByDescending(x => x.IntentScore)
                .Select(x => new { x.Id, Platform = x.Platform.ToString(), x.Community, x.Industry, x.DeclaredLocation,
                    x.Language, x.QuestionSummary, x.IntentScore, Status = x.Status.ToString(), x.PublicThreadUrl }).Take(100).ToListAsync(ct)));

        // تخصیص / ثبتِ پاسخِ منتشرشده (سیستم وانمود نمی‌کند منتشر کرده) / تبدیل
        g.MapPost("/opportunities/{id:guid}/assign", async (Guid id, AssignOppRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var o = await db.CommunityOpportunities.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (o is null) return Results.NotFound();
            o.Assign(r.AgentId); await db.SaveChangesAsync(ct);
            return Results.Ok(new { o.Id, Status = o.Status.ToString() });
        });
        g.MapPost("/opportunities/{id:guid}/record-response", async (Guid id, RecordResponseRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var o = await db.CommunityOpportunities.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (o is null) return Results.NotFound();
            o.RecordPublishedResponse(r.ResponseUrl); await db.SaveChangesAsync(ct);
            return Results.Ok(new { o.Id, Status = o.Status.ToString(), o.PublishedResponseUrl });
        });
        g.MapPost("/opportunities/{id:guid}/convert", async (Guid id, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var o = await db.CommunityOpportunities.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (o is null) return Results.NotFound();
            o.ConvertToLead(); await db.SaveChangesAsync(ct); // فقط پس از اقدامِ داوطلبانه
            return Results.Ok(new { o.Id, Status = o.Status.ToString() });
        });
    }
}

public sealed record CreateCommunitySourceRequest(Guid TenantId, string Name, string Platform, string Url,
    string Country, string? City, string Language, string Industries, bool CommercialResponsesAllowed,
    bool DirectMessagesAllowed, bool OfficialApiAvailable, int DailyRequestLimit, int RetentionDays);
public sealed record TransitionSourceRequest(string ToStatus);
public sealed record IntentScoreRequest(string[]? Signals);
public sealed record IngestRequest(Guid SourceId, string Community, string PublicThreadUrl, string? PublicPostId,
    string Topic, string QuestionSummary, string Language, string Industry, string? DeclaredLocation,
    int IntentScore, DateTimeOffset PublishedAtUtc);
public sealed record AssignOppRequest(Guid AgentId);
public sealed record RecordResponseRequest(string ResponseUrl);
