using LeadPilot.Application.Communications;
using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Crm;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>
/// صفحهٔ ارتباطاتِ کارشناسِ فروش (کنسولِ Omnichannel). فقط مخاطبانِ دارای رضایت.
/// حالت دستی و خودکار؛ اتوماسیونِ کامنتِ اینستاگرام؛ اتصالِ CRM.
/// </summary>
public static class CommunicationEndpoints
{
    public static void MapCommunicationEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/communications").WithTags("Communications");

        // صندوقِ ورودی: فقط مخاطبانِ دارای اکانت و رضایت (Usable، غیرِ Suppressed).
        g.MapGet("/inbox/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var items = await db.ContactPoints.AsNoTracking()
                .Where(x => x.Visibility == LeadPilot.Domain.Consent.ContactVisibility.Usable && !x.ManagerBlocked)
                .OrderByDescending(x => x.CreatedAtUtc)
                .Take(100)
                .Select(x => new { x.Id, x.ProspectId, Channel = x.Channel.ToString(), x.CreatedAtUtc })
                .ToListAsync(ct);
            return Results.Ok(items);
        });

        // ارتباط (دستی/خودکار) — گیتِ رضایت در سرویس/دامنه اجرا می‌شود.
        g.MapPost("/contact", async (ContactRequest req, CommunicationsService svc, CancellationToken ct) =>
        {
            var attempt = await svc.ContactAsync(req.TenantId, req.ProspectId, req.ContactPointId,
                Enum.Parse<CommunicationChannel>(req.Channel), Enum.Parse<OutreachMode>(req.Mode),
                req.AgentId, req.MessageRef, req.MessageBody, ct);
            return Results.Ok(new { attempt.Id, attempt.Result, attempt.BlockReason });
        });

        // اتوماسیونِ کامنتِ اینستاگرام — ارزیابیِ یک کامنت در برابرِ قواعد.
        g.MapPost("/instagram/evaluate-comment", async (EvaluateCommentRequest req,
            InstagramCommentAutomationService svc, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var rules = await db.InstagramCommentRules.Where(x => x.TenantId == req.TenantId && x.IsEnabled).ToListAsync(ct);
            var decision = svc.Evaluate(rules, req.CommentText);
            await db.SaveChangesAsync(ct); // ثبتِ MatchedCount
            return Results.Ok(decision);
        });

        // قواعدِ اینستاگرام
        g.MapGet("/instagram/rules/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.InstagramCommentRules.AsNoTracking().Where(x => x.TenantId == tenantId).ToListAsync(ct)));

        g.MapPost("/instagram/rules", async (CreateIgRuleRequest req, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var rule = new InstagramCommentRule(req.TenantId, req.Name, req.Keyword,
                req.PublicReplyTemplateRef, req.DmInviteTemplateRef, Enum.Parse<OutreachMode>(req.Mode));
            if (req.Enabled) rule.Enable();
            db.InstagramCommentRules.Add(rule);
            await db.SaveChangesAsync(ct);
            return Results.Created($"/api/communications/instagram/rules/{rule.Id}", new { rule.Id });
        });

        // اتصالِ CRM
        g.MapGet("/crm/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.CrmConnections.AsNoTracking().Where(x => x.TenantId == tenantId)
                .Select(x => new { x.Id, Provider = x.Provider.ToString(), x.DisplayName, Status = x.Status.ToString() })
                .ToListAsync(ct)));

        g.MapPost("/crm", async (CreateCrmRequest req, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var conn = new CrmConnection(req.TenantId, Enum.Parse<CrmProvider>(req.Provider),
                req.DisplayName, req.BaseUrl, req.SecretReference);
            db.CrmConnections.Add(conn);
            await db.SaveChangesAsync(ct);
            return Results.Created($"/api/communications/crm/{conn.Id}", new { conn.Id });
        });

        g.MapPost("/crm/{id:guid}/connect", async (Guid id, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var conn = await db.CrmConnections.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (conn is null) return Results.NotFound();
            conn.MarkConnected(); await db.SaveChangesAsync(ct);
            return Results.Ok(new { conn.Id, Status = conn.Status.ToString() });
        });

        // ارسالِ نتیجهٔ عملکرد به CRM
        g.MapPost("/crm/{id:guid}/push", async (Guid id, PushOutcomeRequest req, LeadPilotDbContext db,
            CrmSyncService svc, CancellationToken ct) =>
        {
            var conn = await db.CrmConnections.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (conn is null) return Results.NotFound();
            var rec = await svc.PushAsync(conn, req.ProspectId, req.Outcome, ct);
            return Results.Ok(new { rec.Id, Status = rec.Status.ToString(), rec.ExternalId, rec.Error });
        });
    }
}

public sealed record ContactRequest(Guid TenantId, Guid ProspectId, Guid ContactPointId,
    string Channel, string Mode, Guid AgentId, string MessageRef, string MessageBody);
public sealed record EvaluateCommentRequest(Guid TenantId, string CommentText);
public sealed record CreateIgRuleRequest(Guid TenantId, string Name, string Keyword,
    string PublicReplyTemplateRef, string DmInviteTemplateRef, string Mode, bool Enabled);
public sealed record CreateCrmRequest(Guid TenantId, string Provider, string DisplayName, string? BaseUrl, string? SecretReference);
public sealed record PushOutcomeRequest(Guid ProspectId, string Outcome);
