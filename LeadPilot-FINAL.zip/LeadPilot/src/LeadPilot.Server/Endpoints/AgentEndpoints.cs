using LeadPilot.Application.Agents;
using LeadPilot.Domain.Agents;
using LeadPilot.Domain.Communications;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>
/// ابزار و بانکِ اختصاصیِ هر فروشنده + قفلِ انحصاریِ شماره + پیکربندیِ Failover ابزارها.
/// </summary>
public static class AgentEndpoints
{
    public static void MapAgentEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/agents").WithTags("Agents");

        // ساخت پروفایل فروشنده (خدمات + کانال‌ها + سقف + اجازه‌ها)
        g.MapPost("/", async (CreateAgentRequest req, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var a = new AgentProfile(req.TenantId, req.PartnerId, req.DisplayName,
                req.DailySendCap, req.AutomaticSendingAllowed, req.CanRevealContact);
            foreach (var s in req.Services ?? []) a.AllowService(s);
            foreach (var c in req.Channels ?? []) a.AllowChannel(c);
            db.AgentProfiles.Add(a);
            await db.SaveChangesAsync(ct);
            return Results.Created($"/api/agents/{a.Id}", new { a.Id });
        });

        // تخصیصِ شماره به فروشنده — قفلِ انحصاری + تطبیقِ خدمت
        g.MapPost("/assign", async (AssignRequest req, AgentAssignmentService svc, CancellationToken ct) =>
        {
            var r = await svc.AssignAsync(req.TenantId, req.ContactPointId, req.ProspectId, req.AgentProfileId,
                req.ServiceCode, req.HasAccount, req.HasEmail, req.HasPhone, ct);
            return r.Ok ? Results.Ok(new { r.AssignmentId, r.Reason }) : Results.Conflict(new { r.Reason });
        });

        // بازیابیِ بانکِ فروشنده بر اساسِ ویژگی (دارای اکانت/ایمیل/تلفن)
        g.MapGet("/{agentProfileId:guid}/bank", async (Guid agentProfileId, bool? hasAccount, bool? hasEmail,
            bool? hasPhone, bool? activeOnly, AgentAssignmentService svc, CancellationToken ct) =>
        {
            var items = await svc.RetrieveBankAsync(agentProfileId, hasAccount, hasEmail, hasPhone, activeOnly ?? true, ct);
            return Results.Ok(items.Select(x => new { x.Id, x.ContactPointId, x.ServiceCode,
                x.HasAccount, x.HasEmail, x.HasPhone, Status = x.Status.ToString() }));
        });

        // آزادسازی پس از ارسال به CRM
        g.MapPost("/release-after-crm", async (ReleaseRequest req, AgentAssignmentService svc, CancellationToken ct) =>
        {
            await svc.ReleaseAfterCrmAsync(req.ContactPointId, req.CrmRef, ct);
            return Results.Ok();
        });

        // پیکربندیِ اولویتِ ابزار برای یک کانال (Failover)
        g.MapPost("/provider-config", async (ProviderConfigRequest req, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var cfg = new ChannelProviderConfig(req.TenantId,
                Enum.Parse<CommunicationChannel>(req.Channel),
                Enum.Parse<MessagingProviderCode>(req.Provider), req.Priority);
            db.ChannelProviderConfigs.Add(cfg);
            await db.SaveChangesAsync(ct);
            return Results.Created($"/api/agents/provider-config/{cfg.Id}", new { cfg.Id });
        });

        g.MapGet("/provider-config/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.ChannelProviderConfigs.AsNoTracking().Where(x => x.TenantId == tenantId)
                .OrderBy(x => x.Channel).ThenBy(x => x.Priority)
                .Select(x => new { x.Id, Channel = x.Channel.ToString(), Provider = x.Provider.ToString(), x.Priority, x.IsEnabled })
                .ToListAsync(ct)));
    }
}

public sealed record CreateAgentRequest(Guid TenantId, Guid PartnerId, string DisplayName,
    int DailySendCap, bool AutomaticSendingAllowed, bool CanRevealContact, string[]? Services, string[]? Channels);
public sealed record AssignRequest(Guid TenantId, Guid ContactPointId, Guid ProspectId, Guid AgentProfileId,
    string ServiceCode, bool HasAccount, bool HasEmail, bool HasPhone);
public sealed record ReleaseRequest(Guid ContactPointId, string CrmRef);
public sealed record ProviderConfigRequest(Guid TenantId, string Channel, string Provider, int Priority);
