using LeadPilot.Application.Imports;
using LeadPilot.Domain.Imports;
using LeadPilot.Domain.Lifecycle;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>ورود CSV/CRM + چرخهٔ عمر داده (رضایتِ آرشیوی، نگهداری، حذف).</summary>
public static class ImportEndpoints
{
    public static void MapImportEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/imports").WithTags("Imports");

        // آپلود CSV و اجرای فوریِ خطِ ورود
        g.MapPost("/csv", async (HttpRequest req, ContactImportService svc, LeadPilotDbContext db, CancellationToken ct) =>
        {
            if (!req.HasFormContentType) return Results.BadRequest(new { error = "فرم multipart لازم است." });
            var form = await req.ReadFormAsync(ct);
            var file = form.Files.GetFile("file");
            if (file is null) return Results.BadRequest(new { error = "فایل CSV یافت نشد." });

            if (!Guid.TryParse(form["tenantId"], out var tenantId) ||
                !Guid.TryParse(form["projectId"], out var projectId))
                return Results.BadRequest(new { error = "tenantId/projectId معتبر نیست." });

            var batch = new ContactImportBatch(tenantId, projectId, form["projectCode"].ToString(),
                file.FileName, form["sourceCode"].ToString(), form["importedBy"].ToString(), DateTimeOffset.UtcNow);
            db.ContactImportBatches.Add(batch);
            await db.SaveChangesAsync(ct);

            await using var stream = file.OpenReadStream();
            await svc.ImportAsync(batch, stream, ct);
            await db.SaveChangesAsync(ct);

            return Results.Ok(new { batch.Id, Status = batch.Status.ToString(),
                batch.TotalRows, batch.ImportedRows, batch.DuplicateRows, batch.InvalidRows });
        }).DisableAntiforgery();

        g.MapGet("/batches/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.ContactImportBatches.AsNoTracking().Where(x => x.TenantId == tenantId)
                .OrderByDescending(x => x.CreatedAtUtc)
                .Select(x => new { x.Id, x.OriginalFileName, Status = x.Status.ToString(),
                    x.TotalRows, x.ImportedRows, x.DuplicateRows, x.InvalidRows }).ToListAsync(ct)));

        // چرخهٔ عمر داده
        g.MapPost("/consent-evidence", async (ConsentEvidenceRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var e = new ConsentEvidence(r.TenantId, r.ProspectId, r.Channel, r.Method, r.EvidenceRef, DateTimeOffset.UtcNow);
            db.ConsentEvidences.Add(e); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/imports/consent-evidence/{e.Id}", new { e.Id });
        });

        g.MapPost("/retention-policy", async (RetentionRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var p = new DataRetentionPolicy(r.TenantId, r.DataCategory, r.RetentionDays, r.LawfulBasis);
            db.DataRetentionPolicies.Add(p); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/imports/retention-policy/{p.Id}", new { p.Id });
        });

        g.MapPost("/deletion-request", async (DeletionRequestBody r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var d = new DeletionRequest(r.TenantId, r.ProspectId, r.RequestedBy, r.Reason);
            db.DeletionRequests.Add(d); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/imports/deletion-request/{d.Id}", new { d.Id, Status = d.Status.ToString() });
        });
    }
}

public sealed record ConsentEvidenceRequest(Guid TenantId, Guid ProspectId, string Channel, string Method, string EvidenceRef);
public sealed record RetentionRequest(Guid TenantId, string DataCategory, int RetentionDays, string LawfulBasis);
public sealed record DeletionRequestBody(Guid TenantId, Guid ProspectId, string RequestedBy, string Reason);
