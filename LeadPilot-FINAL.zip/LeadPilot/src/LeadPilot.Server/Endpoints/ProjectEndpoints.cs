using LeadPilot.Application.Projects;

namespace LeadPilot.Server.Endpoints;

public static class ProjectEndpoints
{
    public static void MapProjectEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/projects").WithTags("Projects");

        group.MapGet("/", GetProjects);
        group.MapGet("/{id:guid}", GetProject);
        group.MapPost("/", CreateProject);
        group.MapPost("/{id:guid}/activate", ActivateProject);
        group.MapPost("/{id:guid}/pause", PauseProject);
    }

    private static async Task<IResult> GetProjects(ProjectService svc, CancellationToken ct) =>
        Results.Ok(await svc.ListAsync(ct));

    private static async Task<IResult> GetProject(Guid id, ProjectService svc, CancellationToken ct)
    {
        var p = await svc.GetAsync(id, ct);
        return p is null ? Results.NotFound() : Results.Ok(p);
    }

    private static async Task<IResult> CreateProject(CreateProjectRequest req, ProjectService svc, CancellationToken ct)
    {
        try
        {
            var created = await svc.CreateAsync(req, ct);
            return Results.Created($"/api/projects/{created.Id}", created);
        }
        catch (ArgumentException ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }

    private static async Task<IResult> ActivateProject(Guid id, ProjectService svc, CancellationToken ct)
    {
        try
        {
            var p = await svc.ActivateAsync(id, ct);
            return p is null ? Results.NotFound() : Results.Ok(p);
        }
        catch (InvalidOperationException ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }

    private static async Task<IResult> PauseProject(Guid id, ProjectService svc, CancellationToken ct)
    {
        try
        {
            var p = await svc.PauseAsync(id, ct);
            return p is null ? Results.NotFound() : Results.Ok(p);
        }
        catch (InvalidOperationException ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }
}
