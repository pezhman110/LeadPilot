using LeadPilot.Application.Acquisition;

namespace LeadPilot.Server.Endpoints;

public static class AcquisitionEndpoints
{
    public static void MapAcquisitionEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/acquisition/first-ten").WithTags("FirstTenRun");

        // مدیر Start Test Run را می‌زند → جریان کامل → فقط نتایجِ ماسک‌شده
        g.MapPost("/start", async (StartFirstTenRunCommand cmd, IFirstTenRunService svc, CancellationToken ct) =>
            Results.Ok(await svc.StartAsync(cmd, ct)));

        // وضعیت یک اجرا (فقط ماسک‌شده؛ شمارهٔ کامل از Endpoint کنترل‌شدهٔ Reveal مدیر)
        g.MapGet("/{id:guid}", async (Guid id, IFirstTenRunService svc, CancellationToken ct) =>
        {
            var r = await svc.GetAsync(id, ct);
            return r is null ? Results.NotFound() : Results.Ok(r);
        });

        // لغو اجرا
        g.MapPost("/{id:guid}/cancel", async (Guid id, IFirstTenRunService svc, CancellationToken ct) =>
        {
            await svc.CancelAsync(id, ct);
            return Results.NoContent();
        });
    }
}
