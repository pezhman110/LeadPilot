using LeadPilot.Application.Discovery;
using LeadPilot.Domain.Discovery;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>صفحاتِ جذب (Acquisition): کشف منبع، تأیید Provider، قرنطینه، سیگنال، Lead Magnet، Tracked Link.</summary>
public static class DiscoveryEndpoints
{
    public static void MapDiscoveryEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/acquisition").WithTags("Acquisition");

        // Source Discovery
        g.MapPost("/sources", async (CreateSourceRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var s = new AcquisitionSource(r.TenantId, r.Name, Enum.Parse<DiscoverySourceType>(r.Type),
                r.Industry, r.Country, r.City, r.Language, r.CollectionAllowed, r.ToolUsed);
            db.AcquisitionSources.Add(s); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/acquisition/sources/{s.Id}", new { s.Id });
        });
        g.MapGet("/sources/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.AcquisitionSources.AsNoTracking().Where(x => x.TenantId == tenantId)
                .Select(x => new { x.Id, x.Name, Type = x.Type.ToString(), x.Industry, x.Country, x.City,
                    x.Language, x.CollectionAllowed, x.ToolUsed }).ToListAsync(ct)));

        // Provider approval lifecycle
        g.MapPost("/providers/{tenantId:guid}/{provider}/transition", async (Guid tenantId, string provider,
            TransitionRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var code = Enum.Parse<DataProviderCode>(provider);
            var pa = await db.ProviderApprovals.FirstOrDefaultAsync(x => x.TenantId == tenantId && x.Provider == code, ct)
                     ?? new ProviderApproval(tenantId, code, r.Actor);
            pa.Transition(Enum.Parse<ProviderApprovalState>(r.ToState), r.Actor, r.Notes);
            if (db.Entry(pa).State == EntityState.Detached) db.ProviderApprovals.Add(pa);
            await db.SaveChangesAsync(ct);
            return Results.Ok(new { pa.Id, State = pa.State.ToString(), pa.CanDiscover, pa.CanEnrich, pa.CanOutreach });
        });
        g.MapGet("/providers/{tenantId:guid}", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
            Results.Ok(await db.ProviderApprovals.AsNoTracking().Where(x => x.TenantId == tenantId)
                .Select(x => new { Provider = x.Provider.ToString(), State = x.State.ToString(),
                    x.CanDiscover, x.CanEnrich, x.CanOutreach }).ToListAsync(ct)));

        // Import + Quarantine pipeline
        g.MapPost("/imports/run", async (RunImportRequest r, QuarantineService svc, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var rec = new ImportRecord(r.TenantId, Enum.Parse<DataProviderCode>(r.Provider), r.SourceRef,
                r.SourceUrl, r.CollectedAt, r.HasProvenance, r.HasConsentEvidence);
            var stage = svc.RunPipeline(rec, r.SourceValid, r.IsDuplicate, r.HumanApproved);
            db.ImportRecords.Add(rec); await db.SaveChangesAsync(ct);
            return Results.Ok(new { rec.Id, Stage = stage.ToString(), rec.SendingEnabled, rec.Reason });
        });

        // Intent signal (qualification only)
        g.MapPost("/intent", async (CreateIntentRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var sig = new IntentSignal(r.TenantId, r.SignalType, r.Source, r.TextReference, r.Industry,
                r.Location, r.Language, r.Confidence, Enum.Parse<AllowedNextAction>(r.NextAction));
            db.IntentSignals.Add(sig); await db.SaveChangesAsync(ct);
            return Results.Ok(new { sig.Id, NextAction = sig.NextAction.ToString(), grantsDirectOutreach = sig.GrantsDirectOutreach });
        });

        // Data-class guard check
        g.MapPost("/data-guard/evaluate", (GuardRequest r) =>
        {
            var d = DataClassGuard.EvaluateEnrichment(
                Enum.Parse<DataFieldKind>(r.SourceField), Enum.Parse<DataFieldKind>(r.TargetField), r.HasProvenConsent);
            return Results.Ok(new { d.Allowed, d.Reason,
                targetClass = DataClassGuard.Classify(Enum.Parse<DataFieldKind>(r.TargetField)).ToString() });
        });

        // Enrichment providers (Apollo/Lusha/ZoomInfo) — با حاکمیت: تأیید + گاردِ داده + رضایت
        g.MapGet("/enrichment/providers", () => Results.Ok(new[]
        {
            new { code = "ZoomInfo", scope = "Company-level B2B", personal = "requires proven consent", note = "Enterprise-priced" },
            new { code = "Apollo",   scope = "Company-level B2B", personal = "requires proven consent", note = "Economical ($50-100/mo)" },
            new { code = "Lusha",    scope = "Company-level B2B", personal = "requires proven consent", note = "Economical" }
        }));

        g.MapPost("/enrichment/evaluate", async (EnrichmentEvalRequest r,
            LeadPilot.Application.Discovery.EnrichmentGovernanceService svc, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var code = Enum.Parse<DataProviderCode>(r.Provider);
            var approval = await db.ProviderApprovals.FirstOrDefaultAsync(x => x.TenantId == r.TenantId && x.Provider == code, ct)
                           ?? new ProviderApproval(r.TenantId, code, "system");
            var d = svc.Evaluate(approval, Enum.Parse<DataFieldKind>(r.SourceField),
                Enum.Parse<DataFieldKind>(r.TargetField), r.HasProvenConsent);
            return Results.Ok(new { d.Allowed, d.Code, d.Reason });
        });

        // Lead Magnet + Tracked Link
        g.MapPost("/lead-magnets", async (CreateLeadMagnetRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var m = new LeadMagnet(r.TenantId, r.Title, Enum.Parse<LeadMagnetKind>(r.Kind), r.Industry, r.City, r.Language);
            db.LeadMagnets.Add(m); await db.SaveChangesAsync(ct);
            return Results.Created($"/api/acquisition/lead-magnets/{m.Id}", new { m.Id, m.RequiresConsentBeforeDelivery });
        });
        g.MapPost("/tracked-links", async (CreateTrackedLinkRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            try
            {
                var l = new TrackedLink(r.TenantId, r.Campaign, r.DestinationUrl, r.UtmSource, r.UtmMedium, r.UtmCampaign, r.ExpiresAt);
                db.TrackedLinks.Add(l); await db.SaveChangesAsync(ct);
                return Results.Created($"/api/acquisition/tracked-links/{l.Id}", new { l.Id, l.ShortCode });
            }
            catch (ArgumentException ex) { return Results.BadRequest(new { error = ex.Message }); }
        });
    }
}

public sealed record CreateSourceRequest(Guid TenantId, string Name, string Type, string Industry,
    string Country, string? City, string Language, bool CollectionAllowed, string ToolUsed);
public sealed record TransitionRequest(string ToState, string Actor, string? Notes);
public sealed record RunImportRequest(Guid TenantId, string Provider, string SourceRef, string? SourceUrl,
    DateTimeOffset CollectedAt, bool HasProvenance, bool HasConsentEvidence, bool SourceValid, bool IsDuplicate, bool HumanApproved);
public sealed record CreateIntentRequest(Guid TenantId, string SignalType, string Source, string TextReference,
    string Industry, string Location, string Language, int Confidence, string NextAction);
public sealed record GuardRequest(string SourceField, string TargetField, bool HasProvenConsent);
public sealed record EnrichmentEvalRequest(Guid TenantId, string Provider, string SourceField, string TargetField, bool HasProvenConsent);
public sealed record CreateLeadMagnetRequest(Guid TenantId, string Title, string Kind, string Industry, string City, string Language);
public sealed record CreateTrackedLinkRequest(Guid TenantId, string Campaign, string DestinationUrl,
    string UtmSource, string UtmMedium, string UtmCampaign, DateTimeOffset? ExpiresAt);
