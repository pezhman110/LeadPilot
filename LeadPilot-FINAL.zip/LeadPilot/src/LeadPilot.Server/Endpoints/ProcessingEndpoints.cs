using System.Text.Json;
using LeadPilot.Application.Processing;
using LeadPilot.Domain.Processing;

namespace LeadPilot.Server.Endpoints;

public static class ProcessingEndpoints
{
    public static void MapProcessingEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/processing").WithTags("Processing");

        // ساخت Jobِ دریافت اطلاعات تماس (Payload فقط شناسه‌ها)
        g.MapPost("/contact-discovery", async (EnqueueContactDiscoveryRequest r, IProcessingJobRepository repo, CancellationToken ct) =>
        {
            var payload = JsonSerializer.Serialize(r);
            var job = new ProcessingJob(
                ProcessingJobTypes.ContactDiscovery, payload,
                idempotencyKey: $"DISCOVER:{r.TenantId}:{r.ProjectId}:{r.ProspectId}",
                correlationId: Guid.NewGuid().ToString("N"),
                priority: r.ProspectScore >= 97 ? ProcessingJobPriority.Critical : ProcessingJobPriority.Normal,
                maximumAttempts: 4, scheduledAtUtc: DateTimeOffset.UtcNow,
                projectId: r.ProjectId, prospectId: r.ProspectId);
            bool created = await repo.EnqueueAsync(job, ct);
            return created
                ? Results.Accepted($"/api/processing/jobs/{job.Id}", new { job.Id, status = job.Status.ToString() })
                : Results.Conflict(new { error = "Job مشابه قبلاً ایجاد شده است.", idempotencyKey = job.IdempotencyKey });
        });

        // خلاصهٔ صف (فقط مدیر)
        g.MapGet("/summary", async (IProcessingJobRepository repo, CancellationToken ct) =>
            Results.Ok(await repo.GetSummaryAsync(ct)));
    }
}

public sealed record EnqueueContactDiscoveryRequest(
    Guid TenantId, Guid ProspectId, Guid ProjectId, string ProjectCode, bool IsCorporateProject,
    string? PersonName, string? CompanyName, string? CompanyDomain, string? SourceProfileUrl,
    string LanguageCode, string CountryCode, bool NeedsPhone, bool NeedsEmail,
    decimal MaximumTotalCostAed, int ProspectScore);
