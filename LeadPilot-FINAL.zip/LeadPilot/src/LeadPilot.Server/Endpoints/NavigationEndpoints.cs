using LeadPilot.Application.Navigation;
using LeadPilot.Domain.Navigation;

namespace LeadPilot.Server.Endpoints;

/// <summary>منوی داشبورد بر اساسِ نقش (گروه‌بندی‌شده روی مسیرِ فرآیند) + هزینهٔ حدودی هر مرحله.</summary>
public static class NavigationEndpoints
{
    public static void MapNavigationEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/navigation").WithTags("Navigation");

        // منوی نقش: فقط آیتم‌های مجاز، گروه‌بندی‌شده — UI از این می‌خواند، دکمه hardcode نمی‌کند.
        g.MapGet("/menu/{role}", (string role) =>
        {
            if (!Enum.TryParse<DashboardRole>(role, true, out var r)) return Results.BadRequest(new { error = "role نامعتبر." });
            var menu = DashboardBlueprint.MenuFor(r).Select(grp => new
            {
                stage = grp.Stage.ToString(),
                order = (int)grp.Stage,
                items = grp.Items.Select(i => new { i.Key, i.TitleFa, i.TitleEn, i.IsPrimary, i.Icon })
            });
            return Results.Ok(new { role = r.ToString(), groups = menu });
        });

        // هزینهٔ حدودی هر مرحله (تخمینی — نیازمندِ پیشنهادِ رسمیِ روز)
        g.MapGet("/costs", () => Results.Ok(new
        {
            note = "تخمینی و غیرتضمینی — از پیشنهادِ رسمیِ همان روز دریافت شود.",
            stages = DashboardBlueprint.CostEstimates.Select(c => new
            {
                stage = c.Stage.ToString(), c.Driver, c.MonthlyLowUsd, c.MonthlyHighUsd, c.Unit
            })
        }));
    }
}
