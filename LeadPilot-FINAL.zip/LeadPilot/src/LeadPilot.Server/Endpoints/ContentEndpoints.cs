using LeadPilot.Application.Content;
using LeadPilot.Domain.Content;

namespace LeadPilot.Server.Endpoints;

public static class ContentEndpoints
{
    public static void MapContentEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/content").WithTags("Content");

        g.MapPost("/headings", async (AddHeadingBody b, ContentService s, CancellationToken ct) =>
            Results.Ok(new { id = await s.AddHeadingAsync(b.ProjectId, b.Title, b.AudienceGroup, b.Language, ct) }));

        // غریال: چه داریم / چه کم داریم
        g.MapGet("/projects/{id:guid}/inventory", async (Guid id, ContentService s, CancellationToken ct) =>
            Results.Ok(await s.ReviewInventoryAsync(id, ["ar", "fa", "en", "tr", "fr", "hi"], ct)));

        // تولید محتوا (متن/اسکریپت توسط مغزِ AI)
        g.MapPost("/generate", async (GenerateBody b, ContentService s, CancellationToken ct) =>
            Results.Ok(await s.GenerateAsync(b.ProjectId, b.Heading, b.AudienceGroup, b.Language,
                b.PriorAdModel, b.MarketTrends, (ContentAssetType)b.TargetType, ct)));

        g.MapPost("/landing", async (LandingBody b, ContentService s, CancellationToken ct) =>
            Results.Ok(new { id = await s.CreateLandingAsync(b.ProjectId, b.Slug, b.TemplateCode, b.Language, b.Headline, ct) }));

        g.MapPost("/campaigns", async (CampaignBody b, ContentService s, CancellationToken ct) =>
            Results.Ok(new { id = await s.CreateCampaignAsync(b.ProjectId, b.Name, (CampaignScope)b.Scope, b.LandingPageId, ct) }));

        g.MapPost("/campaigns/{id:guid}/start", async (Guid id, ContentService s, CancellationToken ct) =>
            await s.StartCampaignAsync(id, ct) ? Results.Ok() : Results.NotFound());

        // پرزنت اختصاصی
        g.MapPost("/presentations", async (PresentationBody b, ContentService s, CancellationToken ct) =>
            Results.Ok(new { id = await s.BuildPresentationAsync(b.ProspectId, b.ProjectId, (PresenterKind)b.Presenter,
                b.Language, b.Heading, b.AudienceGroup, b.PriorAdModel, b.MarketTrends, ct) }));

        g.MapPost("/presentations/{id:guid}/evaluate", async (Guid id, EvaluateBody b, ContentService s, CancellationToken ct) =>
            await s.EvaluatePresentationAsync(id, b.QualityScore, ct) ? Results.Ok() : Results.NotFound());
    }
}

public sealed record AddHeadingBody(Guid ProjectId, string Title, string AudienceGroup, string Language);
public sealed record GenerateBody(Guid ProjectId, string Heading, string AudienceGroup, string Language,
    string PriorAdModel, string MarketTrends, int TargetType);
public sealed record LandingBody(Guid ProjectId, string Slug, string TemplateCode, string Language, string Headline);
public sealed record CampaignBody(Guid ProjectId, string Name, int Scope, Guid LandingPageId);
public sealed record PresentationBody(Guid ProspectId, Guid ProjectId, int Presenter, string Language,
    string Heading, string AudienceGroup, string PriorAdModel, string MarketTrends);
public sealed record EvaluateBody(int QualityScore);
