using LeadPilot.Application.Consent;
using LeadPilot.Application.Partners;
using LeadPilot.Application.Targets;

namespace LeadPilot.Server.Endpoints;

public static class ModuleEndpoints
{
    public static void MapConsentEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/consent").WithTags("Consent");
        g.MapPost("/contacts", async (CreateContactRequest r, ConsentService s, CancellationToken ct) =>
            Results.Ok(await s.AddContactAsync(r, ct)));
        g.MapGet("/prospects/{id:guid}/contacts", async (Guid id, ConsentService s, CancellationToken ct) =>
            Results.Ok(await s.ListContactsAsync(id, ct)));
        g.MapPost("/invite", async (InviteRequest r, ConsentService s, CancellationToken ct) =>
            Results.Ok(await s.InviteAsync(r, ct)));
        g.MapPost("/journeys/{id:guid}/consent", async (Guid id, ConsentService s, CancellationToken ct) =>
            (await s.ConsentAsync(id, ct)) is { } j ? Results.Ok(j) : Results.NotFound());
        g.MapPost("/journeys/{id:guid}/decline", async (Guid id, ConsentService s, CancellationToken ct) =>
            (await s.DeclineAsync(id, ct)) is { } j ? Results.Ok(j) : Results.NotFound());
        g.MapPost("/journeys/{id:guid}/no-response", async (Guid id, ConsentService s, CancellationToken ct) =>
            (await s.NoResponseAsync(id, ct)) is { } j ? Results.Ok(j) : Results.NotFound());
        g.MapPost("/contacts/{id:guid}/manager-block", async (Guid id, ManagerBlockBody b, ConsentService s, CancellationToken ct) =>
            (await s.ManagerBlockAsync(id, b.Reason, ct)) is { } c ? Results.Ok(c) : Results.NotFound());
        g.MapPost("/contacts/{id:guid}/manager-unblock", async (Guid id, ConsentService s, CancellationToken ct) =>
            (await s.ManagerUnblockAsync(id, ct)) is { } c ? Results.Ok(c) : Results.NotFound());
    }

    public static void MapPartnerEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/partners").WithTags("Partners");
        g.MapGet("/", async (PartnerService s, CancellationToken ct) => Results.Ok(await s.ListAsync(ct)));
        g.MapPost("/", async (CreatePartnerRequest r, PartnerService s, CancellationToken ct) =>
        {
            try { return Results.Ok(await s.CreateAsync(r, ct)); }
            catch (ArgumentException ex) { return Results.BadRequest(new { error = ex.Message }); }
        });
        g.MapPost("/recommend", async (RecommendRequest r, PartnerService s, CancellationToken ct) =>
            Results.Ok(await s.RecommendAsync(r, ct)));
        g.MapPost("/agreements", async (CreateAgreementRequest r, PartnerService s, CancellationToken ct) =>
            Results.Ok(new { id = await s.CreateAgreementAsync(r, ct) }));
        g.MapPost("/agreements/{id:guid}/approve", async (Guid id, ApproveAgreementRequest r, PartnerService s, CancellationToken ct) =>
        {
            try { return await s.ApproveAgreementAsync(id, r, ct) ? Results.Ok() : Results.NotFound(); }
            catch (ArgumentException ex) { return Results.BadRequest(new { error = ex.Message }); }
        });
    }

    public static void MapTargetEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/targets").WithTags("Targets");
        g.MapPost("/", async (CreateTargetRequest r, TargetService s, CancellationToken ct) =>
        {
            try { return Results.Ok(await s.CreateAsync(r, ct)); }
            catch (ArgumentException ex) { return Results.BadRequest(new { error = ex.Message }); }
        });
        g.MapGet("/projects/{id:guid}", async (Guid id, TargetService s, CancellationToken ct) =>
            Results.Ok(await s.ListAsync(id, ct)));
        g.MapPost("/plan", async (PlanRequest r, TargetService s, CancellationToken ct) =>
            Results.Ok(await s.PlanAsync(r, ct)));
    }
}

public sealed record ManagerBlockBody(string Reason);
