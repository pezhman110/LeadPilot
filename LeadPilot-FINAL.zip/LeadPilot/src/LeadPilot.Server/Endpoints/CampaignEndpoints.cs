using LeadPilot.Application.Campaigns;
using LeadPilot.Domain.Campaigns;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

/// <summary>Launcher کمپین: یک دکمه per زمینه (هتل/برج/مال/…) و کلِ فرآیند پشتِ آن اجرا می‌شود.</summary>
public static class CampaignEndpoints
{
    public static void MapCampaignEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/campaigns").WithTags("Campaigns");

        // تاکتیک‌های پیش‌فرضِ هر زمینه (برای پرکردنِ خودکارِ دکمه)
        g.MapGet("/contexts/{context}/tactics", (string context) =>
        {
            if (!Enum.TryParse<CampaignContext>(context, true, out var c)) return Results.BadRequest(new { error = "context نامعتبر." });
            return Results.Ok(new { context = c.ToString(),
                tactics = CampaignLauncherService.DefaultTactics(c).Select(t => t.ToString()) });
        });

        // اجرای دکمه: زمینه + شهر + بودجه + سقفِ درصد → مسیرِ آمادهٔ اجرا پشتِ دکمه
        g.MapPost("/launch", async (LaunchRequest r, CampaignLauncherService svc, LeadPilotDbContext db, CancellationToken ct) =>
        {
            if (!Enum.TryParse<CampaignContext>(r.Context, true, out var c))
                return Results.BadRequest(new { error = "context نامعتبر." });
            var tactics = (r.Tactics is { Length: > 0 })
                ? r.Tactics.Select(Enum.Parse<LaunchTactic>).ToList()
                : CampaignLauncherService.DefaultTactics(c).ToList();

            var preset = new CampaignPreset(r.TenantId, c, r.DisplayName, r.City,
                r.MonthlyBudgetUsd, r.MaxCostPerLeadPercent, tactics);
            db.CampaignPresets.Add(preset);
            await db.SaveChangesAsync(ct);

            var plan = svc.BuildPlan(preset);
            return Results.Ok(new
            {
                preset.Id,
                context = plan.Context.ToString(),
                plan.City,
                plan.MonthlyBudgetUsd,
                maxCostPerLeadUsd = plan.MaxCostPerLeadUsd,
                steps = plan.Steps.Select(s => new { s.Order, s.Key, s.Note })
            });
        });

        // بررسیِ سقفِ هزینه (BudgetGuard)
        g.MapGet("/{id:guid}/budget-check", async (Guid id, decimal costPerLead, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var p = await db.CampaignPresets.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (p is null) return Results.NotFound();
            return Results.Ok(new { within = p.IsWithinBudget(costPerLead), cap = p.MaxCostPerLeadUsd });
        });
    }
}

public sealed record LaunchRequest(Guid TenantId, string Context, string DisplayName, string City,
    decimal MonthlyBudgetUsd, decimal MaxCostPerLeadPercent, string[]? Tactics);
