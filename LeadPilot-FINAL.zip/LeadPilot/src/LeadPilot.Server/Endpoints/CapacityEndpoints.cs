using LeadPilot.Domain.Capacity;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Endpoints;

public static class CapacityEndpoints
{
    public static void MapCapacityEndpoints(this IEndpointRouteBuilder app)
    {
        var g = app.MapGroup("/api/capacity").WithTags("Capacity");

        // ساخت برنامهٔ روزانه با سهمیه‌ها
        g.MapPost("/plans", async (CreatePlanRequest r, LeadPilotDbContext db, CancellationToken ct) =>
        {
            try
            {
                var plan = new DailyCapacityPlan(
                    r.TenantId, DateOnly.Parse(r.BusinessDate),
                    TimeOnly.Parse(r.WindowStartUtc), TimeOnly.Parse(r.WindowEndUtc),
                    r.TargetSignals, r.TargetContacts, r.TargetConsents, r.DesignCapacity, r.CreatedBy);
                foreach (var q in r.Quotas)
                    plan.AddQuota(q.GroupCode, q.ProjectId, q.ContactTarget, q.ConsentTarget, q.Priority, q.IsFlexible);
                db.DailyCapacityPlans.Add(plan);
                await db.SaveChangesAsync(ct);
                return Results.Ok(new { plan.Id, status = plan.Status.ToString() });
            }
            catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
        });

        g.MapPost("/plans/{id:guid}/schedule", async (Guid id, LeadPilotDbContext db,
            LeadPilot.Application.Connections.IConnectorHealthService health, CancellationToken ct) =>
        {
            var plan = await db.DailyCapacityPlans.Include(x => x.Quotas).FirstOrDefaultAsync(x => x.Id == id, ct);
            if (plan is null) return Results.NotFound();

            // گیتِ آمادگی (سند بخش ۱۴): با اتصالِ حیاتیِ قرمز، برنامهٔ روزانه شروع نمی‌شود.
            var readiness = await health.CheckStartupReadinessAsync(plan.TenantId, ct);
            if (!readiness.CanStart)
                return Results.BadRequest(new
                {
                    error = "اتصال‌های حیاتی آماده نیستند.",
                    readiness.BlockingConnectors,
                    readiness.Warnings
                });

            try { plan.Schedule(); await db.SaveChangesAsync(ct); return Results.Ok(new { status = plan.Status.ToString() }); }
            catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
        });

        g.MapPost("/plans/{id:guid}/pause", async (Guid id, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var plan = await db.DailyCapacityPlans.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (plan is null) return Results.NotFound();
            try { plan.Pause(); await db.SaveChangesAsync(ct); return Results.Ok(); }
            catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
        });

        g.MapGet("/plans/today", async (Guid tenantId, LeadPilotDbContext db, CancellationToken ct) =>
        {
            var today = DateOnly.FromDateTime(DateTime.UtcNow);
            var plan = await db.DailyCapacityPlans.Include(x => x.Quotas)
                .FirstOrDefaultAsync(x => x.TenantId == tenantId && x.BusinessDate == today, ct);
            return plan is null ? Results.NotFound() : Results.Ok(plan);
        });
    }
}

public sealed record CreatePlanRequest(
    Guid TenantId, string BusinessDate, string WindowStartUtc, string WindowEndUtc,
    int TargetSignals, int TargetContacts, int TargetConsents, int DesignCapacity, string CreatedBy,
    List<QuotaInput> Quotas);
public sealed record QuotaInput(string GroupCode, Guid? ProjectId, int ContactTarget, int ConsentTarget, int Priority, bool IsFlexible);
