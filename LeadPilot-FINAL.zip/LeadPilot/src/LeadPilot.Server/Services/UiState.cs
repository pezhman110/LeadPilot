namespace LeadPilot.Server.Services;

public sealed class UiState
{
    public string Lang { get; private set; } = "fa";
    public string Dir => Lang == "fa" ? "rtl" : "ltr";
    public event Action? Changed;
    public void Toggle() { Lang = Lang == "fa" ? "en" : "fa"; Changed?.Invoke(); }
    public string T(string fa, string en) => Lang == "fa" ? fa : en;
}
