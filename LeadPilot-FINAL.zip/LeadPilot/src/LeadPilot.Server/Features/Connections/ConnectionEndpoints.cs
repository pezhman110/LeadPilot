using LeadPilot.Application.Connections;
using LeadPilot.Domain.Connections;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Server.Features.Connections;

/// <summary>
/// Connection Center واقعی (سند بخش ۱۰). ساخت/پیکربندی/فعال‌سازی/آزمایش/گیتِ آمادگی.
/// نکتهٔ امنیتی: API هرگز مقدارِ Secret را نمی‌گیرد و برنمی‌گرداند؛ فقط SecretReference.
/// </summary>
public static class ConnectionEndpoints
{
    public static IEndpointRouteBuilder MapConnectionEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/connections").WithTags("Connections");
        group.MapGet("/tenant/{tenantId:guid}", GetAll);
        group.MapPost("/", Create);
        group.MapPut("/{id:guid}/configuration", Configure);
        group.MapPost("/{id:guid}/enable", Enable);
        group.MapPost("/{id:guid}/disable", Disable);
        group.MapPost("/{id:guid}/test", Test);
        group.MapPost("/tenant/{tenantId:guid}/test-all", TestAll);
        group.MapGet("/tenant/{tenantId:guid}/readiness", Readiness);
        return app;
        // در Production: .RequireAuthorization("connections.manage")
    }

    private static async Task<IResult> GetAll(Guid tenantId, LeadPilotDbContext db, CancellationToken ct)
    {
        var connectors = await db.ConnectorDefinitions.AsNoTracking()
            .Where(x => x.TenantId == tenantId).OrderBy(x => x.ExecutionOrder).ToArrayAsync(ct);
        return Results.Ok(connectors.Select(Map));
    }

    private static async Task<IResult> Create(CreateConnectorRequest request, LeadPilotDbContext db, CancellationToken ct)
    {
        if (!Enum.TryParse(request.Category, true, out ConnectorCategory category) ||
            !Enum.TryParse(request.CostLevel, true, out ConnectorCostLevel costLevel))
            return Results.BadRequest(new { error = "Category یا CostLevel معتبر نیست." });

        string code = request.Code.Trim().ToUpperInvariant();
        bool exists = await db.ConnectorDefinitions.AnyAsync(
            x => x.TenantId == request.TenantId && x.Code == code, ct);
        if (exists) return Results.Conflict(new { error = "این اتصال قبلاً ثبت شده است." });

        var connector = new ConnectorDefinition(request.TenantId, code, request.DisplayName,
            category, costLevel, request.ExecutionOrder, request.IsCritical,
            request.SupportsCorporateProjects, request.SupportsPersonalProjects);
        db.ConnectorDefinitions.Add(connector);
        await db.SaveChangesAsync(ct);
        return Results.Created($"/api/connections/{connector.Id}", Map(connector));
    }

    private static async Task<IResult> Configure(Guid id, ConfigureConnectorRequest request, LeadPilotDbContext db, CancellationToken ct)
    {
        var connector = await db.ConnectorDefinitions.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (connector is null) return Results.NotFound();
        connector.Configure(request.BaseUrl, request.SecretReference,
            request.MaximumConcurrency, request.RequestsPerMinute, request.TimeoutSeconds, request.MaximumRetries,
            request.MaximumDailyCostAed, request.DailyQuota, DateTimeOffset.UtcNow);
        await db.SaveChangesAsync(ct);
        return Results.Ok(Map(connector));
    }

    private static async Task<IResult> Enable(Guid id, LeadPilotDbContext db, CancellationToken ct)
    {
        var connector = await db.ConnectorDefinitions.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (connector is null) return Results.NotFound();
        connector.Enable(DateTimeOffset.UtcNow);
        await db.SaveChangesAsync(ct);
        return Results.Ok(Map(connector));
    }

    private static async Task<IResult> Disable(Guid id, LeadPilotDbContext db, CancellationToken ct)
    {
        var connector = await db.ConnectorDefinitions.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (connector is null) return Results.NotFound();
        connector.Disable(DateTimeOffset.UtcNow);
        await db.SaveChangesAsync(ct);
        return Results.Ok(Map(connector));
    }

    private static async Task<IResult> Test(Guid id, IConnectorHealthService service, CancellationToken ct)
    {
        try { return Results.Ok(await service.TestAsync(id, ct)); }
        catch (InvalidOperationException exception) { return Results.NotFound(new { error = exception.Message }); }
    }

    private static async Task<IResult> TestAll(Guid tenantId, IConnectorHealthService service, CancellationToken ct) =>
        Results.Ok(await service.TestAllAsync(tenantId, ct));

    private static async Task<IResult> Readiness(Guid tenantId, IConnectorHealthService service, CancellationToken ct) =>
        Results.Ok(await service.CheckStartupReadinessAsync(tenantId, ct));

    private static ConnectorListItem Map(ConnectorDefinition c) => new(
        c.Id, c.Code, c.DisplayName, c.Category.ToString(), c.CostLevel.ToString(), c.Status.ToString(),
        c.IsEnabled, c.IsCritical, c.ExecutionOrder, c.RemainingDailyQuota, c.LastHealthCheckAtUtc, c.LastHealthMessage);
}
