namespace LeadPilot.Server.Features.Connections;

public sealed record CreateConnectorRequest(
    Guid TenantId, string Code, string DisplayName, string Category, string CostLevel,
    int ExecutionOrder, bool IsCritical, bool SupportsCorporateProjects, bool SupportsPersonalProjects);

public sealed record ConfigureConnectorRequest(
    string? BaseUrl, string? SecretReference,
    int MaximumConcurrency, int RequestsPerMinute, int TimeoutSeconds, int MaximumRetries,
    decimal? MaximumDailyCostAed, int? DailyQuota);

public sealed record ConnectorListItem(
    Guid Id, string Code, string DisplayName, string Category, string CostLevel, string Status,
    bool IsEnabled, bool IsCritical, int ExecutionOrder, int? RemainingDailyQuota,
    DateTimeOffset? LastHealthCheckAtUtc, string? LastHealthMessage);
