using LeadPilot.Application.Abstractions;
using LeadPilot.Application.Compliance;
using LeadPilot.Application.Projects;
using LeadPilot.Application.Scoring;
using LeadPilot.Application.Search;
using LeadPilot.Infrastructure;
using LeadPilot.Infrastructure.Persistence;
using LeadPilot.Server.Components;
using LeadPilot.Server.Endpoints;
using LeadPilot.Server.Features.Connections;
using LeadPilot.Server.Hubs;
using LeadPilot.Server.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.AddSimpleConsole(o => { o.SingleLine = true; o.TimestampFormat = "HH:mm:ss "; });

// Blazor Web App (interactive server) + SignalR
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSignalR();

// Infrastructure (Npgsql + repositories + connectors)
builder.Services.AddInfrastructure(builder.Configuration);

// Application services — Phase 1
builder.Services.AddScoped<ProjectService>();

// Application services — Phase 2 (search engine)
builder.Services.AddScoped<IComplianceGateway, ComplianceGateway>();
builder.Services.AddScoped<IScoringEngine, RuleScoringEngine>();
builder.Services.AddScoped<ILanguageDetector, LanguageDetector>();
builder.Services.AddScoped<IQueryBuilder, QueryBuilder>();
builder.Services.AddScoped<ILiveNotifier, SignalRLiveNotifier>();
builder.Services.AddScoped<SearchOrchestrator>();
builder.Services.AddScoped<LeadPilot.Application.Reporting.ManagementReportService>();
builder.Services.AddScoped<LeadPilot.Application.Consent.ConsentService>();
builder.Services.AddScoped<LeadPilot.Application.Partners.PartnerService>();
builder.Services.AddScoped<LeadPilot.Application.Targets.TargetService>();
builder.Services.AddScoped<LeadPilot.Application.Content.ContentService>();

// UI state (bilingual)
builder.Services.AddScoped<UiState>();

// Health checks + API docs
builder.Services.AddHealthChecks().AddDbContextCheck<LeadPilotDbContext>("database");
builder.Services.AddOpenApi();

var app = builder.Build();

// اجرای Migration هنگام بالا آمدن (نقطهٔ کنترل)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<LeadPilotDbContext>();
    db.Database.Migrate();
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapOpenApi();
app.MapHealthChecks("/health");
app.MapProjectEndpoints();
app.MapSearchEndpoints();
app.MapReportEndpoints();
app.MapConsentEndpoints();
app.MapPartnerEndpoints();
app.MapTargetEndpoints();
app.MapContentEndpoints();
app.MapProcessingEndpoints();
app.MapCapacityEndpoints();
app.MapConnectionEndpoints();
app.MapCommunicationEndpoints();
app.MapAgentEndpoints();
app.MapRoutingEndpoints();
app.MapDiscoveryEndpoints();
app.MapImportEndpoints();
app.MapCommunityEndpoints();
app.MapNavigationEndpoints();
app.MapCampaignEndpoints();
app.MapAcquisitionEndpoints();
app.MapHub<LiveHub>("/hubs/live");
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
