namespace LeadPilot.Domain.Content;

// ── صفحهٔ فرود / تک‌صفحه (قالب از صفحه جداست) ──
public sealed class LandingPage
{
    private LandingPage() { }
    public LandingPage(Guid projectId, string slug, string templateCode, string language, string headline)
    {
        if (string.IsNullOrWhiteSpace(slug)) throw new ArgumentException("slug الزامی است.");
        Id = Guid.NewGuid(); ProjectId = projectId; Slug = slug.Trim().ToLowerInvariant();
        TemplateCode = templateCode; Language = language.Trim().ToLowerInvariant();
        Headline = headline; HasOptInForm = true; IsPublished = false; CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string Slug { get; private set; } = string.Empty;
    public string TemplateCode { get; private set; } = string.Empty; // قالب جدا از محتوا
    public string Language { get; private set; } = "fa";
    public string Headline { get; private set; } = string.Empty;
    public bool HasOptInForm { get; private set; }   // همیشه فرم رضایت دارد
    public bool IsPublished { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public void Publish() => IsPublished = true;
}

public enum CampaignScope { SmallDedicated = 0, LargeGroup = 1 }
public enum CampaignStatus { Draft = 0, Running = 1, Paused = 2, Completed = 3 }

// ── کمپین (گروه کوچک/اختصاصی یا بزرگ) ──
public sealed class Campaign
{
    private Campaign() { }
    public Campaign(Guid projectId, string name, CampaignScope scope, Guid landingPageId)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام کمپین الزامی است.");
        Id = Guid.NewGuid(); ProjectId = projectId; Name = name.Trim();
        Scope = scope; LandingPageId = landingPageId; Status = CampaignStatus.Draft;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public CampaignScope Scope { get; private set; }
    public Guid LandingPageId { get; private set; }
    public CampaignStatus Status { get; private set; }
    public int Sent { get; private set; }
    public int OptIns { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public void Start() { if (Status is CampaignStatus.Draft or CampaignStatus.Paused) Status = CampaignStatus.Running; }
    public void Pause() { if (Status == CampaignStatus.Running) Status = CampaignStatus.Paused; }
    public void Complete() => Status = CampaignStatus.Completed;
    public void RecordSent(int n) => Sent += n;
    public void RecordOptIn() => OptIns++;
    public decimal OptInRate => Sent == 0 ? 0 : Math.Round((decimal)OptIns / Sent * 100, 2);
}

// ── پرزنت اختصاصی (ارائه توسط AI یا کارشناس) ──
public enum PresenterKind { Ai = 0, HumanExpert = 1 }
public enum PresentationStatus { Draft = 0, Ready = 1, Delivered = 2, Evaluated = 3 }

public sealed class Presentation
{
    private Presentation() { }
    public Presentation(Guid prospectId, Guid projectId, PresenterKind presenter, string language)
    {
        Id = Guid.NewGuid(); ProspectId = prospectId; ProjectId = projectId;
        Presenter = presenter; Language = language.Trim().ToLowerInvariant();
        Status = PresentationStatus.Draft; CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid ProjectId { get; private set; }
    public PresenterKind Presenter { get; private set; }
    public string Language { get; private set; } = "fa";
    public string? ScriptRef { get; private set; }     // اسکریپت اختصاصی (تولید AI متن)
    public PresentationStatus Status { get; private set; }
    public int? QualityScore { get; private set; }     // ارزیابی کیفیت جلسه
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public void AttachScript(string scriptRef) { ScriptRef = scriptRef; Status = PresentationStatus.Ready; }
    public void MarkDelivered() { if (Status == PresentationStatus.Ready) Status = PresentationStatus.Delivered; }
    public void Evaluate(int score)
    {
        if (score is < 0 or > 100) throw new ArgumentOutOfRangeException(nameof(score));
        QualityScore = score; Status = PresentationStatus.Evaluated;
    }
}
