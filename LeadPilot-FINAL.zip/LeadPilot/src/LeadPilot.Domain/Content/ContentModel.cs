namespace LeadPilot.Domain.Content;

// ── سرفصل محتوایی ──
public sealed class ContentHeading
{
    private ContentHeading() { }
    public ContentHeading(Guid projectId, string title, string audienceGroup, string language)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("عنوان سرفصل الزامی است.");
        Id = Guid.NewGuid(); ProjectId = projectId; Title = title.Trim();
        AudienceGroup = audienceGroup; Language = language.Trim().ToLowerInvariant();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string AudienceGroup { get; private set; } = string.Empty;
    public string Language { get; private set; } = "fa";
    public DateTimeOffset CreatedAtUtc { get; private set; }
}

public enum ContentAssetType { Text = 0, Banner = 1, Carousel = 2, Motion = 3, Video = 4, Audio = 5, Podcast = 6, LandingCopy = 7 }
public enum ContentStatus { Draft = 0, InReview = 1, Approved = 2, Published = 3, Archived = 4, Missing = 5 }

// ── فایل محتوا در آرشیو (هر فایل با متادیتا و وضعیت) ──
public sealed class ContentAsset
{
    private ContentAsset() { }
    public ContentAsset(Guid projectId, ContentAssetType type, string language, string title, string? storageRef)
    {
        Id = Guid.NewGuid(); ProjectId = projectId; Type = type;
        Language = language.Trim().ToLowerInvariant(); Title = title.Trim();
        StorageRef = storageRef; Status = ContentStatus.Draft; CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public ContentAssetType Type { get; private set; }
    public string Language { get; private set; } = string.Empty;
    public string Title { get; private set; } = string.Empty;
    public string? StorageRef { get; private set; }   // مرجع فایل (Drive/S3) — تولید بیرونی
    public string? SourceHeadingId { get; private set; }
    public ContentStatus Status { get; private set; }
    public bool IsAiGenerated { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public void Approve() => Status = ContentStatus.Approved;
    public void Publish() { if (Status == ContentStatus.Approved) Status = ContentStatus.Published; }
    public void MarkAiGenerated() => IsAiGenerated = true;
    public void AttachStorage(string storageRef) => StorageRef = storageRef;
}
