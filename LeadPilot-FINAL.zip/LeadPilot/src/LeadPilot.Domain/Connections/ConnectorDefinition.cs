namespace LeadPilot.Domain.Connections;

public enum ConnectorCategory
{
    InternalData = 1,
    Search = 2,
    CorporateWebsite = 3,
    Maps = 4,
    ContactProvider = 5,
    LeadForm = 6,
    Messaging = 7,
    ArtificialIntelligence = 8,
    MobileContacts = 9,
    Meeting = 10,
    Storage = 11
}

public enum ConnectorCostLevel { Free = 1, Low = 2, Medium = 3, Premium = 4 }

public enum ConnectorStatus
{
    NotConfigured = 1,
    Testing = 2,
    Healthy = 3,
    Degraded = 4,
    RateLimited = 5,
    AuthenticationFailed = 6,
    QuotaExceeded = 7,
    Unavailable = 8,
    Disabled = 9
}

/// <summary>
/// تعریفِ یک اتصال (Connector) در Connection Center. مطابق سند بخش ۱.
/// نکتهٔ امنیتی: رمز/Token/API Key هرگز اینجا ذخیره نمی‌شود؛ فقط SecretReference
/// (نامِ Secret در Secret Store) نگهداری می‌شود.
/// RowVersion به‌صورت Postgres xmin (uint) — تطبیق با استکِ قفل‌شده.
/// </summary>
public sealed class ConnectorDefinition
{
    private ConnectorDefinition() { }

    public ConnectorDefinition(
        Guid tenantId, string code, string displayName,
        ConnectorCategory category, ConnectorCostLevel costLevel,
        int executionOrder, bool isCritical,
        bool supportsCorporateProjects, bool supportsPersonalProjects)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("شناسه سازمان معتبر نیست.");
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("کد اتصال الزامی است.");
        if (string.IsNullOrWhiteSpace(displayName)) throw new ArgumentException("نام اتصال الزامی است.");
        if (executionOrder is < 1 or > 10_000) throw new ArgumentOutOfRangeException(nameof(executionOrder));

        Id = Guid.NewGuid();
        TenantId = tenantId;
        Code = code.Trim().ToUpperInvariant();
        DisplayName = displayName.Trim();
        Category = category;
        CostLevel = costLevel;
        ExecutionOrder = executionOrder;
        IsCritical = isCritical;
        SupportsCorporateProjects = supportsCorporateProjects;
        SupportsPersonalProjects = supportsPersonalProjects;
        IsEnabled = false;
        Status = ConnectorStatus.NotConfigured;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string DisplayName { get; private set; } = string.Empty;
    public ConnectorCategory Category { get; private set; }
    public ConnectorCostLevel CostLevel { get; private set; }
    public int ExecutionOrder { get; private set; }
    public bool IsCritical { get; private set; }
    public bool SupportsCorporateProjects { get; private set; }
    public bool SupportsPersonalProjects { get; private set; }
    public bool IsEnabled { get; private set; }
    public ConnectorStatus Status { get; private set; }

    // فقط نامِ Secret نگهداری می‌شود، نه مقدارِ Token/API Key.
    public string? SecretReference { get; private set; }
    public string? BaseUrl { get; private set; }
    public int MaximumConcurrency { get; private set; } = 1;
    public int RequestsPerMinute { get; private set; } = 10;
    public int TimeoutSeconds { get; private set; } = 30;
    public int MaximumRetries { get; private set; } = 3;
    public decimal? MaximumDailyCostAed { get; private set; }
    public int? DailyQuota { get; private set; }
    public int? RemainingDailyQuota { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? UpdatedAtUtc { get; private set; }
    public DateTimeOffset? LastHealthCheckAtUtc { get; private set; }
    public string? LastHealthMessage { get; private set; }
    public uint RowVersion { get; private set; }

    public void Configure(
        string? baseUrl, string? secretReference,
        int maximumConcurrency, int requestsPerMinute, int timeoutSeconds, int maximumRetries,
        decimal? maximumDailyCostAed, int? dailyQuota, DateTimeOffset nowUtc)
    {
        if (maximumConcurrency is < 1 or > 100) throw new ArgumentOutOfRangeException(nameof(maximumConcurrency));
        if (requestsPerMinute is < 1 or > 100_000) throw new ArgumentOutOfRangeException(nameof(requestsPerMinute));
        if (timeoutSeconds is < 1 or > 300) throw new ArgumentOutOfRangeException(nameof(timeoutSeconds));
        if (maximumRetries is < 0 or > 10) throw new ArgumentOutOfRangeException(nameof(maximumRetries));
        if (maximumDailyCostAed < 0) throw new ArgumentOutOfRangeException(nameof(maximumDailyCostAed));
        if (dailyQuota < 0) throw new ArgumentOutOfRangeException(nameof(dailyQuota));

        BaseUrl = NormalizeOptional(baseUrl);
        SecretReference = NormalizeOptional(secretReference);
        MaximumConcurrency = maximumConcurrency;
        RequestsPerMinute = requestsPerMinute;
        TimeoutSeconds = timeoutSeconds;
        MaximumRetries = maximumRetries;
        MaximumDailyCostAed = maximumDailyCostAed;
        DailyQuota = dailyQuota;
        UpdatedAtUtc = nowUtc;
        Status = ConnectorStatus.NotConfigured;
    }

    public void Enable(DateTimeOffset nowUtc) { IsEnabled = true; UpdatedAtUtc = nowUtc; }

    public void Disable(DateTimeOffset nowUtc)
    {
        IsEnabled = false;
        Status = ConnectorStatus.Disabled;
        UpdatedAtUtc = nowUtc;
    }

    public void MarkTesting(DateTimeOffset nowUtc)
    {
        if (!IsEnabled) throw new InvalidOperationException("اتصال غیرفعال است.");
        Status = ConnectorStatus.Testing;
        LastHealthCheckAtUtc = nowUtc;
    }

    public void RecordHealth(ConnectorStatus status, string? message, int? remainingDailyQuota, DateTimeOffset nowUtc)
    {
        if (status == ConnectorStatus.Testing) throw new ArgumentException("نتیجه نمی‌تواند Testing باشد.");
        Status = IsEnabled ? status : ConnectorStatus.Disabled;
        LastHealthMessage = NormalizeOptional(message);
        RemainingDailyQuota = remainingDailyQuota;
        LastHealthCheckAtUtc = nowUtc;
        UpdatedAtUtc = nowUtc;
    }

    private static string? NormalizeOptional(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
