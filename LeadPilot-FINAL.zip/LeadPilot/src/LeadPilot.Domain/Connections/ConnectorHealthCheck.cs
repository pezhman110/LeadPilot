namespace LeadPilot.Domain.Connections;

/// <summary>تاریخچهٔ یک Health Check برای یک اتصال. مطابق سند بخش ۲.</summary>
public sealed class ConnectorHealthCheck
{
    private ConnectorHealthCheck() { }

    public ConnectorHealthCheck(
        Guid connectorDefinitionId, ConnectorStatus status, long latencyMilliseconds,
        int? remainingDailyQuota, string? errorCode, string? message, DateTimeOffset checkedAtUtc)
    {
        if (connectorDefinitionId == Guid.Empty) throw new ArgumentException("شناسه اتصال معتبر نیست.");
        if (latencyMilliseconds < 0) throw new ArgumentOutOfRangeException(nameof(latencyMilliseconds));

        Id = Guid.NewGuid();
        ConnectorDefinitionId = connectorDefinitionId;
        Status = status;
        LatencyMilliseconds = latencyMilliseconds;
        RemainingDailyQuota = remainingDailyQuota;
        ErrorCode = Normalize(errorCode, 100);
        Message = Normalize(message, 2000);
        CheckedAtUtc = checkedAtUtc;
    }

    public Guid Id { get; private set; }
    public Guid ConnectorDefinitionId { get; private set; }
    public ConnectorStatus Status { get; private set; }
    public long LatencyMilliseconds { get; private set; }
    public int? RemainingDailyQuota { get; private set; }
    public string? ErrorCode { get; private set; }
    public string? Message { get; private set; }
    public DateTimeOffset CheckedAtUtc { get; private set; }

    private static string? Normalize(string? value, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        string result = value.Trim();
        return result.Length <= maximumLength ? result : result[..maximumLength];
    }
}
