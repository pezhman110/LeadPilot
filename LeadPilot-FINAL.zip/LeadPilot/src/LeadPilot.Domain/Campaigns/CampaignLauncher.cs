namespace LeadPilot.Domain.Campaigns;

/// <summary>زمینهٔ کمپین — همان «دکمه‌ها»یِ سطحِ بالا (هتل/برج/مال/…)، نه ۷۰ فرمِ تودرتو.</summary>
public enum CampaignContext
{
    Hotels = 1, ResidentialTowers = 2, Malls = 3, Investment = 4, Salon = 5, HomeService = 6
}

/// <summary>
/// تاکتیک‌های مجاز — نسخهٔ قانونیِ «۳۵ روش». هر کدام رضایت‌محور و از راهِ رسمی است.
/// (تاکتیک‌های مخفی/غیرقانونی عمداً در این enum نیستند تا از پشتِ هیچ دکمه‌ای اجرا نشوند.)
/// </summary>
public enum LaunchTactic
{
    ContextualAds = 1,        // تبلیغِ Meta/Google روی مخاطبِ مرتبط (نه شناساییِ بازدیدکننده)
    QrNfcOptIn = 2,           // QR/NFC در فضای فیزیکی → لندینگ → opt-in داوطلبانه
    LoyaltyRewardCoupon = 3,  // کوپنِ وفاداریِ رسمیِ مال/برج
    SurveyLotteryOptIn = 4,   // نظرسنجی/قرعه‌کشی با ارائهٔ داوطلبانهٔ تماس
    PartnerReferral = 5,      // ارجاعِ رسمیِ PropTech/Movers با رضایت
    CommunityTransparentPost = 6, // پاسخِ شفافِ کارشناس در انجمن → لندینگ
    NewsletterCtaAd = 7,      // اجارهٔ فضای CTA در خبرنامهٔ محلی
    B2bCompanyEnrichment = 8, // Apollo/Crunchbase/Magnitt در سطحِ شرکت (خطِ سرمایه‌گذاری)
    LandingLeadForm = 9       // لندینگ + فرمِ رضایتِ رسمی
}

/// <summary>
/// یک «پیش‌تنظیمِ» زمینه: با انتخابِ Context + شهر + سقفِ هزینه، یک مسیرِ آمادهٔ اجرا تولید می‌شود.
/// کلِ برنامه‌ریزی پشتِ دکمه اجرا می‌شود؛ کاربر فقط زمینه/شهر/بودجه را می‌دهد.
/// </summary>
public sealed class CampaignPreset
{
    private CampaignPreset() { }

    public CampaignPreset(Guid tenantId, CampaignContext context, string displayName, string city,
        decimal monthlyBudgetUsd, decimal maxCostPerLeadPercent, IReadOnlyList<LaunchTactic> tactics)
    {
        if (monthlyBudgetUsd < 0) throw new ArgumentOutOfRangeException(nameof(monthlyBudgetUsd));
        if (maxCostPerLeadPercent is < 0 or > 100) throw new ArgumentOutOfRangeException(nameof(maxCostPerLeadPercent));
        if (tactics.Count == 0) throw new ArgumentException("حداقل یک تاکتیک لازم است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Context = context;
        DisplayName = displayName.Trim();
        City = city.Trim();
        MonthlyBudgetUsd = monthlyBudgetUsd;
        MaxCostPerLeadPercent = maxCostPerLeadPercent;
        Tactics = tactics.Distinct().ToList();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public CampaignContext Context { get; private set; }
    public string DisplayName { get; private set; } = string.Empty;
    public string City { get; private set; } = string.Empty;
    public decimal MonthlyBudgetUsd { get; private set; }
    /// <summary>سقفِ هزینهٔ هر لید به‌صورتِ درصدی از بودجه (مثلِ «حداکثر ۱٪»).</summary>
    public decimal MaxCostPerLeadPercent { get; private set; }
    public IReadOnlyList<LaunchTactic> Tactics { get; private set; } = [];
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    /// <summary>سقفِ هزینهٔ مجازِ هر لید (دلار) از روی درصد.</summary>
    public decimal MaxCostPerLeadUsd => Math.Round(MonthlyBudgetUsd * (MaxCostPerLeadPercent / 100m), 2);

    /// <summary>آیا هزینهٔ واقعیِ یک لید در سقف است؟ (BudgetGuard پشتِ دکمه.)</summary>
    public bool IsWithinBudget(decimal actualCostPerLeadUsd) => actualCostPerLeadUsd <= MaxCostPerLeadUsd;
}
