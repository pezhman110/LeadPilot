namespace LeadPilot.Domain.MobileSync;

public enum MobileContactSyncStatus
{
    Pending = 1,
    Processing = 2,
    Synced = 3,
    UpdatePending = 4,
    RemovalPending = 5,
    Removed = 6,
    Failed = 7,
    Cancelled = 8
}

/// <summary>
/// صفِ همگام‌سازیِ اکانت روی موبایلِ کاری (ذخیرهٔ روزانه). مطابق سند.
/// اکانت روی موبایل ذخیره می‌شود؛ فقط پس از رضایت ارتباط از آن انجام می‌شود.
/// اگر رضایت رد شد یا Suppress شد، حذف از موبایل (RemovalPending → Removed).
/// </summary>
public sealed class MobileContactSyncJob
{
    private MobileContactSyncJob() { }

    public MobileContactSyncJob(Guid prospectId, Guid contactPointId, Guid tenantId,
        string deviceLabel, string maskedValue)
    {
        if (prospectId == Guid.Empty) throw new ArgumentException("شناسه مخاطب معتبر نیست.");
        if (contactPointId == Guid.Empty) throw new ArgumentException("شناسه پرونده معتبر نیست.");
        Id = Guid.NewGuid();
        ProspectId = prospectId;
        ContactPointId = contactPointId;
        TenantId = tenantId;
        DeviceLabel = deviceLabel;
        MaskedValue = maskedValue;
        Status = MobileContactSyncStatus.Pending;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid ContactPointId { get; private set; }
    public Guid TenantId { get; private set; }
    public string DeviceLabel { get; private set; } = string.Empty;
    public string MaskedValue { get; private set; } = string.Empty;
    public MobileContactSyncStatus Status { get; private set; }
    public string? DeviceContactRef { get; private set; }
    public int AttemptCount { get; private set; }
    public string? LastError { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? SyncedAtUtc { get; private set; }
    public DateTimeOffset? RemovedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void BeginProcessing() { AttemptCount++; Status = MobileContactSyncStatus.Processing; }

    public void MarkSynced(string deviceContactRef)
    {
        DeviceContactRef = deviceContactRef;
        Status = MobileContactSyncStatus.Synced;
        SyncedAtUtc = DateTimeOffset.UtcNow;
        LastError = null;
    }

    public void RequestUpdate() { if (Status == MobileContactSyncStatus.Synced) Status = MobileContactSyncStatus.UpdatePending; }

    /// <summary>درخواست حذف از موبایل (پس از رد رضایت/Suppress).</summary>
    public void RequestRemoval() => Status = MobileContactSyncStatus.RemovalPending;

    public void MarkRemoved()
    {
        Status = MobileContactSyncStatus.Removed;
        RemovedAtUtc = DateTimeOffset.UtcNow;
        DeviceContactRef = null;
    }

    public void Fail(string error) { LastError = error; Status = MobileContactSyncStatus.Failed; }
    public void Cancel() => Status = MobileContactSyncStatus.Cancelled;
}
