namespace LeadPilot.Domain.Sources;

/// <summary>
/// ۱۴ گروهِ منبع (A–N) مطابق سند. رجیستری توسعه‌پذیر است؛ این‌ها گروه‌بندیِ پایه‌اند.
/// </summary>
public enum SourceGroup
{
    A_OwnedData = 1,          // منابع متعلق به خود مجموعه (CRM/فرم/رزرو/POS/Referral)
    B_PlatformLeadForms = 2,  // فرم‌های رسمی جذب لید (Meta/LinkedIn/TikTok/Snapchat/Google)
    C_Messaging = 3,          // پیام‌رسان‌ها و مراکز ارتباطی (کانالِ opt-in، نه استخراج)
    D_SearchWeb = 4,          // موتورهای جست‌وجو و وب عمومی
    E_MapsDirectories = 5,    // نقشه‌ها و دایرکتوری‌ها (فقط شرکتی)
    F_SocialPublic = 6,       // شبکه‌های اجتماعی و محتوای عمومی
    G_CommentsForums = 7,     // کامنت/انجمن/تالار (Signal Source، نه Phone Source)
    H_NewsMedia = 8,          // خبر، رسانه، رویداد
    I_CompanyRegistries = 9,  // ثبت شرکت و منابع رسمی B2B
    J_ContractProviders = 10, // Providerهای قراردادی (Apollo/ZoomInfo/…)
    K_Marketplaces = 11,      // مارکت‌پلیس‌ها و سایت‌های تخصصی
    L_AppStores = 12,         // اپلیکیشن‌ها و فروشگاه‌های اپ
    M_AiOutputs = 13,         // خروجی ابزارهای AI (نه منبع مستقیم تلفن)
    N_Offline = 14            // منابع آفلاین
}

/// <summary>
/// نقشِ منبع: آیا شماره می‌دهد یا فقط سیگنالِ نیت؟ (تفکیک حیاتیِ سند)
/// </summary>
public enum SourceRole
{
    PhoneSource = 0,   // اطلاعات تماسِ مجاز می‌دهد (فرم/CRM/Provider قراردادی)
    SignalSource = 1,  // فقط نیت/سیگنال؛ شماره از opt-in می‌آید (کامنت/انجمن/سوشیال)
    OptInChannel = 2   // کانالِ ادامهٔ ارتباط (پیام‌رسان)
}

/// <summary>
/// طبقه‌بندیِ تماس (سند): تا Unknown روشن نشود، وارد عملیات نمی‌شود.
/// </summary>
public enum ContactClassification
{
    Corporate = 0,
    PublicBusiness = 1,
    PersonalSelfSubmitted = 2,
    PartnerSupplied = 3,
    Unknown = 4
}

/// <summary>
/// یک منبعِ ثبت‌شده در رجیستری. با سیاست‌های حیاتی: فقط-شرکتی، رتبهٔ سرعت، نقش.
/// </summary>
public sealed class SourceDefinition
{
    private SourceDefinition() { }

    public SourceDefinition(string code, string displayName, SourceGroup group, SourceRole role,
        int speedRank, bool corporateOnly, bool requiresContract)
    {
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("کد منبع الزامی است.");
        if (speedRank is < 1 or > 6) throw new ArgumentOutOfRangeException(nameof(speedRank), "رتبهٔ سرعت ۱ تا ۶ است.");
        Id = Guid.NewGuid();
        Code = code.Trim();
        DisplayName = displayName.Trim();
        Group = group;
        Role = role;
        SpeedRank = speedRank;          // ۱ = سریع‌ترین (دادهٔ آماده)، ۶ = کندترین (سوشیال/انجمن)
        CorporateOnly = corporateOnly;  // Google Maps/About = true
        RequiresContract = requiresContract;
        IsEnabled = true;
    }

    public Guid Id { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string DisplayName { get; private set; } = string.Empty;
    public SourceGroup Group { get; private set; }
    public SourceRole Role { get; private set; }
    public int SpeedRank { get; private set; }
    public bool CorporateOnly { get; private set; }
    public bool RequiresContract { get; private set; }
    public bool IsEnabled { get; private set; }

    public void Disable() => IsEnabled = false;
    public void Enable() => IsEnabled = true;

    /// <summary>
    /// آیا این منبع برای این پروژه مجاز است؟ منابعِ فقط-شرکتی برای پروژهٔ شخصی ممنوع.
    /// </summary>
    public bool IsAllowedFor(bool projectIsPersonal) => !(CorporateOnly && projectIsPersonal);
}
