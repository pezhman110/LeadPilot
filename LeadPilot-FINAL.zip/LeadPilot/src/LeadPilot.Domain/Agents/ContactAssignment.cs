namespace LeadPilot.Domain.Agents;

public enum AssignmentStatus { Active = 0, Released = 1, Reassigned = 2 }

/// <summary>
/// قفلِ انحصاریِ یک شماره/ایمیل به یک فروشنده. قاعده: یک ContactPoint در هر لحظه فقط
/// یک تخصیصِ Active دارد (ایندکسِ یکتا روی ContactPointId جایی که Active). این تضمین می‌کند
/// «یک شماره در جاهای مختلف استفاده نشود». بازیابیِ دوباره (پس از ارسال به CRM) بر اساسِ
/// ویژگی (دارای اکانت/ایمیل/تلفن) و فقط برای فروشنده‌ای که مالکِ تخصیص است انجام می‌شود.
/// </summary>
public sealed class ContactAssignment
{
    private ContactAssignment() { }

    public ContactAssignment(Guid tenantId, Guid contactPointId, Guid prospectId, Guid agentProfileId,
        string serviceCode, bool hasAccount, bool hasEmail, bool hasPhone)
    {
        if (contactPointId == Guid.Empty) throw new ArgumentException("شناسه پرونده معتبر نیست.");
        if (agentProfileId == Guid.Empty) throw new ArgumentException("شناسه فروشنده معتبر نیست.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ContactPointId = contactPointId;
        ProspectId = prospectId;
        AgentProfileId = agentProfileId;
        ServiceCode = serviceCode.Trim();
        HasAccount = hasAccount;
        HasEmail = hasEmail;
        HasPhone = hasPhone;
        Status = AssignmentStatus.Active;
        AssignedAtUtc = DateTimeOffset.UtcNow;
        // کلیدِ انحصار: فقط برای رکوردهای Active مقدار دارد؛ Released/Reassigned = null.
        ActiveContactKey = contactPointId;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ContactPointId { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid AgentProfileId { get; private set; }
    public string ServiceCode { get; private set; } = string.Empty;
    public bool HasAccount { get; private set; }
    public bool HasEmail { get; private set; }
    public bool HasPhone { get; private set; }
    public AssignmentStatus Status { get; private set; }
    public DateTimeOffset AssignedAtUtc { get; private set; }
    public DateTimeOffset? ReleasedAtUtc { get; private set; }
    public string? PushedToCrm { get; private set; }
    /// <summary>برای ایندکسِ یکتا: وقتی Active برابرِ ContactPointId، وقتی آزاد شد null.</summary>
    public Guid? ActiveContactKey { get; private set; }
    public uint RowVersion { get; private set; }

    /// <summary>پس از ارسال به CRM، تخصیص آزاد می‌شود تا شماره «رزرو» نماند؛ ولی سابقه می‌ماند.</summary>
    public void ReleaseAfterCrmPush(string crmRef)
    {
        PushedToCrm = crmRef;
        Status = AssignmentStatus.Released;
        ReleasedAtUtc = DateTimeOffset.UtcNow;
        ActiveContactKey = null;
    }

    public void Release()
    {
        Status = AssignmentStatus.Released;
        ReleasedAtUtc = DateTimeOffset.UtcNow;
        ActiveContactKey = null;
    }

    public bool MatchesAttribute(bool? needAccount, bool? needEmail, bool? needPhone) =>
        (needAccount != true || HasAccount) &&
        (needEmail != true || HasEmail) &&
        (needPhone != true || HasPhone);
}
