namespace LeadPilot.Domain.Agents;

/// <summary>
/// پروفایلِ کاریِ یک فروشنده در کنسولِ ارتباطات. مدیر تعیین می‌کند هر فروشنده کدام خدمات و
/// کدام کانال‌ها را دارد، سقفِ روزانه، اجازهٔ ارسالِ خودکار، و اجازهٔ Reveal.
/// «فروشندهٔ ۱ ویژهٔ فلان خدمات» یعنی فقط بانکِ همان خدمات را می‌بیند.
/// </summary>
public sealed class AgentProfile
{
    private readonly HashSet<string> _services = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _channels = new(StringComparer.OrdinalIgnoreCase);

    private AgentProfile() { }

    public AgentProfile(Guid tenantId, Guid partnerId, string displayName, int dailySendCap,
        bool automaticSendingAllowed, bool canRevealContact)
    {
        if (partnerId == Guid.Empty) throw new ArgumentException("شناسه فروشنده معتبر نیست.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        PartnerId = partnerId;
        DisplayName = displayName.Trim();
        DailySendCap = Math.Max(0, dailySendCap);
        AutomaticSendingAllowed = automaticSendingAllowed;
        CanRevealContact = canRevealContact;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid PartnerId { get; private set; }
    public string DisplayName { get; private set; } = string.Empty;
    public int DailySendCap { get; private set; }
    public bool AutomaticSendingAllowed { get; private set; }
    public bool CanRevealContact { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public IReadOnlyCollection<string> Services => _services;
    public IReadOnlyCollection<string> Channels => _channels;

    public string ServicesCsv
    {
        get => string.Join(',', _services);
        private set { _services.Clear(); foreach (var s in Split(value)) _services.Add(s); }
    }
    public string ChannelsCsv
    {
        get => string.Join(',', _channels);
        private set { _channels.Clear(); foreach (var s in Split(value)) _channels.Add(s); }
    }

    public void AllowService(string serviceCode) { if (!string.IsNullOrWhiteSpace(serviceCode)) _services.Add(serviceCode.Trim()); }
    public void AllowChannel(string channel) { if (!string.IsNullOrWhiteSpace(channel)) _channels.Add(channel.Trim()); }

    public bool HandlesService(string serviceCode) => _services.Contains(serviceCode);
    public bool HasChannel(string channel) => _channels.Contains(channel);

    private static IEnumerable<string> Split(string? csv) =>
        string.IsNullOrWhiteSpace(csv) ? [] : csv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}
