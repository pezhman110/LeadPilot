namespace LeadPilot.Domain.Acquisition;

/// <summary>
/// یک نتیجهٔ اجرای آزمایشی. فقط مقدارِ ماسک‌شده اینجاست؛ شمارهٔ کامل در ContactPoint
/// (رمزنگاری‌شده، ManagerOnly). هر نتیجه باید منبع و مرجعِ قابل‌کلیک داشته باشد.
/// </summary>
public sealed class FirstTenRunResult
{
    private FirstTenRunResult() { }

    public FirstTenRunResult(
        Guid runId, Guid prospectId, Guid contactPointId, string contactType,
        string maskedValue, string sourceCode, string sourceReference, string? sourceUrl,
        int confidenceScore, decimal costAed, DateTimeOffset discoveredAtUtc)
    {
        if (runId == Guid.Empty || prospectId == Guid.Empty || contactPointId == Guid.Empty)
            throw new ArgumentException("شناسه‌های نتیجه معتبر نیستند.");
        if (string.IsNullOrWhiteSpace(maskedValue))
            throw new ArgumentException("مقدار ماسک‌شده الزامی است.");
        if (string.IsNullOrWhiteSpace(sourceCode))
            throw new ArgumentException("کد منبع الزامی است.");
        if (string.IsNullOrWhiteSpace(sourceReference))
            throw new ArgumentException("مرجع منبع الزامی است."); // نتیجهٔ بدون مرجع پذیرفته نمی‌شود
        if (confidenceScore is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(confidenceScore));

        Id = Guid.NewGuid();
        RunId = runId;
        ProspectId = prospectId;
        ContactPointId = contactPointId;
        ContactType = contactType.Trim().ToUpperInvariant();
        MaskedValue = maskedValue.Trim();
        SourceCode = sourceCode.Trim().ToUpperInvariant();
        SourceReference = sourceReference.Trim();
        SourceUrl = string.IsNullOrWhiteSpace(sourceUrl) ? null : sourceUrl.Trim();
        ConfidenceScore = confidenceScore;
        CostAed = costAed;
        DiscoveredAtUtc = discoveredAtUtc;
    }

    public Guid Id { get; private set; }
    public Guid RunId { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid ContactPointId { get; private set; }
    public string ContactType { get; private set; } = string.Empty;
    public string MaskedValue { get; private set; } = string.Empty;
    public string SourceCode { get; private set; } = string.Empty;
    public string SourceReference { get; private set; } = string.Empty;
    public string? SourceUrl { get; private set; }
    public int ConfidenceScore { get; private set; }
    public decimal CostAed { get; private set; }
    public DateTimeOffset DiscoveredAtUtc { get; private set; }
}
