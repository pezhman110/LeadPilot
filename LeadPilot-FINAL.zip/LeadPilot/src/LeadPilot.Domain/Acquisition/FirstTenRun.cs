namespace LeadPilot.Domain.Acquisition;

public enum FirstTenRunStatus
{
    Created = 1,
    WaitingForConnections = 2,
    Queued = 3,
    Running = 4,
    Completed = 5,
    CompletedWithShortage = 6,
    Failed = 7,
    Cancelled = 8
}

/// <summary>
/// اجرای آزمایشی «۱۰ نتیجهٔ اول» (Start Test Run) — اولین جریانِ عملیِ سیستم.
/// مدیر می‌زند → سلامت اتصالات → حداکثر ۱۰۰ کاندید → آبشار رایگان→پولی →
/// نرمال/Dedup → ContactPoint با ManagerOnly → ۱۰ نتیجهٔ یکتا → توقف خودکار.
/// (RowVersion=uint برای Postgres)
/// </summary>
public sealed class FirstTenRun
{
    private readonly List<FirstTenRunResult> _results = [];
    private FirstTenRun() { }

    public FirstTenRun(
        Guid tenantId, Guid projectId, string projectCode, bool isCorporateProject,
        int targetCount, int maximumCandidates, decimal maximumCostAed,
        string startedBy, DateTimeOffset createdAtUtc)
    {
        if (tenantId == Guid.Empty || projectId == Guid.Empty)
            throw new ArgumentException("شناسه سازمان یا پروژه معتبر نیست.");
        if (string.IsNullOrWhiteSpace(projectCode))
            throw new ArgumentException("کد پروژه الزامی است.");
        if (targetCount is < 1 or > 100)
            throw new ArgumentOutOfRangeException(nameof(targetCount));
        if (maximumCandidates < targetCount || maximumCandidates > 1000)
            throw new ArgumentOutOfRangeException(nameof(maximumCandidates),
                "حداکثر کاندیدها باید بین هدف و ۱۰۰۰ باشد.");
        if (maximumCostAed < 0)
            throw new ArgumentOutOfRangeException(nameof(maximumCostAed));
        if (string.IsNullOrWhiteSpace(startedBy))
            throw new ArgumentException("شروع‌کننده مشخص نیست.");

        Id = Guid.NewGuid();
        TenantId = tenantId;
        ProjectId = projectId;
        ProjectCode = projectCode.Trim().ToUpperInvariant();
        IsCorporateProject = isCorporateProject;
        TargetCount = targetCount;
        MaximumCandidates = maximumCandidates;
        MaximumCostAed = maximumCostAed;
        StartedBy = startedBy.Trim();
        Status = FirstTenRunStatus.Created;
        CreatedAtUtc = createdAtUtc;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ProjectId { get; private set; }
    public string ProjectCode { get; private set; } = string.Empty;
    public bool IsCorporateProject { get; private set; }
    public int TargetCount { get; private set; }
    public int MaximumCandidates { get; private set; }
    public decimal MaximumCostAed { get; private set; }
    public decimal ConsumedCostAed { get; private set; }
    public int CandidatesQueued { get; private set; }
    public int CandidatesProcessed { get; private set; }
    public int DuplicateCount { get; private set; }
    public int InvalidCount { get; private set; }
    public FirstTenRunStatus Status { get; private set; }
    public string StartedBy { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? StartedAtUtc { get; private set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }
    public string? FailureReason { get; private set; }
    public uint RowVersion { get; private set; }

    public IReadOnlyCollection<FirstTenRunResult> Results => _results;
    public int ResultCount => _results.Count;

    public void MarkWaitingForConnections() => Status = FirstTenRunStatus.WaitingForConnections;

    public void Queue(int candidateCount)
    {
        if (candidateCount is < 1 or > 1000)
            throw new ArgumentOutOfRangeException(nameof(candidateCount));
        CandidatesQueued = candidateCount;
        Status = FirstTenRunStatus.Queued;
    }

    public void Start(DateTimeOffset nowUtc)
    {
        if (Status != FirstTenRunStatus.Queued)
            throw new InvalidOperationException("اجرا در صف قرار ندارد.");
        Status = FirstTenRunStatus.Running;
        StartedAtUtc = nowUtc;
    }

    /// <summary>آیا می‌تواند نتیجهٔ جدید بپذیرد؟ (در حال اجرا، زیر هدف، زیر سقف هزینه)</summary>
    public bool CanAcceptResult() =>
        Status == FirstTenRunStatus.Running
        && ResultCount < TargetCount
        && ConsumedCostAed <= MaximumCostAed;

    public void RecordCandidateProcessed(bool wasDuplicate, bool wasInvalid, decimal costAed)
    {
        if (costAed < 0) throw new ArgumentOutOfRangeException(nameof(costAed));
        CandidatesProcessed++;
        ConsumedCostAed += costAed;
        if (wasDuplicate) DuplicateCount++;
        if (wasInvalid) InvalidCount++;
    }

    /// <summary>
    /// افزودنِ یک نتیجهٔ یکتا و واجدِ شرایط. تکراری در همین اجرا پذیرفته نمی‌شود.
    /// پس از رسیدن به هدف، اجرا خودکار Completed می‌شود.
    /// </summary>
    public void AddResult(FirstTenRunResult result, DateTimeOffset nowUtc)
    {
        if (!CanAcceptResult())
            throw new InvalidOperationException("اجرا نمی‌تواند نتیجهٔ جدید بپذیرد.");
        if (_results.Any(r => r.ContactPointId == result.ContactPointId))
            return; // تکراری در همین اجرا — شمرده نمی‌شود
        _results.Add(result);
        CompleteIfTargetReached(nowUtc);
    }

    public void CompleteIfTargetReached(DateTimeOffset nowUtc)
    {
        if (ResultCount < TargetCount) return;
        Status = FirstTenRunStatus.Completed;
        CompletedAtUtc = nowUtc;
    }

    public void CompleteWithShortage(string reason, DateTimeOffset nowUtc)
    {
        Status = FirstTenRunStatus.CompletedWithShortage;
        FailureReason = reason;
        CompletedAtUtc = nowUtc;
    }

    public void Fail(string reason, DateTimeOffset nowUtc)
    {
        Status = FirstTenRunStatus.Failed;
        FailureReason = reason;
        CompletedAtUtc = nowUtc;
    }

    public void Cancel(DateTimeOffset nowUtc)
    {
        Status = FirstTenRunStatus.Cancelled;
        CompletedAtUtc = nowUtc;
    }
}
