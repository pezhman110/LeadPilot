namespace LeadPilot.Domain.Imports;

public enum ContactImportBatchStatus
{
    Uploaded = 1, Processing = 2, Completed = 3, CompletedWithErrors = 4, Failed = 5, Cancelled = 6
}

/// <summary>
/// یک دستهٔ واردکردنِ CSV/CRM (سند: Checkpoint ورود CSV). جریان: خواندن Stream → اعتبارسنجی →
/// استانداردسازی → Hash/حذف تکراری → رمزنگاری → پروندهٔ الکترونیکی → ManagerOnly → ثبت منبع.
/// نکتهٔ امنیتی: مقدارِ خامِ تلفن/ایمیل هرگز در جدولِ Import یا Log ذخیره نمی‌شود.
/// lawful_source_reference = مرجعِ قانونیِ نگهداریِ داده، نه رضایت برای تماسِ فروش.
/// </summary>
public sealed class ContactImportBatch
{
    private ContactImportBatch() { }

    public ContactImportBatch(Guid tenantId, Guid projectId, string projectCode,
        string originalFileName, string sourceCode, string importedBy, DateTimeOffset createdAtUtc)
    {
        if (tenantId == Guid.Empty || projectId == Guid.Empty)
            throw new ArgumentException("شناسهٔ سازمان/پروژه معتبر نیست.");
        if (string.IsNullOrWhiteSpace(sourceCode)) throw new ArgumentException("کد منبع الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ProjectId = projectId;
        ProjectCode = projectCode.Trim();
        OriginalFileName = originalFileName.Trim();
        SourceCode = sourceCode.Trim();
        ImportedBy = importedBy.Trim();
        Status = ContactImportBatchStatus.Uploaded;
        CreatedAtUtc = createdAtUtc;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ProjectId { get; private set; }
    public string ProjectCode { get; private set; } = string.Empty;
    public string OriginalFileName { get; private set; } = string.Empty;
    public string SourceCode { get; private set; } = string.Empty;
    public string ImportedBy { get; private set; } = string.Empty;
    public ContactImportBatchStatus Status { get; private set; }
    public int TotalRows { get; private set; }
    public int ImportedRows { get; private set; }
    public int DuplicateRows { get; private set; }
    public int InvalidRows { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void BeginProcessing() => Status = ContactImportBatchStatus.Processing;

    public void CountRow(bool imported, bool duplicate, bool invalid)
    {
        TotalRows++;
        if (invalid) InvalidRows++;
        else if (duplicate) DuplicateRows++;
        else if (imported) ImportedRows++;
    }

    public void Complete()
    {
        Status = InvalidRows > 0 ? ContactImportBatchStatus.CompletedWithErrors : ContactImportBatchStatus.Completed;
        CompletedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Fail() { Status = ContactImportBatchStatus.Failed; CompletedAtUtc = DateTimeOffset.UtcNow; }
}
