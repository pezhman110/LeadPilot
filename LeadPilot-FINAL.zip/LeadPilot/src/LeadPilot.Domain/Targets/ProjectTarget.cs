namespace LeadPilot.Domain.Targets;

/// <summary>
/// هدفِ یک پروژه (تعدادی یا مالی) با دوره و بازهٔ زمانی. مطابق سند.
/// </summary>
public sealed class ProjectTarget
{
    private ProjectTarget() { }

    public ProjectTarget(
        Guid projectId,
        string name,
        TargetMetricType metricType,
        TargetPeriodType periodType,
        decimal targetValue,
        DateTimeOffset startsAtUtc,
        DateTimeOffset? endsAtUtc,
        string currency = "AED")
    {
        if (projectId == Guid.Empty)
            throw new ArgumentException("شناسه پروژه معتبر نیست.");
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("نام هدف الزامی است.");
        if (targetValue <= 0)
            throw new ArgumentOutOfRangeException(nameof(targetValue), "مقدار هدف باید بیشتر از صفر باشد.");
        if (endsAtUtc.HasValue && endsAtUtc <= startsAtUtc)
            throw new ArgumentException("تاریخ پایان باید بعد از تاریخ شروع باشد.");

        Id = Guid.NewGuid();
        ProjectId = projectId;
        Name = name.Trim();
        MetricType = metricType;
        PeriodType = periodType;
        TargetValue = targetValue;
        Currency = currency.Trim().ToUpperInvariant();
        StartsAtUtc = startsAtUtc;
        EndsAtUtc = endsAtUtc;
        IsActive = true;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public TargetMetricType MetricType { get; private set; }
    public TargetPeriodType PeriodType { get; private set; }
    public decimal TargetValue { get; private set; }
    public decimal ActualValue { get; private set; }
    public string Currency { get; private set; } = "AED";
    public DateTimeOffset StartsAtUtc { get; private set; }
    public DateTimeOffset? EndsAtUtc { get; private set; }
    public bool IsActive { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? UpdatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public decimal AchievementPercentage =>
        TargetValue == 0 ? 0 : Math.Round(ActualValue / TargetValue * 100, 2);

    public decimal RemainingValue => Math.Max(0, TargetValue - ActualValue);

    public void SetActualValue(decimal value)
    {
        if (value < 0) throw new ArgumentOutOfRangeException(nameof(value));
        ActualValue = value; UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
    public void AddActualValue(decimal value)
    {
        if (value <= 0) throw new ArgumentOutOfRangeException(nameof(value));
        ActualValue += value; UpdatedAtUtc = DateTimeOffset.UtcNow;
    }
    public void Deactivate() { IsActive = false; UpdatedAtUtc = DateTimeOffset.UtcNow; }
}

/// <summary>
/// نرخ‌های قیفِ هر پروژه (تخمینی تا رسیدن به داده واقعی). مطابق سند.
/// </summary>
public sealed class ProjectFunnelSettings
{
    private ProjectFunnelSettings() { }

    public ProjectFunnelSettings(Guid projectId)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        // پیش‌فرض‌های تخمینیِ سند
        SignalToContactRate = 0.20m;
        ContactToConsentRate = 0.20m;
        ConsentToQualifiedRate = 0.40m;
        QualifiedToMeetingRate = 0.50m;
        MeetingToProposalRate = 0.60m;
        ProposalToCloseRate = 0.10m;
        AverageDealValueAed = 200_000m;
        IsEstimated = true;
        CalculatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public decimal SignalToContactRate { get; set; }
    public decimal ContactToConsentRate { get; set; }
    public decimal ConsentToQualifiedRate { get; set; }
    public decimal QualifiedToMeetingRate { get; set; }
    public decimal MeetingToProposalRate { get; set; }
    public decimal ProposalToCloseRate { get; set; }
    public decimal AverageDealValueAed { get; set; }
    public decimal AverageCollectedRevenueAed { get; set; }
    public int DataSampleSize { get; set; }
    public bool IsEstimated { get; set; }
    public DateTimeOffset CalculatedAtUtc { get; set; }
}
