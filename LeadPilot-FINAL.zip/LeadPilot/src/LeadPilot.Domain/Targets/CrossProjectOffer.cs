namespace LeadPilot.Domain.Targets;

/// <summary>
/// موتور پیشنهاد متقابل بین ۱۶ پروژه (زنجیرهٔ ارزش). مطابق سند.
/// هر قانون: رویداد مبدأ → پروژهٔ مقصد → پیشنهاد، با شرط رضایت و سقف.
/// </summary>
public sealed class CrossProjectOffer
{
    private CrossProjectOffer() { }

    public CrossProjectOffer(
        string sourceEvent, string sourceProjectCode, string targetProjectCode,
        string offer, decimal discountOrCreditAed, int validityDays, bool requiresConsent)
    {
        if (string.IsNullOrWhiteSpace(sourceEvent)) throw new ArgumentException("رویداد مبدأ الزامی است.");
        if (string.IsNullOrWhiteSpace(targetProjectCode)) throw new ArgumentException("پروژهٔ مقصد الزامی است.");

        Id = Guid.NewGuid();
        SourceEvent = sourceEvent;
        SourceProjectCode = sourceProjectCode;
        TargetProjectCode = targetProjectCode;
        Offer = offer;
        DiscountOrCreditAed = discountOrCreditAed;
        ValidityDays = validityDays;
        RequiresConsent = requiresConsent;
        IsActive = true;
    }

    public Guid Id { get; private set; }
    public string SourceEvent { get; private set; } = string.Empty;
    public string SourceProjectCode { get; private set; } = string.Empty;
    public string TargetProjectCode { get; private set; } = string.Empty;
    public string Offer { get; private set; } = string.Empty;
    public decimal DiscountOrCreditAed { get; private set; }
    public int ValidityDays { get; private set; }
    public bool RequiresConsent { get; private set; }
    public int? MaxUses { get; private set; }
    public bool IsActive { get; private set; }

    public void SetMaxUses(int max) => MaxUses = max > 0 ? max : throw new ArgumentOutOfRangeException(nameof(max));
    public void Deactivate() => IsActive = false;
}

/// <summary>
/// سیاست Attribution — جلوگیری از پرداختِ چندبارهٔ پورسانت/تخفیف. مطابق سند.
/// </summary>
public sealed class AttributionRecord
{
    private AttributionRecord() { }

    public AttributionRecord(Guid saleId, AttributionModel model)
    {
        Id = Guid.NewGuid();
        SaleId = saleId;
        Model = model;
    }

    public Guid Id { get; private set; }
    public Guid SaleId { get; private set; }
    public AttributionModel Model { get; private set; }
    public string? PrimarySource { get; private set; }
    public string? AssistingSource { get; private set; }
    public string? ReferralCode { get; private set; }
    public bool CommissionPaid { get; private set; }

    public void SetSources(string primary, string? assisting, string? referralCode)
    {
        PrimarySource = primary; AssistingSource = assisting; ReferralCode = referralCode;
    }
    public void MarkCommissionPaid() => CommissionPaid = true;
}

public enum AttributionModel { FirstTouch = 0, LastTouch = 1, PrimaryPlusAssist = 2 }
