namespace LeadPilot.Domain.Targets;

public enum TargetMetricType
{
    DiscoveredSignals = 1,
    QualifiedProspects = 2,
    ConsentedProspects = 3,
    SalesReadyLeads = 4,
    Meetings = 5,
    Bookings = 6,
    CompletedServices = 7,
    ClosedDeals = 8,
    ActiveFreelancers = 9,
    ActiveCustomers = 10,
    Orders = 11,
    Partnerships = 12,

    GrossMerchandiseValueAed = 20,
    GrossRevenueAed = 21,
    CollectedRevenueAed = 22,
    CompanyCommissionAed = 23,
    GrossProfitAed = 24,
    NetProfitAed = 25
}

public enum TargetPeriodType
{
    Daily = 1,
    Weekly = 2,
    Monthly = 3,
    Quarterly = 4,
    Annual = 5,
    Custom = 6
}
