namespace LeadPilot.Domain.Community;

public enum CommunityPlatform { Reddit = 1, FacebookGroup = 2, Quora = 3, Telegram = 4, Discord = 5, Forum = 6, LocalPortal = 7, QnaSite = 8, ClassifiedsPortal = 9 }

/// <summary>وضعیتِ تأییدِ منبعِ انجمن (سند).</summary>
public enum CommunitySourceStatus
{
    Candidate = 0, UnderReview = 1,
    ApprovedForMonitoring = 2, ApprovedForPublicResponse = 3, ApprovedForPublishing = 4,
    Suspended = 5, Rejected = 6
}

/// <summary>
/// یک منبعِ انجمن/فروم. مدیر قواعدِ آن را تنظیم می‌کند: آیا پاسخِ تجاری/دایرکت مجاز است؟
/// آیا API رسمی دارد؟ سقفِ روزانه، تیمِ مسئول، سطحِ تأییدِ لازم. صرفِ نام‌بردنِ یک Subreddit
/// به‌معنی فعال/مناسب‌بودنش نیست؛ باید در زمان اجرا بررسی شود → Candidate تا تأیید.
/// </summary>
public sealed class CommunitySource
{
    private CommunitySource() { }

    public CommunitySource(Guid tenantId, string name, CommunityPlatform platform, string url,
        string country, string? city, string language, string industries,
        bool commercialResponsesAllowed, bool directMessagesAllowed, bool officialApiAvailable,
        int dailyRequestLimit, int retentionDays)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام منبع الزامی است.");
        if (string.IsNullOrWhiteSpace(url)) throw new ArgumentException("URL الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Name = name.Trim();
        Platform = platform;
        Url = url.Trim();
        Country = country.Trim();
        City = city?.Trim();
        Language = language.Trim();
        Industries = industries.Trim();
        CommercialResponsesAllowed = commercialResponsesAllowed;
        DirectMessagesAllowed = directMessagesAllowed;
        OfficialApiAvailable = officialApiAvailable;
        DailyRequestLimit = Math.Max(0, dailyRequestLimit);
        RetentionDays = Math.Max(1, retentionDays);
        Status = CommunitySourceStatus.Candidate;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public CommunityPlatform Platform { get; private set; }
    public string Url { get; private set; } = string.Empty;
    public string Country { get; private set; } = string.Empty;
    public string? City { get; private set; }
    public string Language { get; private set; } = string.Empty;
    public string Industries { get; private set; } = string.Empty;
    public bool CommercialResponsesAllowed { get; private set; }
    public bool DirectMessagesAllowed { get; private set; }
    public bool OfficialApiAvailable { get; private set; }
    public int DailyRequestLimit { get; private set; }
    public int RetentionDays { get; private set; }
    public CommunitySourceStatus Status { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? LastReviewedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void Transition(CommunitySourceStatus to) { Status = to; LastReviewedAtUtc = DateTimeOffset.UtcNow; }

    public bool CanMonitor => Status is CommunitySourceStatus.ApprovedForMonitoring
        or CommunitySourceStatus.ApprovedForPublicResponse or CommunitySourceStatus.ApprovedForPublishing;
    public bool CanPublicRespond => Status is CommunitySourceStatus.ApprovedForPublicResponse
        or CommunitySourceStatus.ApprovedForPublishing;
    public bool CanPublish => Status == CommunitySourceStatus.ApprovedForPublishing;
}
