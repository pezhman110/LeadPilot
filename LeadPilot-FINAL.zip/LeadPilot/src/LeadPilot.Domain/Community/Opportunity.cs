namespace LeadPilot.Domain.Community;

/// <summary>وضعیتِ فرصت (سند). تا اقدامِ داوطلبانهٔ مخاطب، فقط Opportunity است، نه Contact.</summary>
public enum OpportunityStatus
{
    New = 0, Assigned = 1, ResponseDrafted = 2, PendingApproval = 3, Published = 4,
    ConvertedToLead = 5, Irrelevant = 6, Duplicate = 7
}

public enum OpportunityMode { Manual = 0, AiAssisted = 1, AutomaticLimited = 2 }

/// <summary>
/// یک «فرصت» از یک سؤالِ عمومیِ پرقصد در انجمن. قاعدهٔ سخت (سند):
/// سؤالِ عمومی = سیگنالِ تقاضا، نه اجازهٔ استخراجِ هویت یا تبلیغِ مستقیم.
/// این رکورد هرگز شماره/ایمیل/هویتِ واقعیِ کاربر را نگه نمی‌دارد؛ فقط دادهٔ عمومیِ Thread.
/// تبدیل به Lead فقط پس از اقدامِ داوطلبانه (فرم/opt-in) رخ می‌دهد.
/// </summary>
public sealed class Opportunity
{
    private Opportunity() { }

    public Opportunity(Guid tenantId, Guid sourceId, CommunityPlatform platform, string community,
        string publicThreadUrl, string? publicPostId, string topic, string questionSummary,
        string language, string industry, string? declaredLocation, int intentScore,
        DateTimeOffset publishedAtUtc)
    {
        if (string.IsNullOrWhiteSpace(publicThreadUrl)) throw new ArgumentException("URL عمومیِ Thread الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        SourceId = sourceId;
        Platform = platform;
        Community = community.Trim();
        PublicThreadUrl = publicThreadUrl.Trim();
        PublicPostId = publicPostId?.Trim();
        Topic = topic.Trim();
        QuestionSummary = questionSummary.Trim();
        Language = language.Trim();
        Industry = industry.Trim();
        DeclaredLocation = declaredLocation?.Trim();
        IntentScore = Math.Clamp(intentScore, 0, 100);
        PublishedAtUtc = publishedAtUtc;
        Status = OpportunityStatus.New;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid SourceId { get; private set; }
    public CommunityPlatform Platform { get; private set; }
    public string Community { get; private set; } = string.Empty;
    public string PublicThreadUrl { get; private set; } = string.Empty;
    public string? PublicPostId { get; private set; }
    public string Topic { get; private set; } = string.Empty;
    public string QuestionSummary { get; private set; } = string.Empty;
    public string Language { get; private set; } = string.Empty;
    public string Industry { get; private set; } = string.Empty;
    public string? DeclaredLocation { get; private set; }
    public int IntentScore { get; private set; }
    public DateTimeOffset PublishedAtUtc { get; private set; }
    public OpportunityStatus Status { get; private set; }
    public Guid? AssignedAgentId { get; private set; }
    public string? PublishedResponseUrl { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void Assign(Guid agentId) { AssignedAgentId = agentId; Status = OpportunityStatus.Assigned; }
    public void MarkResponseDrafted() => Status = OpportunityStatus.ResponseDrafted;
    public void SendForApproval() => Status = OpportunityStatus.PendingApproval;
    /// <summary>کارشناس پس از انتشار در پلتفرم، URL پاسخ را ثبت می‌کند (سیستم وانمود نمی‌کند منتشر کرده).</summary>
    public void RecordPublishedResponse(string responseUrl) { PublishedResponseUrl = responseUrl; Status = OpportunityStatus.Published; }
    public void MarkIrrelevant() => Status = OpportunityStatus.Irrelevant;
    public void MarkDuplicate() => Status = OpportunityStatus.Duplicate;
    /// <summary>فقط پس از اقدامِ داوطلبانهٔ مخاطب (فرم/opt-in) قابلِ تبدیل به Lead است.</summary>
    public void ConvertToLead() => Status = OpportunityStatus.ConvertedToLead;

    /// <summary>یک فرصت هرگز به‌تنهایی Contact قابلِ ارسال نیست.</summary>
    public bool IsContactable => false;
}
