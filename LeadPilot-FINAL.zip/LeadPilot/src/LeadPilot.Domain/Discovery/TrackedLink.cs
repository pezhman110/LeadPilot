namespace LeadPilot.Domain.Discovery;

/// <summary>
/// لینکِ قابلِ ردیابی (سند: Tracked Link Campaigns). فقط دامنهٔ خودِ شرکت، UTM، انقضا،
/// بدونِ Token/اطلاعاتِ حساس در URL. کلیک = فقط سیگنالِ تحلیلی/آغازِ لندینگِ رضایت — نه مجوزِ استخراج.
/// </summary>
public sealed class TrackedLink
{
    private TrackedLink() { }

    public TrackedLink(Guid tenantId, string campaign, string ownedDomainUrl, string utmSource,
        string utmMedium, string utmCampaign, DateTimeOffset? expiresAt)
    {
        if (string.IsNullOrWhiteSpace(ownedDomainUrl)) throw new ArgumentException("URL دامنهٔ خودی الزامی است.");
        if (ownedDomainUrl.Contains("token=", StringComparison.OrdinalIgnoreCase) ||
            ownedDomainUrl.Contains("secret=", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("URL نباید Token/اطلاعاتِ حساس داشته باشد.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Campaign = campaign.Trim();
        DestinationUrl = ownedDomainUrl.Trim();
        UtmSource = utmSource.Trim();
        UtmMedium = utmMedium.Trim();
        UtmCampaign = utmCampaign.Trim();
        ExpiresAt = expiresAt;
        ShortCode = Guid.NewGuid().ToString("N")[..8];
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Campaign { get; private set; } = string.Empty;
    public string DestinationUrl { get; private set; } = string.Empty;
    public string UtmSource { get; private set; } = string.Empty;
    public string UtmMedium { get; private set; } = string.Empty;
    public string UtmCampaign { get; private set; } = string.Empty;
    public string ShortCode { get; private set; } = string.Empty;
    public DateTimeOffset? ExpiresAt { get; private set; }
    public int Clicks { get; private set; }
    public int Conversions { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public bool IsActive(DateTimeOffset now) => ExpiresAt is null || ExpiresAt > now;
    public void RecordClick() => Clicks++;
    public void RecordConversion() => Conversions++;
}
