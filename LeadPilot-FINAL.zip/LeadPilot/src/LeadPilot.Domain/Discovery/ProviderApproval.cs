namespace LeadPilot.Domain.Discovery;

/// <summary>ارائه‌دهنده‌های داده/ابزار (Outscraper/Apify/ZoomInfo/…).</summary>
public enum DataProviderCode
{
    Outscraper = 1, Apify = 2, ZoomInfo = 3, Bombora = 4, Lusha = 5, ContactOut = 6,
    Lemlist = 7, GoogleAds = 8, MetaAds = 9, PixelMe = 10, Sniply = 11, Apollo = 12, CustomProvider = 13
}

/// <summary>چرخهٔ تأییدِ Provider (سند). هیچ Providerی بدونِ تأییدِ متناسب استفاده نمی‌شود.</summary>
public enum ProviderApprovalState
{
    NotReviewed = 0, UnderReview = 1,
    ApprovedForDiscovery = 2, ApprovedForEnrichment = 3, ApprovedForOutreach = 4,
    Suspended = 5, Rejected = 6
}

/// <summary>
/// حاکمیتِ استفاده از یک Provider. جدا از سلامتِ فنی است؛ اینجا «مجازبودنِ استفاده» و برای چه کاری.
/// Discovery ⊂ Enrichment ⊂ Outreach (تأییدِ بالاتر شاملِ پایین‌تر).
/// </summary>
public sealed class ProviderApproval
{
    private ProviderApproval() { }

    public ProviderApproval(Guid tenantId, DataProviderCode provider, string reviewedBy)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Provider = provider;
        State = ProviderApprovalState.NotReviewed;
        ReviewedBy = reviewedBy;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public DataProviderCode Provider { get; private set; }
    public ProviderApprovalState State { get; private set; }
    public string ReviewedBy { get; private set; } = string.Empty;
    public string? Notes { get; private set; }
    public DateTimeOffset UpdatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void Transition(ProviderApprovalState to, string actor, string? notes = null)
    {
        State = to;
        ReviewedBy = actor;
        Notes = notes;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public bool CanDiscover => State is ProviderApprovalState.ApprovedForDiscovery
        or ProviderApprovalState.ApprovedForEnrichment or ProviderApprovalState.ApprovedForOutreach;
    public bool CanEnrich => State is ProviderApprovalState.ApprovedForEnrichment or ProviderApprovalState.ApprovedForOutreach;
    public bool CanOutreach => State == ProviderApprovalState.ApprovedForOutreach;
}
