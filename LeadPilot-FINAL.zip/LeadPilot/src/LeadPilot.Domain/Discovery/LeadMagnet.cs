namespace LeadPilot.Domain.Discovery;

public enum LeadMagnetKind { Pdf = 1, ShortVideo = 2, Checklist = 3, BudgetCalculator = 4, ConsultationForm = 5, Booking = 6 }

/// <summary>
/// Lead Magnet (سند: Campaign Builder). محتوای جذب که به فرمِ رضایت ختم می‌شود. سناریوی مجاز:
/// محتوا → CTA → لندینگ/فرم → انتخاب زبان → رضایت → دریافتِ Email/WhatsApp → ارسالِ راهنما →
/// پرسش‌های Qualification → ارجاع به کارشناس → CRM. تحویلِ محتوا فقط پس از رضایت.
/// </summary>
public sealed class LeadMagnet
{
    private LeadMagnet() { }

    public LeadMagnet(Guid tenantId, string title, LeadMagnetKind kind, string industry, string city, string language)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("عنوان الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Title = title.Trim();
        Kind = kind;
        Industry = industry.Trim();
        City = city.Trim();
        Language = language.Trim();
        RequiresConsentBeforeDelivery = true; // همیشه
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public LeadMagnetKind Kind { get; private set; }
    public string Industry { get; private set; } = string.Empty;
    public string City { get; private set; } = string.Empty;
    public string Language { get; private set; } = string.Empty;
    public bool RequiresConsentBeforeDelivery { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }
}
