namespace LeadPilot.Domain.Discovery;

/// <summary>نوعِ منبعِ کشف (سند: Source Discovery).</summary>
public enum DiscoverySourceType
{
    GoogleMapsListing = 1, ReviewsAndComments = 2, CompetitorPage = 3, WebsiteDirectory = 4,
    ForumCommunity = 5, NewsArticle = 6, B2BIntentProvider = 7, ApprovedDataProvider = 8, ManualList = 9
}

/// <summary>
/// یک منبعِ کشفِ پیکربندی‌شده برای یک صنعت/شهر. مدیر آن را دسته‌بندی می‌کند و مشخص می‌کند
/// جمع‌آوری از آن مجاز است یا نه. این با کاتالوگِ نوعِ منابع (SourceRegistry) فرق دارد؛ اینجا
/// منبعِ مشخصِ عملیاتی است.
/// </summary>
public sealed class AcquisitionSource
{
    private AcquisitionSource() { }

    public AcquisitionSource(Guid tenantId, string name, DiscoverySourceType type,
        string industry, string country, string? city, string language,
        bool collectionAllowed, string toolUsed)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("نام منبع الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Name = name.Trim();
        Type = type;
        Industry = industry.Trim();
        Country = country.Trim();
        City = city?.Trim();
        Language = language.Trim();
        CollectionAllowed = collectionAllowed;
        ToolUsed = toolUsed.Trim();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public DiscoverySourceType Type { get; private set; }
    public string Industry { get; private set; } = string.Empty;
    public string Country { get; private set; } = string.Empty;
    public string? City { get; private set; }
    public string Language { get; private set; } = string.Empty;
    public int AuthorityScore { get; private set; }
    public bool CollectionAllowed { get; private set; }
    public string ToolUsed { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? LastReviewedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void SetAuthority(int score) => AuthorityScore = Math.Clamp(score, 0, 100);
    public void MarkReviewed() => LastReviewedAtUtc = DateTimeOffset.UtcNow;
    public void SetCollectionAllowed(bool allowed) => CollectionAllowed = allowed;
}
