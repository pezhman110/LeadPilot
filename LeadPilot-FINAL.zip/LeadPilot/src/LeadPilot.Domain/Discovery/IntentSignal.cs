namespace LeadPilot.Domain.Discovery;

/// <summary>اقدامِ بعدیِ مجاز پس از یک سیگنالِ قصد (سند: سیگنال فقط Qualification می‌سازد).</summary>
public enum AllowedNextAction
{
    QualifyOnly = 0,          // فقط امتیازدهی؛ اجازهٔ ارسال نمی‌دهد
    InviteOptInInPlatform = 1,// دعوت به opt-in در محدودهٔ همان پلتفرم
    RouteToLandingForm = 2,   // هدایت به لندینگ/فرمِ رضایت
    HandoffToAgent = 3        // انتقال به کارشناس
}

/// <summary>
/// سیگنالِ قصدِ خرید که از تحلیلِ تجمیعیِ Review/Comment/محتوا کشف می‌شود — نه برداشتِ قطعیِ
/// ویژگیِ روان‌شناختیِ فرد. وجودِ سیگنال فقط Qualification می‌سازد، نه مجوزِ ارسالِ خارج از پلتفرم.
/// </summary>
public sealed class IntentSignal
{
    private IntentSignal() { }

    public IntentSignal(Guid tenantId, string signalType, string source, string textReference,
        string industry, string location, string language, int confidence, AllowedNextAction nextAction)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        SignalType = signalType.Trim();
        Source = source.Trim();
        TextReference = textReference.Trim();
        Industry = industry.Trim();
        Location = location.Trim();
        Language = language.Trim();
        Confidence = Math.Clamp(confidence, 0, 100);
        NextAction = nextAction;
        ObservedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string SignalType { get; private set; } = string.Empty;
    public string Source { get; private set; } = string.Empty;
    public string TextReference { get; private set; } = string.Empty;
    public string Industry { get; private set; } = string.Empty;
    public string Location { get; private set; } = string.Empty;
    public string Language { get; private set; } = string.Empty;
    public int Confidence { get; private set; }
    public AllowedNextAction NextAction { get; private set; }
    public DateTimeOffset ObservedAtUtc { get; private set; }

    /// <summary>سیگنال هرگز به‌تنهایی مجوزِ ارسالِ مستقیم نیست.</summary>
    public bool GrantsDirectOutreach => false;
}
