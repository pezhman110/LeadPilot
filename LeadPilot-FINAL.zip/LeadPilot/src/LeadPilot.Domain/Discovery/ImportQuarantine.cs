namespace LeadPilot.Domain.Discovery;

/// <summary>مراحلِ خطِ قرنطینهٔ Import (سند).</summary>
public enum QuarantineStage
{
    Imported = 0, SourceValidation = 1, ProvenanceValidation = 2, ConsentClassification = 3,
    Deduplication = 4, HumanReview = 5, Approved = 6, Rejected = 7, Quarantined = 8
}

/// <summary>
/// یک رکوردِ واردشده که پیش از هر استفاده باید خطِ قرنطینه را طی کند. هیچ رکوردی مستقیم
/// وارد صفِ ارسال نمی‌شود. بدونِ منبع/منشأ/رضایتِ معتبر → Quarantined و ارسال غیرفعال.
/// </summary>
public sealed class ImportRecord
{
    private ImportRecord() { }

    public ImportRecord(Guid tenantId, DataProviderCode provider, string sourceRef,
        string? sourceUrl, DateTimeOffset collectedAt, bool hasProvenance, bool hasConsentEvidence)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Provider = provider;
        SourceRef = sourceRef.Trim();
        SourceUrl = sourceUrl?.Trim();
        CollectedAt = collectedAt;
        HasProvenance = hasProvenance;
        HasConsentEvidence = hasConsentEvidence;
        Stage = QuarantineStage.Imported;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public DataProviderCode Provider { get; private set; }
    public string SourceRef { get; private set; } = string.Empty;
    public string? SourceUrl { get; private set; }
    public DateTimeOffset CollectedAt { get; private set; }
    public bool HasProvenance { get; private set; }
    public bool HasConsentEvidence { get; private set; }
    public bool IsDuplicate { get; private set; }
    public QuarantineStage Stage { get; private set; }
    public string? Reason { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void Advance(QuarantineStage to) => Stage = to;
    public void MarkDuplicate() { IsDuplicate = true; }
    public void Reject(string reason) { Stage = QuarantineStage.Rejected; Reason = reason; }
    public void Quarantine(string reason) { Stage = QuarantineStage.Quarantined; Reason = reason; }
    public void Approve() { Stage = QuarantineStage.Approved; }

    public bool SendingEnabled => Stage == QuarantineStage.Approved;
}
