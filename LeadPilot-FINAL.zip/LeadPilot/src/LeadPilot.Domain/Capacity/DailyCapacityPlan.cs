namespace LeadPilot.Domain.Capacity;

public enum DailyCapacityPlanStatus
{
    Draft = 1,
    Scheduled = 2,
    Running = 3,
    Paused = 4,
    Completed = 5,
    CompletedWithShortage = 6,
    Cancelled = 7
}

/// <summary>
/// برنامهٔ ظرفیت روزانه: ۳۰۰۰ اطلاعات تماس در پنجرهٔ ۴ ساعته، بدون قفل/تکرار.
/// (RowVersion=uint برای Postgres)
/// </summary>
public sealed class DailyCapacityPlan
{
    private readonly List<ProjectDailyQuota> _quotas = [];
    private DailyCapacityPlan() { }

    public DailyCapacityPlan(
        Guid tenantId, DateOnly businessDate, TimeOnly windowStartUtc, TimeOnly windowEndUtc,
        int targetSignals, int targetContacts, int targetConsents, int designCapacity, string createdBy)
    {
        if (tenantId == Guid.Empty) throw new ArgumentException("شناسه سازمان معتبر نیست.");
        if (windowEndUtc <= windowStartUtc) throw new ArgumentException("پایان پنجره باید بعد از شروع باشد.");
        if (targetSignals <= 0 || targetContacts <= 0 || targetConsents < 0 || designCapacity < targetContacts)
            throw new ArgumentException("اهداف ظرفیت معتبر نیستند.");
        if (string.IsNullOrWhiteSpace(createdBy)) throw new ArgumentException("ایجادکننده مشخص نیست.");

        Id = Guid.NewGuid();
        TenantId = tenantId;
        BusinessDate = businessDate;
        WindowStartUtc = windowStartUtc;
        WindowEndUtc = windowEndUtc;
        TargetSignals = targetSignals;
        TargetContacts = targetContacts;
        TargetConsents = targetConsents;
        DesignCapacity = designCapacity;
        CreatedBy = createdBy.Trim();
        Status = DailyCapacityPlanStatus.Draft;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public DateOnly BusinessDate { get; private set; }
    public TimeOnly WindowStartUtc { get; private set; }
    public TimeOnly WindowEndUtc { get; private set; }
    public int TargetSignals { get; private set; }
    public int TargetContacts { get; private set; }
    public int TargetConsents { get; private set; }
    public int DesignCapacity { get; private set; }
    public DailyCapacityPlanStatus Status { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? StartedAtUtc { get; private set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public IReadOnlyCollection<ProjectDailyQuota> Quotas => _quotas;

    public void AddQuota(string groupCode, Guid? projectId, int contactTarget, int consentTarget, int priority, bool isFlexible)
    {
        if (Status != DailyCapacityPlanStatus.Draft) throw new InvalidOperationException("سهمیه فقط در پیش‌نویس قابل تغییر است.");
        if (string.IsNullOrWhiteSpace(groupCode)) throw new ArgumentException("کد گروه الزامی است.");
        if (contactTarget < 0 || consentTarget < 0) throw new ArgumentOutOfRangeException(nameof(contactTarget));
        if (priority is < 1 or > 100) throw new ArgumentOutOfRangeException(nameof(priority));
        _quotas.Add(new ProjectDailyQuota(Id, groupCode, projectId, contactTarget, consentTarget, priority, isFlexible));
    }

    public void Schedule()
    {
        if (_quotas.Count == 0) throw new InvalidOperationException("سهمیه‌ای ثبت نشده است.");
        int total = _quotas.Sum(x => x.ContactTarget);
        if (total > DesignCapacity) throw new InvalidOperationException("جمع سهمیه‌ها از ظرفیت طراحی بیشتر است.");
        Status = DailyCapacityPlanStatus.Scheduled;
    }

    public void Start(DateTimeOffset nowUtc)
    {
        if (Status is not DailyCapacityPlanStatus.Scheduled and not DailyCapacityPlanStatus.Paused)
            throw new InvalidOperationException("برنامه قابل شروع نیست.");
        Status = DailyCapacityPlanStatus.Running;
        StartedAtUtc ??= nowUtc;
    }

    public void Pause()
    {
        if (Status != DailyCapacityPlanStatus.Running) throw new InvalidOperationException("برنامه در حال اجرا نیست.");
        Status = DailyCapacityPlanStatus.Paused;
    }

    public void Complete(bool hasShortage, DateTimeOffset nowUtc)
    {
        Status = hasShortage ? DailyCapacityPlanStatus.CompletedWithShortage : DailyCapacityPlanStatus.Completed;
        CompletedAtUtc = nowUtc;
    }

    public void Cancel(DateTimeOffset nowUtc)
    {
        Status = DailyCapacityPlanStatus.Cancelled;
        CompletedAtUtc = nowUtc;
    }
}
