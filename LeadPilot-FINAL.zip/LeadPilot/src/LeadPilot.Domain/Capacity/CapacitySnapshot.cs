namespace LeadPilot.Domain.Capacity;

/// <summary>Snapshot عملکرد (هر ۱–۵ دقیقه)، تا شمارش هر بار از میلیون‌ها رکورد نباشد.</summary>
public sealed class CapacitySnapshot
{
    private CapacitySnapshot() { }
    public CapacitySnapshot(Guid planId, Guid quotaId, int signalsDiscovered, int contactsCreated,
        int duplicateContacts, int validConsents, int failedJobs, int deadLetterJobs, decimal costAed,
        DateTimeOffset capturedAtUtc)
    {
        Id = Guid.NewGuid();
        PlanId = planId; QuotaId = quotaId;
        SignalsDiscovered = signalsDiscovered; ContactsCreated = contactsCreated;
        DuplicateContacts = duplicateContacts; ValidConsents = validConsents;
        FailedJobs = failedJobs; DeadLetterJobs = deadLetterJobs;
        CostAed = costAed; CapturedAtUtc = capturedAtUtc;
    }
    public Guid Id { get; private set; }
    public Guid PlanId { get; private set; }
    public Guid QuotaId { get; private set; }
    public int SignalsDiscovered { get; private set; }
    public int ContactsCreated { get; private set; }
    public int DuplicateContacts { get; private set; }
    public int ValidConsents { get; private set; }
    public int FailedJobs { get; private set; }
    public int DeadLetterJobs { get; private set; }
    public decimal CostAed { get; private set; }
    public DateTimeOffset CapturedAtUtc { get; private set; }
}
