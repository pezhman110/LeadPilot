namespace LeadPilot.Domain.Capacity;

public sealed class ProjectDailyQuota
{
    private ProjectDailyQuota() { }

    internal ProjectDailyQuota(Guid dailyCapacityPlanId, string groupCode, Guid? projectId,
        int contactTarget, int consentTarget, int priority, bool isFlexible)
    {
        Id = Guid.NewGuid();
        DailyCapacityPlanId = dailyCapacityPlanId;
        GroupCode = groupCode.Trim().ToUpperInvariant();
        ProjectId = projectId;
        ContactTarget = contactTarget;
        ConsentTarget = consentTarget;
        Priority = priority;
        IsFlexible = isFlexible;
        IsActive = true;
    }

    public Guid Id { get; private set; }
    public Guid DailyCapacityPlanId { get; private set; }
    public string GroupCode { get; private set; } = string.Empty;
    public Guid? ProjectId { get; private set; }
    public int ContactTarget { get; private set; }
    public int ConsentTarget { get; private set; }
    public int SignalTarget { get; private set; }
    public int Priority { get; private set; }
    public bool IsFlexible { get; private set; }
    public bool IsActive { get; private set; }
    public DailyCapacityPlan DailyCapacityPlan { get; private set; } = null!;

    public void SetSignalTarget(decimal observedContactDiscoveryRate)
    {
        if (observedContactDiscoveryRate is <= 0 or > 1) throw new ArgumentOutOfRangeException(nameof(observedContactDiscoveryRate));
        SignalTarget = (int)Math.Ceiling(ContactTarget / observedContactDiscoveryRate);
    }
    public void Deactivate() => IsActive = false;
}
