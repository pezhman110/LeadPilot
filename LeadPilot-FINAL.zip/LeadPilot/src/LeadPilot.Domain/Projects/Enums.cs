namespace LeadPilot.Domain.Projects;

public enum CustomerType
{
    Personal = 1,
    Corporate = 2
}

public enum ProjectStatus
{
    Draft = 1,
    Active = 2,
    Paused = 3,
    Archived = 4
}
