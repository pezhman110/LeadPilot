namespace LeadPilot.Domain.Projects;

/// <summary>
/// ریشهٔ Aggregate پروژه. یک موتور، ۱۶ پروژه؛ هر پروژه فقط با Configuration.
/// همهٔ invariantها داخل خودِ دامنه تضمین می‌شوند (نه در Endpoint یا UI).
/// </summary>
public sealed class Project
{
    private readonly List<ProjectLanguage> _languages = [];
    private readonly List<ProjectGeography> _geographies = [];

    private static readonly string[] AllowedLanguageCodes = ["ar", "en", "fa", "hi", "fr", "ru"];

    private Project() { }

    public Project(
        string persianName,
        string englishName,
        CustomerType customerType,
        decimal? minimumBudgetAed,
        int minimumSignalScore,
        int managerReviewScore,
        int salesAssignmentScore)
    {
        if (string.IsNullOrWhiteSpace(persianName))
            throw new ArgumentException("نام فارسی پروژه الزامی است.");
        if (string.IsNullOrWhiteSpace(englishName))
            throw new ArgumentException("نام انگلیسی پروژه الزامی است.");

        ValidateScores(minimumSignalScore, managerReviewScore, salesAssignmentScore);

        Id = Guid.NewGuid();
        PersianName = persianName.Trim();
        EnglishName = englishName.Trim();
        CustomerType = customerType;
        MinimumBudgetAed = minimumBudgetAed;
        MinimumSignalScore = minimumSignalScore;
        ManagerReviewScore = managerReviewScore;
        SalesAssignmentScore = salesAssignmentScore;
        Status = ProjectStatus.Draft;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public string PersianName { get; private set; } = string.Empty;
    public string EnglishName { get; private set; } = string.Empty;
    public CustomerType CustomerType { get; private set; }
    public ProjectStatus Status { get; private set; }
    public decimal? MinimumBudgetAed { get; private set; }
    public int MinimumSignalScore { get; private set; }
    public int ManagerReviewScore { get; private set; }
    public int SalesAssignmentScore { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? UpdatedAtUtc { get; private set; }

    /// <summary>کنترل همزمانی خوش‌بینانه (optimistic concurrency).</summary>
    public uint RowVersion { get; private set; }

    public IReadOnlyCollection<ProjectLanguage> Languages => _languages;
    public IReadOnlyCollection<ProjectGeography> Geographies => _geographies;

    public void AddLanguage(string code)
    {
        var normalized = code.Trim().ToLowerInvariant();
        if (!AllowedLanguageCodes.Contains(normalized))
            throw new ArgumentException($"زبان {normalized} پشتیبانی نمی‌شود.");
        if (_languages.Any(x => x.Code == normalized))
            return; // تکراری ذخیره نشود
        _languages.Add(new ProjectLanguage(Id, normalized));
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void AddGeography(string countryCode, string? city, int priority)
    {
        if (string.IsNullOrWhiteSpace(countryCode))
            throw new ArgumentException("کد کشور الزامی است.");
        _geographies.Add(new ProjectGeography(Id, countryCode, city, priority));
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    /// <summary>فعال‌سازی: فقط از Draft/Paused و فقط اگر حداقل یک جغرافیا دارد.</summary>
    public void Activate()
    {
        if (Status is not (ProjectStatus.Draft or ProjectStatus.Paused))
            throw new InvalidOperationException($"پروژه در وضعیت {Status} قابل فعال‌سازی نیست.");
        if (_geographies.Count == 0)
            throw new InvalidOperationException("پروژه بدون جغرافیا قابل فعال‌سازی نیست.");
        Status = ProjectStatus.Active;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    /// <summary>توقف: فقط از Active. Draft مستقیماً Pause نمی‌شود.</summary>
    public void Pause()
    {
        if (Status is not ProjectStatus.Active)
            throw new InvalidOperationException($"فقط پروژهٔ فعال قابل توقف است (وضعیت فعلی: {Status}).");
        Status = ProjectStatus.Paused;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public void Archive()
    {
        Status = ProjectStatus.Archived;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    /// <summary>
    /// امتیازها باید در بازهٔ ۰..۱۰۰ و به ترتیب صعودی باشند:
    /// minimumSignal ≤ managerReview ≤ salesAssignment.
    /// </summary>
    private static void ValidateScores(int minimumSignalScore, int managerReviewScore, int salesAssignmentScore)
    {
        if (minimumSignalScore is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(minimumSignalScore));
        if (managerReviewScore is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(managerReviewScore));
        if (salesAssignmentScore is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(salesAssignmentScore));

        if (managerReviewScore < minimumSignalScore)
            throw new ArgumentException("امتیاز بازبینی مدیر نباید کمتر از حداقل امتیاز سیگنال باشد.");
        if (salesAssignmentScore < managerReviewScore)
            throw new ArgumentException("امتیاز تخصیص فروش نباید کمتر از امتیاز بازبینی مدیر باشد.");
    }
}
