namespace LeadPilot.Domain.Projects;

public sealed class ProjectLanguage
{
    private ProjectLanguage() { }

    public ProjectLanguage(Guid projectId, string code)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        Code = code.Trim().ToLowerInvariant();
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public Project Project { get; private set; } = null!;
}

public sealed class ProjectGeography
{
    private ProjectGeography() { }

    public ProjectGeography(Guid projectId, string countryCode, string? city, int priority)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        CountryCode = countryCode.Trim().ToUpperInvariant();
        City = string.IsNullOrWhiteSpace(city) ? null : city.Trim();
        Priority = priority;
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public string CountryCode { get; private set; } = string.Empty;
    public string? City { get; private set; }
    public int Priority { get; private set; }
    public Project Project { get; private set; } = null!;
}
