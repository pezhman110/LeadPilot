namespace LeadPilot.Domain.Lifecycle;

/// <summary>
/// مدرکِ آرشیوشدهٔ رضایت (سند: آرشیو رضایت‌نامه). بدونِ این، مسیرِ تماس ادامه نمی‌یابد.
/// جدا از هر کانال؛ چه چیزی، کِی، از چه راهی، و مرجعِ ذخیره‌سازیِ فایلِ رضایت.
/// </summary>
public sealed class ConsentEvidence
{
    private ConsentEvidence() { }

    public ConsentEvidence(Guid tenantId, Guid prospectId, string channel, string method,
        string evidenceRef, DateTimeOffset capturedAtUtc)
    {
        if (string.IsNullOrWhiteSpace(evidenceRef)) throw new ArgumentException("مرجعِ مدرک الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ProspectId = prospectId;
        Channel = channel.Trim();
        Method = method.Trim();
        EvidenceRef = evidenceRef.Trim();
        CapturedAtUtc = capturedAtUtc;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ProspectId { get; private set; }
    public string Channel { get; private set; } = string.Empty;
    public string Method { get; private set; } = string.Empty;
    public string EvidenceRef { get; private set; } = string.Empty;
    public DateTimeOffset CapturedAtUtc { get; private set; }
}

/// <summary>سیاستِ نگهداری: هر دادهٔ تماس چه زمانی باید حذف شود (سند: «چه زمانی باید حذف شود»).</summary>
public sealed class DataRetentionPolicy
{
    private DataRetentionPolicy() { }

    public DataRetentionPolicy(Guid tenantId, string dataCategory, int retentionDays, string lawfulBasis)
    {
        if (retentionDays < 1) throw new ArgumentOutOfRangeException(nameof(retentionDays));
        Id = Guid.NewGuid();
        TenantId = tenantId;
        DataCategory = dataCategory.Trim();
        RetentionDays = retentionDays;
        LawfulBasis = lawfulBasis.Trim();
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string DataCategory { get; private set; } = string.Empty;
    public int RetentionDays { get; private set; }
    public string LawfulBasis { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public DateTimeOffset ExpiryFrom(DateTimeOffset collectedAt) => collectedAt.AddDays(RetentionDays);
    public bool IsExpired(DateTimeOffset collectedAt, DateTimeOffset now) => now >= ExpiryFrom(collectedAt);
}

public enum DeletionRequestStatus { Received = 0, Verifying = 1, Approved = 2, Executed = 3, Rejected = 4 }

/// <summary>درخواستِ حذف/فراموشی (UAE PDPL/GDPR right-to-erasure). سند: DeletionRequest.</summary>
public sealed class DeletionRequest
{
    private DeletionRequest() { }

    public DeletionRequest(Guid tenantId, Guid prospectId, string requestedBy, string reason)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ProspectId = prospectId;
        RequestedBy = requestedBy.Trim();
        Reason = reason.Trim();
        Status = DeletionRequestStatus.Received;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ProspectId { get; private set; }
    public string RequestedBy { get; private set; } = string.Empty;
    public string Reason { get; private set; } = string.Empty;
    public DeletionRequestStatus Status { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? ExecutedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void MarkVerifying() => Status = DeletionRequestStatus.Verifying;
    public void Approve() => Status = DeletionRequestStatus.Approved;
    public void Reject() => Status = DeletionRequestStatus.Rejected;
    public void MarkExecuted() { Status = DeletionRequestStatus.Executed; ExecutedAtUtc = DateTimeOffset.UtcNow; }
}
