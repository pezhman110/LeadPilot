namespace LeadPilot.Domain.Crm;

/// <summary>ارائه‌دهندهٔ CRM برای اتصالِ نتیجهٔ عملکردِ کارشناسِ فروش.</summary>
public enum CrmProvider { HubSpot = 1, Salesforce = 2, Zoho = 3, Pipedrive = 4, GenericWebhook = 5 }

public enum CrmConnectionStatus { NotConfigured = 0, Connected = 1, AuthFailed = 2, Disabled = 3 }

/// <summary>
/// اتصالِ CRM. مثلِ Connectorها، فقط SecretReference نگه داشته می‌شود، نه Token/API Key.
/// </summary>
public sealed class CrmConnection
{
    private CrmConnection() { }

    public CrmConnection(Guid tenantId, CrmProvider provider, string displayName, string? baseUrl, string? secretReference)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Provider = provider;
        DisplayName = displayName.Trim();
        BaseUrl = string.IsNullOrWhiteSpace(baseUrl) ? null : baseUrl.Trim();
        SecretReference = string.IsNullOrWhiteSpace(secretReference) ? null : secretReference.Trim();
        Status = CrmConnectionStatus.NotConfigured;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public CrmProvider Provider { get; private set; }
    public string DisplayName { get; private set; } = string.Empty;
    public string? BaseUrl { get; private set; }
    public string? SecretReference { get; private set; }
    public CrmConnectionStatus Status { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void MarkConnected() => Status = CrmConnectionStatus.Connected;
    public void MarkAuthFailed() => Status = CrmConnectionStatus.AuthFailed;
    public void Disable() => Status = CrmConnectionStatus.Disabled;
}

public enum CrmSyncStatus { Pending = 0, Pushed = 1, Failed = 2 }

/// <summary>رکوردِ ارسالِ نتیجهٔ یک تماس/سرنخ به CRM.</summary>
public sealed class CrmSyncRecord
{
    private CrmSyncRecord() { }

    public CrmSyncRecord(Guid tenantId, Guid crmConnectionId, Guid prospectId, string outcome)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        CrmConnectionId = crmConnectionId;
        ProspectId = prospectId;
        Outcome = outcome;
        Status = CrmSyncStatus.Pending;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid CrmConnectionId { get; private set; }
    public Guid ProspectId { get; private set; }
    public string Outcome { get; private set; } = string.Empty;
    public string? ExternalId { get; private set; }
    public CrmSyncStatus Status { get; private set; }
    public string? Error { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void MarkPushed(string externalId) { ExternalId = externalId; Status = CrmSyncStatus.Pushed; }
    public void MarkFailed(string error) { Error = error; Status = CrmSyncStatus.Failed; }
}
