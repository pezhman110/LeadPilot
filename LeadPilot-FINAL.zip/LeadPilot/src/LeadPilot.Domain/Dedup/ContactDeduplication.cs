using System.Security.Cryptography;
using System.Text;

namespace LeadPilot.Domain.Dedup;

public enum ContactType { Phone = 0, Email = 1 }

/// <summary>
/// نرمال‌سازی + هشِ غیرقابل‌نمایش برای تشخیص تکراری. مطابق سند:
/// تلفن → +E.164، ایمیل → lowercase؛ سپس HMAC-SHA256 → ContactHash.
/// مقدار اصلی رمزنگاری می‌شود؛ فقط Hash برای dedup به‌کار می‌رود.
/// </summary>
public static class ContactNormalizer
{
    /// <summary>نرمال‌سازی تلفن به +E.164 (پیش‌فرض کد کشور امارات 971).</summary>
    public static string NormalizePhone(string raw, string defaultCountryCode = "971")
    {
        if (string.IsNullOrWhiteSpace(raw)) throw new ArgumentException("شماره خالی است.");
        var digits = new string(raw.Where(char.IsDigit).ToArray());
        // 00971… → 971…
        if (digits.StartsWith("00")) digits = digits[2..];
        // 0501234567 (محلی) → 971501234567
        if (digits.StartsWith("0")) digits = defaultCountryCode + digits[1..];
        // 501234567 (بدون صفر و بدون کد) → افزودن کد کشور
        else if (digits.Length <= 9) digits = defaultCountryCode + digits;
        return "+" + digits;
    }

    public static string NormalizeEmail(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) throw new ArgumentException("ایمیل خالی است.");
        return raw.Trim().ToLowerInvariant();
    }

    public static string Normalize(ContactType type, string raw) =>
        type == ContactType.Phone ? NormalizePhone(raw) : NormalizeEmail(raw);

    /// <summary>HMAC-SHA256 روی مقدار نرمال‌شده. کلید از پیکربندی می‌آید (اینجا پارامتر).</summary>
    public static string Hash(ContactType type, string raw, byte[] key)
    {
        var norm = Normalize(type, raw);
        using var hmac = new HMACSHA256(key);
        var bytes = hmac.ComputeHash(Encoding.UTF8.GetBytes($"{(int)type}:{norm}"));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }
}

/// <summary>
/// پرونده الکترونیکیِ یک نقطهٔ تماس، با تاریخچهٔ کامل (سند بخش ۸).
/// قید یکتایی: TenantId + ContactType + ContactHash.
/// </summary>
public sealed class ContactRecord
{
    private readonly List<ContactObservation> _observations = [];
    private ContactRecord() { }

    public ContactRecord(Guid tenantId, ContactType type, string contactHash, string firstSource)
    {
        if (string.IsNullOrWhiteSpace(contactHash)) throw new ArgumentException("hash الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ContactType = type;
        ContactHash = contactHash;
        var now = DateTimeOffset.UtcNow;
        FirstSeenAtUtc = now;
        LastSeenAtUtc = now;
        _observations.Add(new ContactObservation(Id, firstSource, now));
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public ContactType ContactType { get; private set; }
    public string ContactHash { get; private set; } = string.Empty;

    public DateTimeOffset FirstSeenAtUtc { get; private set; }
    public DateTimeOffset LastSeenAtUtc { get; private set; }
    public DateTimeOffset? LastValidatedAtUtc { get; private set; }
    public DateTimeOffset? LastEnrichedAtUtc { get; private set; }
    public DateTimeOffset? LastInvitationAtUtc { get; private set; }
    public DateTimeOffset? LastConsentAtUtc { get; private set; }
    public DateTimeOffset? LastUsedAtUtc { get; private set; }
    public bool IsSuppressed { get; private set; }

    public IReadOnlyCollection<ContactObservation> Observations => _observations;

    /// <summary>
    /// مشاهدهٔ همان شماره از منبعِ دیگر: ContactPoint جدید ساخته نمی‌شود،
    /// هزینهٔ خرید دوباره پرداخت نمی‌شود، فقط Observation ثبت می‌شود.
    /// </summary>
    public void AddObservation(string source)
    {
        _observations.Add(new ContactObservation(Id, source, DateTimeOffset.UtcNow));
        LastSeenAtUtc = DateTimeOffset.UtcNow;
    }

    public void MarkValidated() => LastValidatedAtUtc = DateTimeOffset.UtcNow;
    public void MarkEnriched() => LastEnrichedAtUtc = DateTimeOffset.UtcNow;
    public void MarkInvited() => LastInvitationAtUtc = DateTimeOffset.UtcNow;
    public void MarkConsented() => LastConsentAtUtc = DateTimeOffset.UtcNow;
    public void MarkUsed() => LastUsedAtUtc = DateTimeOffset.UtcNow;
    public void Suppress() => IsSuppressed = true;

    /// <summary>شمارهٔ موجود دوباره خریداری نشود (سند بخش ۸).</summary>
    public bool ShouldRepurchase() => false;
}

/// <summary>مشاهدهٔ یک شماره از یک منبع در یک زمان (بدون خرید مجدد).</summary>
public sealed class ContactObservation
{
    private ContactObservation() { }
    public ContactObservation(Guid contactRecordId, string source, DateTimeOffset seenAtUtc)
    {
        Id = Guid.NewGuid();
        ContactRecordId = contactRecordId;
        Source = source;
        SeenAtUtc = seenAtUtc;
    }
    public Guid Id { get; private set; }
    public Guid ContactRecordId { get; private set; }
    public string Source { get; private set; } = string.Empty;
    public DateTimeOffset SeenAtUtc { get; private set; }
}

/// <summary>
/// رزروِ Enrichment: قبل از درخواست از Provider، تا دو Worker هم‌زمان
/// یک نفر را دوبار نخرند. کلید: ENRICH:{ProspectId}:{ProviderCode}:{Purpose}.
/// </summary>
public sealed class EnrichmentReservation
{
    private EnrichmentReservation() { }
    public EnrichmentReservation(Guid prospectId, string providerCode, string purpose)
    {
        Id = Guid.NewGuid();
        ProspectId = prospectId;
        ProviderCode = providerCode;
        Purpose = purpose;
        Key = $"ENRICH:{prospectId}:{providerCode}:{purpose}";
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid ProspectId { get; private set; }
    public string ProviderCode { get; private set; } = string.Empty;
    public string Purpose { get; private set; } = string.Empty;
    public string Key { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }
}
