namespace LeadPilot.Domain.Communications;

/// <summary>
/// قواعدِ اختصاصیِ هر کانال (سند: هر شبکه امکاناتِ متفاوت). این‌ها تصمیمِ موتورِ مسیریابی را می‌سازند.
/// - CanInitiate: آیا می‌توان مکالمهٔ جدید آغاز کرد؟ (تلگرام: خیر مگر کاربر شروع کند)
/// - RequiresApprovedTemplate: واتساپ خارج از پنجرهٔ ۲۴ساعته Template تأییدشده می‌خواهد.
/// - RequiresIncomingWindow: اینستاگرام فقط پاسخ به مکالمهٔ ورودی (پنجرهٔ باز).
/// - MessagingWindowHours: طولِ پنجرهٔ مجازِ پاسخ پس از آخرین پیامِ کاربر.
/// </summary>
public readonly record struct ChannelCapability(
    CommunicationChannel Channel,
    bool CanInitiate,
    bool RequiresApprovedTemplate,
    bool RequiresIncomingWindow,
    int MessagingWindowHours,
    bool OutboundSupported)
{
    public static ChannelCapability For(CommunicationChannel channel) => channel switch
    {
        // اینستاگرام/مسنجر: آغازِ آزاد نه؛ فقط در پنجرهٔ ۲۴ساعتهٔ پاسخ.
        CommunicationChannel.InstagramDm => new(channel, false, false, true, 24, true),
        CommunicationChannel.MessengerDm => new(channel, false, false, true, 24, true),
        // واتساپ: آغاز با Template تأییدشده؛ پنجرهٔ ۲۴ساعته برای پیامِ آزاد.
        CommunicationChannel.WhatsApp => new(channel, true, true, false, 24, true),
        // تلگرام: Bot نمی‌تواند دلخواه آغاز کند؛ کاربر باید شروع کند.
        CommunicationChannel.TelegramDm => new(channel, false, false, true, 0, true),
        // تیک‌تاک: فرضِ API عمومیِ DM نداریم؛ فقط ورودی/Lead Form/انتقال.
        CommunicationChannel.TikTokDm => new(channel, false, false, true, 0, false),
        // ایمیل: آغازِ آزاد با opt-in + unsubscribe.
        CommunicationChannel.Email => new(channel, true, false, false, 0, true),
        CommunicationChannel.Sms => new(channel, true, false, false, 0, true),
        _ => new(channel, false, false, true, 0, false)
    };
}

/// <summary>نتیجهٔ تصمیمِ موتورِ مسیریابی برای یک کانال.</summary>
public enum RoutingStatus
{
    Permitted = 0,
    NotConfigured = 1,
    NeedsConsent = 2,
    NeedsHumanApproval = 3,
    TemporarilyUnavailable = 4,
    PlatformWindowClosed = 5,
    ProviderUnavailable = 6,
    Blocked = 7,
    DuplicateRecent = 8
}
