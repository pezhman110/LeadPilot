namespace LeadPilot.Domain.Communications;

/// <summary>
/// Playbookِ اختصاصیِ یک کانال (سند: هر کانال روش، فیلدهای مجاز، روشِ رضایت، نرخ و ریسکِ خودش).
/// PacingSeconds = فاصلهٔ محترمانه و مطابقِ محدودیتِ رسمیِ کانال — نه برای فریبِ تشخیص، بلکه برای
/// رعایتِ نرخِ مجاز و طبیعی‌بودنِ ارتباط. DailyCap = سقفِ روزانهٔ همان کانال.
/// </summary>
public sealed class ChannelPlaybook
{
    private ChannelPlaybook() { }

    public ChannelPlaybook(Guid tenantId, CommunicationChannel channel,
        string discoveryMethods, string permittedFields, string consentMethod,
        int minPacingSeconds, int dailyCap, decimal expectedCostAed, string platformRisks)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Channel = channel;
        DiscoveryMethods = discoveryMethods;
        PermittedFields = permittedFields;
        ConsentMethod = consentMethod;
        MinPacingSeconds = Math.Max(0, minPacingSeconds);
        DailyCap = Math.Max(0, dailyCap);
        ExpectedCostAed = expectedCostAed;
        PlatformRisks = platformRisks;
        IsOutboundTextAllowed = channel is not (CommunicationChannel.TikTokDm); // نمونه؛ قابلِ تنظیم
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public CommunicationChannel Channel { get; private set; }
    public string DiscoveryMethods { get; private set; } = string.Empty;
    public string PermittedFields { get; private set; } = string.Empty;
    public string ConsentMethod { get; private set; } = string.Empty;
    public int MinPacingSeconds { get; private set; }
    public int DailyCap { get; private set; }
    public decimal ExpectedCostAed { get; private set; }
    public string PlatformRisks { get; private set; } = string.Empty;
    public bool IsOutboundTextAllowed { get; private set; }
    public uint RowVersion { get; private set; }
}
