namespace LeadPilot.Domain.Communications;

/// <summary>
/// قاعدهٔ اتوماسیونِ کامنتِ اینستاگرام — مثلِ ManyChat، ولی فقط از راهِ Instagram Graph API رسمی
/// (کامنت روی پستِ اکانتِ Business خودِ شرکت → پاسخ/دعوتِ DM). چون از API است، سرعت بالاست.
/// حالتِ Automatic: پاسخِ خودکار. حالتِ Manual: در صف برای تأییدِ کارشناس.
/// این «اسکرپینگ» یا «ربات روی اکانتِ شخصی» نیست؛ فقط واکنش به کامنتِ عمومی روی پستِ خودِ شرکت.
/// </summary>
public sealed class InstagramCommentRule
{
    private InstagramCommentRule() { }

    public InstagramCommentRule(Guid tenantId, string name, string keyword,
        string publicReplyTemplateRef, string dmInviteTemplateRef, OutreachMode mode)
    {
        if (string.IsNullOrWhiteSpace(keyword)) throw new ArgumentException("کلیدواژهٔ تریگر الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Name = name.Trim();
        Keyword = keyword.Trim().ToLowerInvariant();
        PublicReplyTemplateRef = publicReplyTemplateRef;
        DmInviteTemplateRef = dmInviteTemplateRef;
        Mode = mode;
        IsEnabled = false;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string Keyword { get; private set; } = string.Empty;
    public string PublicReplyTemplateRef { get; private set; } = string.Empty;
    public string DmInviteTemplateRef { get; private set; } = string.Empty;
    public OutreachMode Mode { get; private set; }
    public bool IsEnabled { get; private set; }
    public int MatchedCount { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void Enable() => IsEnabled = true;
    public void Disable() => IsEnabled = false;
    public void SetMode(OutreachMode mode) => Mode = mode;

    /// <summary>آیا این کامنت با قاعده مطابقت دارد؟</summary>
    public bool Matches(string commentText) =>
        IsEnabled && !string.IsNullOrWhiteSpace(commentText) &&
        commentText.ToLowerInvariant().Contains(Keyword);

    public void RecordMatch() => MatchedCount++;
}
