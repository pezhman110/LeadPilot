namespace LeadPilot.Domain.Communications;

/// <summary>ابزارهای Omnichannel/ارسال. هر کدام Connectorِ رسمیِ خودش را دارد.</summary>
public enum MessagingProviderCode
{
    ManyChat = 1,
    RespondIo = 2,
    Wati = 3,
    WhatsAppCloudApi = 4,
    WhatsAppBusinessPro = 5,
    Zoho = 6,
    NovoChat = 7,
    Pabbly = 8,
    NativeApi = 9
}

/// <summary>
/// پیکربندیِ اولویتِ ابزار برای یک کانال (Failover). مثال: برای WhatsApp
/// اولویت ۱ = WATI، اولویت ۲ = WhatsApp Cloud API، اولویت ۳ = Respond.io.
/// موتور به ترتیبِ اولویت تلاش می‌کند؛ اگر یکی ناموفق شد، بعدی را امتحان می‌کند.
/// </summary>
public sealed class ChannelProviderConfig
{
    private ChannelProviderConfig() { }

    public ChannelProviderConfig(Guid tenantId, CommunicationChannel channel,
        MessagingProviderCode provider, int priority)
    {
        if (priority is < 1 or > 100) throw new ArgumentOutOfRangeException(nameof(priority));
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Channel = channel;
        Provider = provider;
        Priority = priority;
        IsEnabled = true;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public CommunicationChannel Channel { get; private set; }
    public MessagingProviderCode Provider { get; private set; }
    public int Priority { get; private set; }
    public bool IsEnabled { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    public void SetPriority(int priority) { if (priority is >= 1 and <= 100) Priority = priority; }
    public void Enable() => IsEnabled = true;
    public void Disable() => IsEnabled = false;
}
