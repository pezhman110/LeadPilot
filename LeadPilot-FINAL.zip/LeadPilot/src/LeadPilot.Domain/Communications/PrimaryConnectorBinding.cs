namespace LeadPilot.Domain.Communications;

public enum ConnectorRole { Primary = 0, FallbackManual = 1 }

/// <summary>
/// مسیرِ اصلیِ یک حساب+کانال (سند: فقط یک مسیرِ اصلی تا از ارسالِ تکراری/Webhook تکراری/
/// مالکِ نامشخصِ مکالمه جلوگیری شود). پشتیبان فقط با «فعال‌سازیِ دستی»، هرگز همزمان با اصلی.
/// یکتایی: فقط یک Primary برای هر Tenant+Channel+Account.
/// </summary>
public sealed class PrimaryConnectorBinding
{
    private PrimaryConnectorBinding() { }

    public PrimaryConnectorBinding(Guid tenantId, CommunicationChannel channel, string accountRef,
        MessagingProviderCode provider, ConnectorRole role)
    {
        if (string.IsNullOrWhiteSpace(accountRef)) throw new ArgumentException("شناسهٔ حساب الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        Channel = channel;
        AccountRef = accountRef.Trim();
        Provider = provider;
        Role = role;
        // کلیدِ یکتاییِ Primary: فقط برای رکوردِ Primary مقدار دارد.
        PrimaryKey = role == ConnectorRole.Primary ? $"{tenantId}:{(int)channel}:{AccountRef}" : null;
        FallbackActivated = false;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public CommunicationChannel Channel { get; private set; }
    public string AccountRef { get; private set; } = string.Empty;
    public MessagingProviderCode Provider { get; private set; }
    public ConnectorRole Role { get; private set; }
    /// <summary>برای ایندکسِ یکتا: یک Primary در هر Tenant+Channel+Account.</summary>
    public string? PrimaryKey { get; private set; }
    public bool FallbackActivated { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    /// <summary>پشتیبان فقط با فعال‌سازیِ دستیِ صریح کار می‌کند، نه خودکار همزمان با اصلی.</summary>
    public void ActivateFallbackManually() { if (Role == ConnectorRole.FallbackManual) FallbackActivated = true; }
    public void DeactivateFallback() => FallbackActivated = false;

    public bool CanSendNow(bool primaryHealthy) =>
        Role == ConnectorRole.Primary
            ? primaryHealthy
            : FallbackActivated && !primaryHealthy; // پشتیبان فقط وقتی اصلی خراب است و دستی فعال شده
}
