namespace LeadPilot.Domain.Communications;

/// <summary>کانالِ ارتباطی. هر کانال نسخهٔ اختصاصیِ خودش را دارد (سند: هر کانال Playbook مستقل).</summary>
public enum CommunicationChannel
{
    InstagramDm = 1,
    WhatsApp = 2,
    Email = 3,
    Sms = 4,
    MessengerDm = 5,
    TelegramDm = 6,
    TikTokDm = 7
}

/// <summary>حالتِ ارسال: دستی (کارشناس تأیید/می‌فرستد) یا خودکار (قاعده‌محور، فقط با API رسمی).</summary>
public enum OutreachMode { Manual = 0, Automatic = 1 }

/// <summary>وضعیتِ رضایتِ هر کانال، جدا از کانال‌های دیگر (سند).</summary>
public enum ChannelConsentStatus { Unknown = 0, Invited = 1, Granted = 2, Denied = 3, Withdrawn = 4, Expired = 5 }

public enum OutreachResult { Pending = 0, Sent = 1, Delivered = 2, Replied = 3, Failed = 4, BlockedByGuard = 5 }

/// <summary>
/// یک تلاشِ ارتباط با مخاطبِ دارای اکانت. قاعدهٔ سخت‌گیرانه (آبروی شرکت):
/// ارسال فقط وقتی مجاز است که رضایتِ همین کانال Granted باشد و مخاطب Suppressed/opt-out نباشد.
/// این گیت در دامنه اجرا می‌شود تا هیچ مسیری نتواند دورش بزند.
/// </summary>
public sealed class OutreachAttempt
{
    private OutreachAttempt() { }

    private OutreachAttempt(Guid tenantId, Guid prospectId, Guid contactPointId,
        CommunicationChannel channel, OutreachMode mode, Guid agentId, string messageRef)
    {
        Id = Guid.NewGuid();
        TenantId = tenantId;
        ProspectId = prospectId;
        ContactPointId = contactPointId;
        Channel = channel;
        Mode = mode;
        AgentId = agentId;
        MessageRef = messageRef;
        Result = OutreachResult.Pending;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid ContactPointId { get; private set; }
    public CommunicationChannel Channel { get; private set; }
    public OutreachMode Mode { get; private set; }
    public Guid AgentId { get; private set; }
    public string MessageRef { get; private set; } = string.Empty;
    public OutreachResult Result { get; private set; }
    public string? BlockReason { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? SentAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    /// <summary>
    /// تنها راهِ ساختِ یک تلاش. اگر گیتِ رضایت/opt-out رد شود، تلاش با BlockedByGuard
    /// ساخته می‌شود (برای Audit) ولی هرگز ارسال نمی‌شود.
    /// </summary>
    public static OutreachAttempt Create(
        Guid tenantId, Guid prospectId, Guid contactPointId,
        CommunicationChannel channel, OutreachMode mode, Guid agentId, string messageRef,
        ChannelConsentStatus channelConsent, bool isSuppressed, bool isOnSuppressionList)
    {
        var attempt = new OutreachAttempt(tenantId, prospectId, contactPointId, channel, mode, agentId, messageRef);

        if (isSuppressed || isOnSuppressionList)
        {
            attempt.Result = OutreachResult.BlockedByGuard;
            attempt.BlockReason = "مخاطب opt-out/Suppressed است؛ ارتباط ممنوع.";
            return attempt;
        }
        if (channelConsent != ChannelConsentStatus.Granted)
        {
            attempt.Result = OutreachResult.BlockedByGuard;
            attempt.BlockReason = $"رضایتِ کانالِ {channel} برابرِ {channelConsent} است؛ فقط Granted مجاز است.";
            return attempt;
        }
        return attempt; // Pending، مجاز برای ارسال
    }

    public bool IsSendable => Result == OutreachResult.Pending;

    public void MarkSent() { if (IsSendable) { Result = OutreachResult.Sent; SentAtUtc = DateTimeOffset.UtcNow; } }
    public void MarkDelivered() { if (Result == OutreachResult.Sent) Result = OutreachResult.Delivered; }
    public void MarkReplied() => Result = OutreachResult.Replied;
    public void MarkFailed(string reason) { Result = OutreachResult.Failed; BlockReason = reason; }
}
