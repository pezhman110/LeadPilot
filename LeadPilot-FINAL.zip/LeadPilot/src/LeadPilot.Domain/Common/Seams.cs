namespace LeadPilot.Domain.Common;

// ── درزهای فاز بعد ──────────────────────────────────────────────
// این‌ها عمداً از همین فاز اول در دامنه هستند تا Compliance و Consent
// «شهروند درجه‌یک» باشند، نه فیچری که بعداً پیچ شود. موتورهای کاملشان
// (ComplianceGateway، ConsentStateMachine، EnrichmentGateway) در فاز ۲/۳
// اضافه می‌شوند، اما مفهوم از ابتدا در مدل حضور دارد.

/// <summary>وضعیت Compliance یک سیگنال/مخاطب (درز فاز ۲).</summary>
public enum ComplianceStatus
{
    Safe = 0,
    NeedsReview = 1,
    Blocked = 2
}

/// <summary>ماشین وضعیت رضایت (درز فاز ۲) — تفکیک «تلفن پیدا شد» از «تماس مجاز».</summary>
public enum ConsentStatus
{
    Unknown = 0,
    SignalOnly = 1,
    ContactFound = 2,
    ContactUseAllowed = 3,
    ConsentRequested = 4,
    OptedIn = 5,
    Declined = 6,
    NoResponse = 7,
    OptedOut = 8,
    Expired = 9,
    Blocked = 10
}

/// <summary>انواع منبع مجاز (درز فاز ۲). منابع خصوصی/دایرکتوری عمداً نیستند.</summary>
public enum SourceType
{
    Unknown = 0,
    PublicApi = 1,
    LeadForm = 2,
    Event = 3,
    PartnerFeed = 4,
    OptIn = 5,
    DemoTest = 99
}
