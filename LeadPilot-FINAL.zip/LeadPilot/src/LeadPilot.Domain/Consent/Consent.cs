using LeadPilot.Domain.Common;

namespace LeadPilot.Domain.Consent;

/// <summary>
/// نقطهٔ تماس (تلفن/ایمیل). تا رضایت نیامده Hidden است و قابل استفاده نیست.
/// بدون Provider و LawfulBasis ساخته نمی‌شود (invariant دامنه).
/// </summary>
public sealed class ProtectedContactPoint
{
    private ProtectedContactPoint() { }

    public ProtectedContactPoint(Guid prospectId, ContactChannel channel, string encryptedValue,
        string provider, string lawfulBasis, string countryScope,
        Guid? tenantId = null, Guid? projectId = null)
    {
        if (string.IsNullOrWhiteSpace(provider))
            throw new ArgumentException("ProtectedContactPoint بدون Provider ساخته نمی‌شود.");
        if (string.IsNullOrWhiteSpace(lawfulBasis))
            throw new ArgumentException("ProtectedContactPoint بدون LawfulBasis ساخته نمی‌شود.");

        Id = Guid.NewGuid();
        ProspectId = prospectId;
        TenantId = tenantId ?? Guid.Empty;
        ProjectId = projectId;
        Channel = channel;
        EncryptedValue = encryptedValue;
        Provider = provider;
        LawfulBasis = lawfulBasis;
        CountryScope = countryScope;
        Visibility = ContactVisibility.Hidden; // تا رضایت، مخفی
        RetrievedAtUtc = DateTimeOffset.UtcNow;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProspectId { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid? ProjectId { get; private set; }
    public ContactChannel Channel { get; private set; }
    public string EncryptedValue { get; private set; } = string.Empty;
    public string Provider { get; private set; } = string.Empty;
    public string LawfulBasis { get; private set; } = string.Empty;
    public string CountryScope { get; private set; } = string.Empty;
    public ContactVisibility Visibility { get; private set; }
    public DateTimeOffset RetrievedAtUtc { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    /// <summary>اختیارِ جلوگیریِ مدیر. اگر true، آزادسازیِ خودکار انجام نمی‌شود.</summary>
    public bool ManagerBlocked { get; private set; }
    public string? ManagerBlockReason { get; private set; }

    /// <summary>
    /// پس از رضایتِ مشتری: آزادسازیِ خودکار (Hidden → Usable).
    /// مدیر همیشه شماره را می‌بیند؛ این فقط برای فروشنده/کارشناس/AI بازش می‌کند.
    /// اگر مدیر جلوگیری کرده باشد (ManagerBlocked)، آزاد نمی‌شود.
    /// </summary>
    public void MakeUsableAfterConsent()
    {
        if (ManagerBlocked) return; // اختیارِ جلوگیریِ مدیر مقدم است
        if (Visibility == ContactVisibility.Hidden) Visibility = ContactVisibility.Usable;
    }

    /// <summary>اختیارِ جلوگیریِ مدیر: حتی بعد از رضایت، نگه‌داشتن/بستنِ دستی.</summary>
    public void ManagerBlock(string reason)
    {
        ManagerBlocked = true;
        ManagerBlockReason = reason;
        if (Visibility == ContactVisibility.Usable) Visibility = ContactVisibility.Hidden;
    }

    /// <summary>رفعِ جلوگیریِ مدیر (اگر رضایت هست، دوباره Usable می‌شود).</summary>
    public void ManagerUnblock()
    {
        ManagerBlocked = false;
        ManagerBlockReason = null;
    }

    /// <summary>رد/انصراف: برای همیشه Suppressed.</summary>
    public void Suppress() => Visibility = ContactVisibility.Suppressed;
}

public enum ContactChannel { Phone = 0, Email = 1, WhatsApp = 2, Telegram = 3 }
public enum ContactVisibility { Hidden = 0, Usable = 1, Suppressed = 2 }

/// <summary>
/// مسیرِ «دعوت و انتخاب» (opt-in) — تأییدشده توسط مشاور حقوقی (آقای لطفی).
/// اولین ارتباط یک دعوت است، نه تماس فروش. سه حاصل: رضایت / بی‌جواب / رد.
/// </summary>
public sealed class InvitationJourney
{
    private InvitationJourney() { }

    public InvitationJourney(Guid prospectId, int score, string channel)
    {
        Id = Guid.NewGuid();
        ProspectId = prospectId;
        Score = score;
        Channel = channel;
        State = InvitationStatus.Invited;   // دعوت ارسال شد
        FollowUpCount = 0;
        UpdatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProspectId { get; private set; }
    public int Score { get; private set; }
    public string Channel { get; private set; } = string.Empty;
    public InvitationStatus State { get; private set; }
    public int FollowUpCount { get; private set; }
    public int MaxFollowUps { get; private set; } = 2;
    public ProspectRoute? Route { get; private set; }
    public DateTimeOffset UpdatedAtUtc { get; private set; }

    /// <summary>مشتری رد کرد → Suppress.</summary>
    public void Declined() { State = InvitationStatus.Declined; Touch(); }

    /// <summary>بی‌جواب → پیگیریِ مجاز تا سقف، سپس توقف.</summary>
    public void NoResponse()
    {
        if (FollowUpCount >= MaxFollowUps) { State = InvitationStatus.Exhausted; }
        else { FollowUpCount++; State = InvitationStatus.NoResponse; }
        Touch();
    }

    /// <summary>
    /// رضایت داد → وارد فروش. مسیریابیِ نمره:
    ///   نمرهٔ بالا (≥ آستانهٔ فروش) → کارشناس انسانی
    ///   نمرهٔ پایین‌تر → هوش مصنوعی (تلفنی/آنلاین) + تبلیغات ارزان به گران
    /// </summary>
    public ProspectRoute Consented(int salesThreshold)
    {
        State = InvitationStatus.Consented;
        Route = Score >= salesThreshold ? ProspectRoute.HumanExpert : ProspectRoute.AiNurture;
        Touch();
        return Route.Value;
    }

    private void Touch() => UpdatedAtUtc = DateTimeOffset.UtcNow;
}

public enum InvitationStatus
{
    Invited = 0,      // دعوت opt-in ارسال شد
    Consented = 1,    // رضایت داد
    NoResponse = 2,   // بی‌جواب (در حلقهٔ پیگیری)
    Declined = 3,     // رد کرد
    Exhausted = 4     // سقف پیگیری پر شد؛ توقف
}

public enum ProspectRoute
{
    HumanExpert = 0,  // نمرهٔ بالا → کارشناس فروش انسانی
    AiNurture = 1     // نمرهٔ پایین‌تر → AI + تبلیغات ارزان به گران
}
