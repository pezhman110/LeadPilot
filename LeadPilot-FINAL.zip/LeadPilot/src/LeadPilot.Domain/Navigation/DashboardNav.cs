namespace LeadPilot.Domain.Navigation;

/// <summary>نقشِ بیننده — منو بر اساسِ آن فیلتر می‌شود تا صفحه شلوغ نشود.</summary>
public enum DashboardRole { Seller = 0, Manager = 1, Admin = 2 }

/// <summary>
/// مرحلهٔ مسیرِ فرآیند/خرید (Spine). ترتیبِ منطقیِ سفرِ سرنخ؛ همین ترتیب در داشبورد نمایش داده می‌شود
/// تا کاربر «مسیر» را ببیند، نه انبوهی دکمهٔ بی‌ترتیب.
/// </summary>
public enum ProcessStage
{
    Discovery = 1,        // کشف تقاضا/منبع/سیگنال/فرصت
    CaptureConsent = 2,   // Lead Magnet/فرم/رضایت/ورود CSV
    Governance = 3,       // قرنطینه/تأیید Provider/گاردِ داده/enrichment
    Assignment = 4,       // تخصیص به فروشنده/اهداف
    Communication = 5,    // صندوق یکپارچه/کانال‌ها/مسیریابی/اتوماسیون
    Conversion = 6,       // نتیجه/تبدیل/CRM
    ReportsCompliance = 7,// گزارش/ممیزی/Suppression/نگهداری‌وحذف
    Settings = 99         // اتصالات/قالب‌ها/نقش‌ها/بازبینی Vendor — تُنُک، پشتِ صفحه
}

/// <summary>یک آیتمِ منو. IsPrimary=false یعنی کم‌اهمیت → داخلِ گروه/تنظیمات، نه جلوی صفحه.</summary>
public sealed class NavItem
{
    public NavItem(string key, string titleFa, string titleEn, ProcessStage stage,
        DashboardRole minRole, bool isPrimary, string icon)
    {
        Key = key;
        TitleFa = titleFa;
        TitleEn = titleEn;
        Stage = stage;
        MinRole = minRole;
        IsPrimary = isPrimary;
        Icon = icon;
    }

    public string Key { get; }
    public string TitleFa { get; }
    public string TitleEn { get; }
    public ProcessStage Stage { get; }
    /// <summary>حداقل نقشِ لازم برای دیدنِ این آیتم (Seller می‌بیند اگر MinRole=Seller).</summary>
    public DashboardRole MinRole { get; }
    public bool IsPrimary { get; }
    public string Icon { get; }

    public bool VisibleTo(DashboardRole role) => role >= MinRole;
}

/// <summary>هزینهٔ حدودیِ هر مرحله (سند: قیمت‌ها تضمینی نیستند و باید از پیشنهادِ رسمی گرفته شوند).</summary>
public sealed class StageCostEstimate
{
    public StageCostEstimate(ProcessStage stage, string driver, decimal monthlyLowUsd, decimal monthlyHighUsd, string unit)
    {
        Stage = stage;
        Driver = driver;
        MonthlyLowUsd = monthlyLowUsd;
        MonthlyHighUsd = monthlyHighUsd;
        Unit = unit;
    }

    public ProcessStage Stage { get; }
    public string Driver { get; }
    public decimal MonthlyLowUsd { get; }
    public decimal MonthlyHighUsd { get; }
    public string Unit { get; }
    /// <summary>همیشه true — تخمینی، نیازمندِ پیشنهادِ رسمیِ روز.</summary>
    public bool IsIndicativeOnly => true;
}
