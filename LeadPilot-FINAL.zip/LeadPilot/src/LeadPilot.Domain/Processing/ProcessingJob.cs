namespace LeadPilot.Domain.Processing;

public enum ProcessingJobStatus
{
    Pending = 1,
    Processing = 2,
    Completed = 3,
    RetryScheduled = 4,
    DeadLetter = 5,
    Cancelled = 6,
    Frozen = 7
}

public enum ProcessingJobPriority
{
    Low = 1,
    Normal = 2,
    High = 3,
    Critical = 4
}

/// <summary>
/// Jobِ پایدار در دیتابیس (مطابق سند). با Lease، بازیابیِ Jobِ رهاشده،
/// Retry فزاینده، Idempotency و Dead Letter. برای Postgres (RowVersion=uint/xmin).
/// نکته: Payload فقط شناسهٔ پرونده‌هاست، نه شماره/ایمیل خام.
/// </summary>
public sealed class ProcessingJob
{
    private ProcessingJob() { }

    public ProcessingJob(
        string jobType, string payload, string idempotencyKey, string correlationId,
        ProcessingJobPriority priority, int maximumAttempts, DateTimeOffset scheduledAtUtc,
        Guid? projectId = null, Guid? prospectId = null)
    {
        if (string.IsNullOrWhiteSpace(jobType)) throw new ArgumentException("نوع Job الزامی است.");
        if (string.IsNullOrWhiteSpace(payload)) throw new ArgumentException("Payload الزامی است.");
        if (string.IsNullOrWhiteSpace(idempotencyKey)) throw new ArgumentException("کلید Idempotency الزامی است.");
        if (string.IsNullOrWhiteSpace(correlationId)) throw new ArgumentException("CorrelationId الزامی است.");
        if (maximumAttempts is < 1 or > 20) throw new ArgumentOutOfRangeException(nameof(maximumAttempts));

        Id = Guid.NewGuid();
        JobType = jobType.Trim().ToUpperInvariant();
        Payload = payload;
        IdempotencyKey = idempotencyKey.Trim().ToUpperInvariant();
        CorrelationId = correlationId.Trim();
        Priority = priority;
        MaximumAttempts = maximumAttempts;
        ScheduledAtUtc = scheduledAtUtc;
        ProjectId = projectId;
        ProspectId = prospectId;
        Status = ProcessingJobStatus.Pending;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public string JobType { get; private set; } = string.Empty;
    public string Payload { get; private set; } = string.Empty;
    public string IdempotencyKey { get; private set; } = string.Empty;
    public string CorrelationId { get; private set; } = string.Empty;
    public Guid? ProjectId { get; private set; }
    public Guid? ProspectId { get; private set; }
    public ProcessingJobStatus Status { get; private set; }
    public ProcessingJobPriority Priority { get; private set; }
    public int AttemptCount { get; private set; }
    public int MaximumAttempts { get; private set; }
    public DateTimeOffset ScheduledAtUtc { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public DateTimeOffset? StartedAtUtc { get; private set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }
    public string? LockedBy { get; private set; }
    public DateTimeOffset? LockedUntilUtc { get; private set; }
    public string? LastErrorCode { get; private set; }
    public string? LastError { get; private set; }
    public uint RowVersion { get; private set; } // Postgres xmin

    public bool CanBeClaimedAt(DateTimeOffset nowUtc)
    {
        bool waiting = Status is ProcessingJobStatus.Pending or ProcessingJobStatus.RetryScheduled;
        bool abandoned = Status == ProcessingJobStatus.Processing
            && LockedUntilUtc.HasValue && LockedUntilUtc.Value <= nowUtc;
        return (waiting && ScheduledAtUtc <= nowUtc) || abandoned;
    }

    public void Claim(string workerId, DateTimeOffset nowUtc, TimeSpan leaseDuration)
    {
        if (string.IsNullOrWhiteSpace(workerId)) throw new ArgumentException("شناسه Worker الزامی است.");
        if (leaseDuration <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(leaseDuration));
        if (!CanBeClaimedAt(nowUtc)) throw new InvalidOperationException("Job در حال حاضر قابل برداشت نیست.");

        Status = ProcessingJobStatus.Processing;
        AttemptCount++;
        StartedAtUtc ??= nowUtc;
        LockedBy = workerId.Trim();
        LockedUntilUtc = nowUtc.Add(leaseDuration);
        LastErrorCode = null; LastError = null;
    }

    public void RenewLease(string workerId, DateTimeOffset nowUtc, TimeSpan leaseDuration)
    {
        EnsureOwnedBy(workerId);
        if (Status != ProcessingJobStatus.Processing) throw new InvalidOperationException("فقط Job در حال پردازش قابل تمدید است.");
        LockedUntilUtc = nowUtc.Add(leaseDuration);
    }

    public void Complete(string workerId, DateTimeOffset completedAtUtc)
    {
        EnsureOwnedBy(workerId);
        if (Status != ProcessingJobStatus.Processing) throw new InvalidOperationException("فقط Job در حال پردازش قابل تکمیل است.");
        Status = ProcessingJobStatus.Completed;
        CompletedAtUtc = completedAtUtc;
        LockedBy = null; LockedUntilUtc = null; LastErrorCode = null; LastError = null;
    }

    public void Fail(string workerId, string errorCode, string error, DateTimeOffset nowUtc, DateTimeOffset nextAttemptAtUtc)
    {
        EnsureOwnedBy(workerId);
        LastErrorCode = NormalizeError(errorCode, 200);
        LastError = NormalizeError(error, 4000);
        LockedBy = null; LockedUntilUtc = null;
        if (AttemptCount >= MaximumAttempts)
        {
            Status = ProcessingJobStatus.DeadLetter;
            CompletedAtUtc = nowUtc;
            return;
        }
        Status = ProcessingJobStatus.RetryScheduled;
        ScheduledAtUtc = nextAttemptAtUtc;
    }

    public void SendToDeadLetter(string workerId, string errorCode, string error, DateTimeOffset nowUtc)
    {
        EnsureOwnedBy(workerId);
        Status = ProcessingJobStatus.DeadLetter;
        LastErrorCode = NormalizeError(errorCode, 200);
        LastError = NormalizeError(error, 4000);
        CompletedAtUtc = nowUtc; LockedBy = null; LockedUntilUtc = null;
    }

    public void RetryDeadLetter(DateTimeOffset scheduledAtUtc)
    {
        if (Status != ProcessingJobStatus.DeadLetter) throw new InvalidOperationException("فقط Dead Letter قابل Retry است.");
        Status = ProcessingJobStatus.RetryScheduled;
        ScheduledAtUtc = scheduledAtUtc;
        CompletedAtUtc = null; AttemptCount = 0; LastErrorCode = null; LastError = null;
    }

    public void Cancel()
    {
        if (Status == ProcessingJobStatus.Completed) throw new InvalidOperationException("Job تکمیل‌شده قابل لغو نیست.");
        Status = ProcessingJobStatus.Cancelled; LockedBy = null; LockedUntilUtc = null;
    }

    public void Freeze()
    {
        if (Status is ProcessingJobStatus.Completed or ProcessingJobStatus.Cancelled)
            throw new InvalidOperationException("این Job قابل توقف نیست.");
        Status = ProcessingJobStatus.Frozen; LockedBy = null; LockedUntilUtc = null;
    }

    public void Unfreeze(DateTimeOffset scheduledAtUtc)
    {
        if (Status != ProcessingJobStatus.Frozen) throw new InvalidOperationException("فقط Job متوقف‌شده قابل آزادسازی است.");
        Status = ProcessingJobStatus.RetryScheduled;
        ScheduledAtUtc = scheduledAtUtc;
    }

    private void EnsureOwnedBy(string workerId)
    {
        if (!string.Equals(LockedBy, workerId, StringComparison.Ordinal))
            throw new InvalidOperationException("Worker مالک این Job نیست.");
    }

    private static string NormalizeError(string? value, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value)) return "UNKNOWN";
        var result = value.Trim();
        return result.Length <= maximumLength ? result : result[..maximumLength];
    }
}

public static class ProcessingJobTypes
{
    public const string Search = "SEARCH";
    public const string SignalAnalysis = "SIGNAL_ANALYSIS";
    public const string ProspectScoring = "PROSPECT_SCORING";
    public const string ContactDiscovery = "CONTACT_DISCOVERY";
    public const string ConsentInvitation = "CONSENT_INVITATION";
    public const string ConsentResponse = "CONSENT_RESPONSE";
    public const string ProspectRouting = "PROSPECT_ROUTING";
    public const string MobileContactSync = "MOBILE_CONTACT_SYNC";
    public const string MobileContactRemoval = "MOBILE_CONTACT_REMOVAL";
    public const string AiTextWarming = "AI_TEXT_WARMING";
    public const string VoiceCall = "VOICE_CALL";
    public const string CampaignEnrollment = "CAMPAIGN_ENROLLMENT";
    public const string MeetingScheduling = "MEETING_SCHEDULING";
}
