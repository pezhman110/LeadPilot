namespace LeadPilot.Domain.Partners;

/// <summary>
/// طبقه‌بندیِ مبلغ برای تخصیص به همکار — دقیقاً بر اساس بازه‌های اعلامیِ پژمان.
/// </summary>
public enum DealTier
{
    Unknown = 0,
    InvestmentLow = 1,     // سرمایه‌گذاری ۵۰k – ۵۰۰k
    InvestmentMid = 2,     // سرمایه‌گذاری ۵۰۰k – ۵M
    InvestmentHigh = 3,    // سرمایه‌گذاری ۵M – ۱۰۰M
    Purchase = 4,          // خرید ۲۰۰k – ۷۵۰M (پروژه داریم)
    BusinessSale = 5,      // فروش بیزینس — هر مبلغ (تعهد فروش در ۳ ماه)
    OtherService = 6       // بقیه — بر اساس جدول/تعرفه
}

public enum DealKind { Investment = 0, Purchase = 1, BusinessSale = 2, OtherService = 3 }

public static class DealClassifier
{
    /// <summary>مبلغ (AED) + نوع معامله → طبقه.</summary>
    public static DealTier Classify(DealKind kind, decimal amountAed) => kind switch
    {
        DealKind.Investment when amountAed is >= 50_000m and < 500_000m => DealTier.InvestmentLow,
        DealKind.Investment when amountAed is >= 500_000m and < 5_000_000m => DealTier.InvestmentMid,
        DealKind.Investment when amountAed is >= 5_000_000m and <= 100_000_000m => DealTier.InvestmentHigh,
        DealKind.Investment => DealTier.Unknown, // خارج از بازهٔ ۵۰k–۱۰۰M

        DealKind.Purchase when amountAed is >= 200_000m and <= 750_000_000m => DealTier.Purchase,
        DealKind.Purchase => DealTier.Unknown,

        DealKind.BusinessSale => DealTier.BusinessSale, // هر مبلغ به بالا
        _ => DealTier.OtherService
    };

    /// <summary>فروش بیزینس تعهد ۳ ماهه دارد.</summary>
    public static bool HasThreeMonthCommitment(DealTier tier) => tier == DealTier.BusinessSale;
}

/// <summary>
/// زبان‌های کاورشده (موتور + کارشناس): لوکال، عربی، فارسی، انگلیسی، ترکی، فرانسوی، هندی.
/// بقیه فقط هوش مصنوعی، و پیام به زبانِ خودِ مشتری.
/// </summary>
public static class LanguageCoverage
{
    // «لوکال» = عربیِ محلی خلیج؛ اینجا کدِ زبان‌های کاورشده.
    public static readonly string[] Covered = ["ar", "fa", "en", "tr", "fr", "hi", "local"];

    public static bool IsCovered(string code) =>
        Covered.Contains(code.Trim().ToLowerInvariant());

    /// <summary>اگر زبان کاور نشده باشد، مسیرِ ارتباط فقط AI است.</summary>
    public static ContactMode ModeFor(string languageCode) =>
        IsCovered(languageCode) ? ContactMode.ExpertOrAi : ContactMode.AiOnly;
}

public enum ContactMode { ExpertOrAi = 0, AiOnly = 1 }
