namespace LeadPilot.Domain.Partners;

/// <summary>
/// همکار/فروشنده. توانمندی + نمرهٔ عملکردِ قبلی وارد می‌شود؛ سیستم بر اساس آن
/// و طبقهٔ مبلغِ لید، تخصیص پیشنهاد می‌دهد.
/// </summary>
public sealed class Partner
{
    private readonly List<string> _languages = [];
    private readonly List<string> _skills = [];

    private Partner() { }

    public Partner(string fullName, PartnerType type, int performanceScore)
    {
        if (string.IsNullOrWhiteSpace(fullName))
            throw new ArgumentException("نام همکار الزامی است.");
        if (performanceScore is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(performanceScore), "نمره باید بین ۰ تا ۱۰۰ باشد.");

        Id = Guid.NewGuid();
        FullName = fullName.Trim();
        Type = type;
        PerformanceScore = performanceScore;
        IsActive = true;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public string FullName { get; private set; } = string.Empty;
    public PartnerType Type { get; private set; }
    /// <summary>نمرهٔ عملکردِ قبلی (۰..۱۰۰) که مدیر وارد می‌کند.</summary>
    public int PerformanceScore { get; private set; }
    public bool IsActive { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public IReadOnlyCollection<string> Languages => _languages;
    public IReadOnlyCollection<string> Skills => _skills;

    // ستون‌های EF (CSV). دامنه از لیست‌ها استفاده می‌کند؛ EF از این دو property.
    public string LanguagesCsv
    {
        get => string.Join(',', _languages);
        private set { _languages.Clear(); if (!string.IsNullOrEmpty(value)) _languages.AddRange(value.Split(',', StringSplitOptions.RemoveEmptyEntries)); }
    }
    public string SkillsCsv
    {
        get => string.Join(',', _skills);
        private set { _skills.Clear(); if (!string.IsNullOrEmpty(value)) _skills.AddRange(value.Split(',', StringSplitOptions.RemoveEmptyEntries)); }
    }

    public void AddLanguage(string code)
    {
        var c = code.Trim().ToLowerInvariant();
        if (!_languages.Contains(c)) _languages.Add(c);
    }
    public void AddSkill(string skill)
    {
        var s = skill.Trim();
        if (!string.IsNullOrEmpty(s) && !_skills.Contains(s)) _skills.Add(s);
    }
    public void SetPerformance(int score)
    {
        if (score is < 0 or > 100) throw new ArgumentOutOfRangeException(nameof(score));
        PerformanceScore = score;
    }
    public void Deactivate() => IsActive = false;
}

public enum PartnerType { Salesperson = 0, Expert = 1, Agent = 2, Marketer = 3, Referral = 4 }

/// <summary>
/// توافق مالیِ همکار (درصد، جایزه، شرایط). «تحت نظر مدیر + قرارداد و Audit»:
/// هر توافق باید ApprovedByManager و یک ContractRef داشته باشد تا فعال شود.
/// </summary>
public sealed class PartnerAgreement
{
    private PartnerAgreement() { }

    public PartnerAgreement(Guid partnerId, decimal commissionPercent, string terms)
    {
        if (commissionPercent is < 0 or > 100)
            throw new ArgumentOutOfRangeException(nameof(commissionPercent));
        Id = Guid.NewGuid();
        PartnerId = partnerId;
        CommissionPercent = commissionPercent;
        Terms = terms;
        Status = AgreementStatus.Draft;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid PartnerId { get; private set; }
    public decimal CommissionPercent { get; private set; }
    public decimal? BonusAed { get; private set; }
    public string Terms { get; private set; } = string.Empty;
    public string? ContractRef { get; private set; }
    public bool ApprovedByManager { get; private set; }
    public string? ApprovedBy { get; private set; }
    public AgreementStatus Status { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }

    public void SetBonus(decimal aed) => BonusAed = aed >= 0 ? aed : throw new ArgumentOutOfRangeException(nameof(aed));

    /// <summary>فعال‌سازی فقط با تأیید مدیر و ارجاع قرارداد (Audit).</summary>
    public void Activate(string managerName, string contractRef)
    {
        if (string.IsNullOrWhiteSpace(managerName)) throw new ArgumentException("تأیید مدیر لازم است.");
        if (string.IsNullOrWhiteSpace(contractRef)) throw new ArgumentException("ارجاع قرارداد لازم است.");
        ApprovedByManager = true;
        ApprovedBy = managerName;
        ContractRef = contractRef;
        Status = AgreementStatus.Active;
    }
}

public enum AgreementStatus { Draft = 0, Active = 1, Suspended = 2 }
