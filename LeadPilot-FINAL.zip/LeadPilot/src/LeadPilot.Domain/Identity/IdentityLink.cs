namespace LeadPilot.Domain.Identity;

/// <summary>امتیازِ اطمینانِ اتصالِ دو حساب به یک نفر (سند).</summary>
public enum IdentityConfidence
{
    Rejected = 0,      // فقط شباهت عکس/نام یا حدسِ سیستم → رد
    NeedsReview = 1,   // شباهت نام/برند/لینک عمومی → نیازمند تأیید
    HighConfidence = 2,// اطلاعاتِ یکسانی که مشتری در دو کانال اعلام کرده
    Verified = 3       // تأییدِ مستقیمِ مشتری یا OAuth
}

/// <summary>نوعِ شواهدِ اتصال.</summary>
public enum IdentityEvidence
{
    PhotoOrNameSimilarity = 0, // ضعیف‌ترین → همیشه Rejected
    PublicLinkSimilarity = 1,
    SelfDeclaredInForm = 2,
    SelfProvidedInConversation = 3,
    CrmVerifiedOrigin = 4,
    OAuthOrOfficialLogin = 5,
    AgentConfirmed = 6
}

/// <summary>
/// اتصالِ یک حسابِ سوشیال به پروفایلِ یکپارچهٔ مشتری. قاعدهٔ سخت:
/// هرگز صرفاً به‌خاطرِ شباهتِ نام/عکس دو حساب یکی فرض نمی‌شوند. اتصالِ نهاییِ کم‌اطمینان
/// نیازمندِ تأییدِ کارشناس/مدیر است.
/// </summary>
public sealed class IdentityLink
{
    private IdentityLink() { }

    public IdentityLink(Guid tenantId, Guid unifiedProfileId, string channel, string accountHandle,
        IdentityEvidence evidence)
    {
        if (string.IsNullOrWhiteSpace(channel)) throw new ArgumentException("کانال الزامی است.");
        if (string.IsNullOrWhiteSpace(accountHandle)) throw new ArgumentException("شناسهٔ حساب الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        UnifiedProfileId = unifiedProfileId;
        Channel = channel.Trim();
        AccountHandle = accountHandle.Trim();
        Evidence = evidence;
        Confidence = ScoreFrom(evidence);
        IsConfirmed = Confidence == IdentityConfidence.Verified;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public Guid UnifiedProfileId { get; private set; }
    public string Channel { get; private set; } = string.Empty;
    public string AccountHandle { get; private set; } = string.Empty;
    public IdentityEvidence Evidence { get; private set; }
    public IdentityConfidence Confidence { get; private set; }
    public bool IsConfirmed { get; private set; }
    public string? ConfirmedBy { get; private set; }
    public DateTimeOffset CreatedAtUtc { get; private set; }
    public uint RowVersion { get; private set; }

    /// <summary>نگاشتِ شواهد به اطمینان. شباهتِ عکس/نام همیشه Rejected.</summary>
    public static IdentityConfidence ScoreFrom(IdentityEvidence evidence) => evidence switch
    {
        IdentityEvidence.OAuthOrOfficialLogin => IdentityConfidence.Verified,
        IdentityEvidence.SelfProvidedInConversation => IdentityConfidence.Verified,
        IdentityEvidence.SelfDeclaredInForm => IdentityConfidence.HighConfidence,
        IdentityEvidence.CrmVerifiedOrigin => IdentityConfidence.HighConfidence,
        IdentityEvidence.AgentConfirmed => IdentityConfidence.HighConfidence,
        IdentityEvidence.PublicLinkSimilarity => IdentityConfidence.NeedsReview,
        _ => IdentityConfidence.Rejected // PhotoOrNameSimilarity
    };

    /// <summary>ادغام فقط وقتی معتبر است که Verified باشد یا کارشناس/مدیر تأیید کند.</summary>
    public bool IsUsableForMerge => IsConfirmed || Confidence == IdentityConfidence.Verified;

    public void Confirm(string actorId)
    {
        if (Confidence == IdentityConfidence.Rejected)
            throw new InvalidOperationException("اتصالِ مبتنی بر شباهتِ عکس/نام قابلِ تأیید نیست.");
        IsConfirmed = true;
        ConfirmedBy = actorId;
    }
}
