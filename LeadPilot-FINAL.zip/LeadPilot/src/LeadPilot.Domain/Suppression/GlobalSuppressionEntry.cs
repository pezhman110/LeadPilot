namespace LeadPilot.Domain.Suppression;

/// <summary>دامنهٔ لغو رضایت: فقط همان کانال، یا کلِ بازاریابی.</summary>
public enum SuppressionScope { ChannelOnly = 0, AllMarketing = 1 }

/// <summary>
/// فهرستِ توقفِ سراسری. اولویت بر همهٔ Connectorها (سند). اگر مخاطب در هر کانال/CRM
/// درخواستِ توقف داد، پیش از هر ارسالِ بعدی در همهٔ کانال‌های مرتبط بررسی می‌شود.
/// کلید = هشِ هویت/تماس (normalize‌شده) تا در همهٔ کانال‌ها یکسان تطبیق بخورد.
/// </summary>
public sealed class GlobalSuppressionEntry
{
    private GlobalSuppressionEntry() { }

    public GlobalSuppressionEntry(Guid tenantId, string identityHash, SuppressionScope scope,
        string? channel, string reason, string source)
    {
        if (string.IsNullOrWhiteSpace(identityHash)) throw new ArgumentException("کلید هویت الزامی است.");
        if (scope == SuppressionScope.ChannelOnly && string.IsNullOrWhiteSpace(channel))
            throw new ArgumentException("برای دامنهٔ ChannelOnly، کانال الزامی است.");
        Id = Guid.NewGuid();
        TenantId = tenantId;
        IdentityHash = identityHash;
        Scope = scope;
        Channel = channel;
        Reason = reason;
        Source = source;
        CreatedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid TenantId { get; private set; }
    public string IdentityHash { get; private set; } = string.Empty;
    public SuppressionScope Scope { get; private set; }
    public string? Channel { get; private set; }
    public string Reason { get; private set; } = string.Empty;
    public string Source { get; private set; } = string.Empty;
    public DateTimeOffset CreatedAtUtc { get; private set; }

    /// <summary>آیا این ورودی ارسال روی کانالِ داده‌شده را می‌بندد؟</summary>
    public bool Blocks(string targetChannel) =>
        Scope == SuppressionScope.AllMarketing ||
        (Scope == SuppressionScope.ChannelOnly &&
         string.Equals(Channel, targetChannel, StringComparison.OrdinalIgnoreCase));
}
