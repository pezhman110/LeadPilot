using LeadPilot.Domain.Common;

namespace LeadPilot.Domain.Signals;

/// <summary>یک اجرای جست‌وجو روی یک پروژه. قابل توقف و ادامه.</summary>
public sealed class SearchRun
{
    private SearchRun() { }

    public SearchRun(Guid projectId)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        Status = SearchRunStatus.Running;
        StartedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public SearchRunStatus Status { get; private set; }
    public int QueriesExecuted { get; private set; }
    public int RawFound { get; private set; }
    public int Blocked { get; private set; }
    public int Processed { get; private set; }
    public int Duplicates { get; private set; }
    public DateTimeOffset StartedAtUtc { get; private set; }
    public DateTimeOffset? CompletedAtUtc { get; private set; }

    public void CountQuery() => QueriesExecuted++;
    public void CountFound() => RawFound++;
    public void CountBlocked() => Blocked++;
    public void CountProcessed() => Processed++;
    public void CountDuplicate() => Duplicates++;

    public void Pause() { if (Status == SearchRunStatus.Running) Status = SearchRunStatus.Paused; }
    public void Resume() { if (Status == SearchRunStatus.Paused) Status = SearchRunStatus.Running; }
    public void Complete() { Status = SearchRunStatus.Completed; CompletedAtUtc = DateTimeOffset.UtcNow; }
    public void Fail() { Status = SearchRunStatus.Failed; CompletedAtUtc = DateTimeOffset.UtcNow; }
}

public enum SearchRunStatus { Running = 0, Paused = 1, Completed = 2, Failed = 3 }

/// <summary>
/// سیگنال خام از یک منبع. URL منبع، Query، زمان و منبع اجباری‌اند (داده ساختگی ممنوع).
/// </summary>
public sealed class RawSignal
{
    private RawSignal() { }

    public RawSignal(Guid projectId, Guid searchRunId, string provider, string sourceUrl,
        SourceType sourceType, string queryUsed, string originalText, bool isDemo)
    {
        Id = Guid.NewGuid();
        ProjectId = projectId;
        SearchRunId = searchRunId;
        Provider = provider;
        SourceUrl = sourceUrl;
        SourceType = sourceType;
        QueryUsed = queryUsed;
        OriginalText = originalText;
        IsDemo = isDemo;
        CollectedAtUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid ProjectId { get; private set; }
    public Guid SearchRunId { get; private set; }
    public string Provider { get; private set; } = string.Empty;
    public string SourceUrl { get; private set; } = string.Empty;
    public SourceType SourceType { get; private set; }
    public string QueryUsed { get; private set; } = string.Empty;
    public string OriginalText { get; private set; } = string.Empty;
    public DetectedLanguage Language { get; set; } = DetectedLanguage.Unknown;
    public bool IsDemo { get; private set; }
    public DateTimeOffset CollectedAtUtc { get; private set; }

    /// <summary>کلید یکتاسازی برای جلوگیری از نتیجهٔ تکراری در یک اجرا.</summary>
    public string DedupeKey() => $"{SourceUrl}|{OriginalText.Trim().ToLowerInvariant()}";
}

/// <summary>سیگنالِ نرمال‌شده و امتیازدار (پس از عبور از Compliance Gateway).</summary>
public sealed class NormalizedSignal
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid RawSignalId { get; set; }
    public Guid ProjectId { get; set; }
    public Guid SearchRunId { get; set; }

    public string SourceUrl { get; set; } = string.Empty;
    public SourceType SourceType { get; set; }
    public string QueryUsed { get; set; } = string.Empty;
    public string OriginalText { get; set; } = string.Empty;
    public string TranslatedSummaryFa { get; set; } = string.Empty;
    public DetectedLanguage Language { get; set; }

    public ComplianceStatus ComplianceStatus { get; set; } = ComplianceStatus.NeedsReview;
    public string ComplianceReason { get; set; } = string.Empty;

    public int IntentScore { get; set; }
    public int FitScore { get; set; }
    public int ComplianceScore { get; set; }
    public int FinalScore { get; set; }

    public List<SignalEvidence> Evidence { get; set; } = [];
    public List<string> ReasonForScore { get; set; } = [];

    public bool IsDemo { get; set; }
    public DateTimeOffset ProcessedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class SignalEvidence
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Kind { get; set; } = string.Empty;
    public string Matched { get; set; } = string.Empty;
}

/// <summary>زبان تشخیص‌داده‌شده.</summary>
public enum DetectedLanguage { Unknown = 0, English = 1, Arabic = 2, Persian = 3, Hindi = 4, French = 5, Russian = 6 }
