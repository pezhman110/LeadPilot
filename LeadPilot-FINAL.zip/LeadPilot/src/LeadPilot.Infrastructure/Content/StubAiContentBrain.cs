using LeadPilot.Application.Content;

namespace LeadPilot.Infrastructure.Content;

/// <summary>
/// پیاده‌سازیِ موقتِ مغزِ محتوا. ساختارِ خروجی درست است تا ماژول اجرا شود.
/// نسخهٔ واقعی به یک LLM (با ۴ ورودیِ سند) وصل می‌شود؛ اینجا خروجیِ نمونه می‌دهد.
/// تولیدِ فایلِ نهاییِ ویدیو/صوت/تصویر کارِ موتورهای بیرونی است، نه این ماژول.
/// </summary>
public sealed class StubAiContentBrain : IAiContentBrain
{
    public Task<GeneratedContent> GenerateAsync(ContentGenerationInput i, CancellationToken ct)
    {
        var scenes = new List<VideoScene>
        {
            new(1, $"نمای باز: {i.AudienceGroup} در فضای دبی", $"شروع با نیازِ گروه دربارهٔ «{i.Heading}»", 5),
            new(2, "نمای محصول/خدمت", "معرفی راه‌حل و ارزش پیشنهادی", 8),
            new(3, "فراخوان به اقدام", "دعوت به ثبت‌نام در صفحهٔ فرود (opt-in)", 5)
        };
        var result = new GeneratedContent(
            AdCopy: $"[{i.Language}] آگهی برای «{i.Heading}» — گروه {i.AudienceGroup} (بر پایهٔ مدل قبلی + ترند بازار).",
            BannerText: $"«{i.Heading}» — همین حالا شروع کنید",
            CarouselText: "اسلاید ۱: مشکل · اسلاید ۲: راه‌حل · اسلاید ۳: اقدام",
            VideoScript: scenes,
            PodcastScript: $"سلام. امروز دربارهٔ «{i.Heading}» برای {i.AudienceGroup} صحبت می‌کنیم…",
            MotionBrief: "سبک: سینمایی، نور طلایی/کهربایی؛ ریتم آرام؛ CTA در ثانیهٔ آخر.");
        return Task.FromResult(result);
    }
}
