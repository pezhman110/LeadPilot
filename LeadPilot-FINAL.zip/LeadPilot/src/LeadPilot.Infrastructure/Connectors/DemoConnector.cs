using System.Runtime.CompilerServices;
using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Common;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;

namespace LeadPilot.Infrastructure.Connectors;

/// <summary>
/// Connector تستی (برچسب Demo/Test در UI). هیچ scrape واقعی ندارد.
/// Connectorهای واقعی (فرم سایت، YouTube/Reddit API، Partner Feed، سپس Apollo/ایپفای
/// بر اساس قرارداد) در قدم‌های بعد اضافه می‌شوند.
/// </summary>
public sealed class DemoConnector : ISignalConnector
{
    public string Name => "Demo/Test Source";
    public SourceType SourceType => SourceType.DemoTest;
    public bool IsDemo => true;
    public TimeSpan MinRequestInterval => TimeSpan.FromMilliseconds(40);

    private static readonly (string text, SourceType src)[] Samples =
    [
        ("Looking to buy a profitable business in Dubai, I have around 1 million AED ready, prefer managed/passive income.", SourceType.PublicApi),
        ("دنبال خرید بیزینس فعال با درآمد ماهانه در دبی هستم، بودجه حدود ۵۰۰ هزار درهم.", SourceType.PublicApi),
        ("أبحث عن استثمار في دبي، لدي رأس مال ويهمني مشروع مع إدارة جاهزة.", SourceType.Event),
        ("We are a corporate VC fund. Contact us via our About Us page.", SourceType.PublicApi),
        ("NRI investor Dubai, want to buy a salon business, golden visa interest, AED 750,000.", SourceType.LeadForm),
        ("private investor looking for operating company in the UAE, half a million dirham.", SourceType.OptIn)
    ];

    public async IAsyncEnumerable<RawSignal> FetchAsync(
        Project project, SearchContext ctx, [EnumeratorCancellation] CancellationToken ct)
    {
        foreach (var (text, src) in Samples)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(40, ct);
            yield return new RawSignal(
                projectId: ctx.ProjectId,
                searchRunId: ctx.SearchRunId,
                provider: "demo",
                sourceUrl: $"https://demo.local/{Guid.NewGuid():N}",
                sourceType: src,
                queryUsed: ctx.Query,
                originalText: text,
                isDemo: true);
        }
    }
}
