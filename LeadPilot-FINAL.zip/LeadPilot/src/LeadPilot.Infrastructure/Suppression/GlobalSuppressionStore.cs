using LeadPilot.Application.Suppression;
using LeadPilot.Domain.Suppression;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Suppression;

public sealed class GlobalSuppressionStore(LeadPilotDbContext db) : IGlobalSuppressionStore
{
    public async Task<IReadOnlyList<GlobalSuppressionEntry>> GetForIdentityAsync(
        Guid tenantId, string identityHash, CancellationToken ct) =>
        await db.GlobalSuppressionEntries.AsNoTracking()
            .Where(x => x.TenantId == tenantId && x.IdentityHash == identityHash)
            .ToListAsync(ct);

    public async Task AddAsync(GlobalSuppressionEntry entry, CancellationToken ct)
    {
        db.GlobalSuppressionEntries.Add(entry);
        await db.SaveChangesAsync(ct);
    }
}
