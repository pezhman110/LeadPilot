using LeadPilot.Application.ContactAccess;
using Microsoft.Extensions.Logging;

namespace LeadPilot.Infrastructure.ContactAccess;

/// <summary>ثبتِ Auditِ مشاهدهٔ شماره توسط مدیر. نسخهٔ واقعی در جدول Audit می‌نویسد.</summary>
public sealed class ContactAccessAudit(ILogger<ContactAccessAudit> logger) : IContactAccessAudit
{
    public void AddRevealAudit(string actorId, Guid contactId, string reason) =>
        logger.LogInformation("REVEAL_AUDIT actor={Actor} contact={Contact} reason={Reason}", actorId, contactId, reason);
}
