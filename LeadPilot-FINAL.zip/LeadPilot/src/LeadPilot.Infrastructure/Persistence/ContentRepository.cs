using LeadPilot.Application.Content;
using LeadPilot.Domain.Content;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class ContentRepository(LeadPilotDbContext db) : IContentRepository
{
    public async Task AddHeadingAsync(ContentHeading h, CancellationToken ct) => await db.ContentHeadings.AddAsync(h, ct);
    public async Task<IReadOnlyList<ContentHeading>> ListHeadingsAsync(Guid p, CancellationToken ct) =>
        await db.ContentHeadings.AsNoTracking().Where(x => x.ProjectId == p).ToListAsync(ct);
    public async Task AddAssetAsync(ContentAsset a, CancellationToken ct) => await db.ContentAssets.AddAsync(a, ct);
    public async Task<IReadOnlyList<ContentAsset>> ListAssetsAsync(Guid p, CancellationToken ct) =>
        await db.ContentAssets.AsNoTracking().Where(x => x.ProjectId == p).ToListAsync(ct);
    public async Task AddLandingAsync(LandingPage p, CancellationToken ct) => await db.LandingPages.AddAsync(p, ct);
    public async Task AddCampaignAsync(Campaign c, CancellationToken ct) => await db.Campaigns.AddAsync(c, ct);
    public Task<Campaign?> GetCampaignAsync(Guid id, CancellationToken ct) => db.Campaigns.FirstOrDefaultAsync(x => x.Id == id, ct);
    public async Task AddPresentationAsync(Presentation p, CancellationToken ct) => await db.Presentations.AddAsync(p, ct);
    public Task<Presentation?> GetPresentationAsync(Guid id, CancellationToken ct) => db.Presentations.FirstOrDefaultAsync(x => x.Id == id, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
