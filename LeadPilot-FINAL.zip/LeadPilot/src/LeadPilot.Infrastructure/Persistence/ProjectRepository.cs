using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Projects;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class ProjectRepository(LeadPilotDbContext db) : IProjectRepository
{
    public Task<Project?> GetAsync(Guid id, CancellationToken ct) =>
        db.Projects
            .Include(p => p.Languages)
            .Include(p => p.Geographies)
            .FirstOrDefaultAsync(p => p.Id == id, ct);

    public async Task<IReadOnlyList<Project>> ListAsync(CancellationToken ct) =>
        await db.Projects
            .Include(p => p.Languages)
            .Include(p => p.Geographies)
            .OrderByDescending(p => p.CreatedAtUtc)
            .ToListAsync(ct);

    public async Task AddAsync(Project project, CancellationToken ct) =>
        await db.Projects.AddAsync(project, ct);

    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
