using LeadPilot.Domain.Discovery;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class AcquisitionSourceConfiguration : IEntityTypeConfiguration<AcquisitionSource>
{
    public void Configure(EntityTypeBuilder<AcquisitionSource> b)
    {
        b.ToTable("acquisition_sources");
        b.HasKey(x => x.Id);
        b.Property(x => x.Type).HasConversion<int>();
        b.Property(x => x.Name).HasMaxLength(250);
        b.Property(x => x.Industry).HasMaxLength(120);
        b.Property(x => x.Country).HasMaxLength(80);
        b.Property(x => x.City).HasMaxLength(120);
        b.Property(x => x.Language).HasMaxLength(40);
        b.Property(x => x.ToolUsed).HasMaxLength(120);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Industry, x.Country });
    }
}

public sealed class ProviderApprovalConfiguration : IEntityTypeConfiguration<ProviderApproval>
{
    public void Configure(EntityTypeBuilder<ProviderApproval> b)
    {
        b.ToTable("provider_approvals");
        b.HasKey(x => x.Id);
        b.Property(x => x.Provider).HasConversion<int>();
        b.Property(x => x.State).HasConversion<int>();
        b.Property(x => x.ReviewedBy).HasMaxLength(120);
        b.Property(x => x.Notes).HasMaxLength(2000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Provider }).IsUnique();
    }
}

public sealed class ImportRecordConfiguration : IEntityTypeConfiguration<ImportRecord>
{
    public void Configure(EntityTypeBuilder<ImportRecord> b)
    {
        b.ToTable("import_records");
        b.HasKey(x => x.Id);
        b.Property(x => x.Provider).HasConversion<int>();
        b.Property(x => x.Stage).HasConversion<int>();
        b.Property(x => x.SourceRef).HasMaxLength(400);
        b.Property(x => x.SourceUrl).HasMaxLength(1000);
        b.Property(x => x.Reason).HasMaxLength(500);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Stage });
    }
}

public sealed class IntentSignalConfiguration : IEntityTypeConfiguration<IntentSignal>
{
    public void Configure(EntityTypeBuilder<IntentSignal> b)
    {
        b.ToTable("intent_signals");
        b.HasKey(x => x.Id);
        b.Property(x => x.NextAction).HasConversion<int>();
        b.Property(x => x.SignalType).HasMaxLength(120);
        b.Property(x => x.Source).HasMaxLength(250);
        b.Property(x => x.TextReference).HasMaxLength(1000);
        b.Property(x => x.Industry).HasMaxLength(120);
        b.Property(x => x.Location).HasMaxLength(120);
        b.Property(x => x.Language).HasMaxLength(40);
        b.HasIndex(x => new { x.TenantId, x.Industry, x.ObservedAtUtc });
    }
}

public sealed class LeadMagnetConfiguration : IEntityTypeConfiguration<LeadMagnet>
{
    public void Configure(EntityTypeBuilder<LeadMagnet> b)
    {
        b.ToTable("lead_magnets");
        b.HasKey(x => x.Id);
        b.Property(x => x.Kind).HasConversion<int>();
        b.Property(x => x.Title).HasMaxLength(250);
        b.Property(x => x.Industry).HasMaxLength(120);
        b.Property(x => x.City).HasMaxLength(120);
        b.Property(x => x.Language).HasMaxLength(40);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Industry });
    }
}

public sealed class TrackedLinkConfiguration : IEntityTypeConfiguration<TrackedLink>
{
    public void Configure(EntityTypeBuilder<TrackedLink> b)
    {
        b.ToTable("tracked_links");
        b.HasKey(x => x.Id);
        b.Property(x => x.Campaign).HasMaxLength(200);
        b.Property(x => x.DestinationUrl).HasMaxLength(1000);
        b.Property(x => x.UtmSource).HasMaxLength(120);
        b.Property(x => x.UtmMedium).HasMaxLength(120);
        b.Property(x => x.UtmCampaign).HasMaxLength(120);
        b.Property(x => x.ShortCode).HasMaxLength(20);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => x.ShortCode).IsUnique();
    }
}
