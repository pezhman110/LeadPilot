using LeadPilot.Domain.MobileSync;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class MobileContactSyncJobConfiguration : IEntityTypeConfiguration<MobileContactSyncJob>
{
    public void Configure(EntityTypeBuilder<MobileContactSyncJob> b)
    {
        b.ToTable("mobile_contact_sync_jobs");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.DeviceLabel).HasMaxLength(120);
        b.Property(x => x.MaskedValue).HasMaxLength(80);
        b.Property(x => x.DeviceContactRef).HasMaxLength(200);
        b.Property(x => x.LastError).HasMaxLength(2000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.Status, x.CreatedAtUtc });
        b.HasIndex(x => x.ProspectId);
        b.HasIndex(x => x.ContactPointId).IsUnique();
    }
}
