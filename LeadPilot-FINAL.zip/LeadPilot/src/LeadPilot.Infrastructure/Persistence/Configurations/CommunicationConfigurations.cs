using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Crm;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class OutreachAttemptConfiguration : IEntityTypeConfiguration<OutreachAttempt>
{
    public void Configure(EntityTypeBuilder<OutreachAttempt> b)
    {
        b.ToTable("outreach_attempts");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasConversion<int>();
        b.Property(x => x.Mode).HasConversion<int>();
        b.Property(x => x.Result).HasConversion<int>();
        b.Property(x => x.MessageRef).HasMaxLength(200);
        b.Property(x => x.BlockReason).HasMaxLength(500);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.ProspectId, x.CreatedAtUtc });
        b.HasIndex(x => new { x.Channel, x.Result });
    }
}

public sealed class InstagramCommentRuleConfiguration : IEntityTypeConfiguration<InstagramCommentRule>
{
    public void Configure(EntityTypeBuilder<InstagramCommentRule> b)
    {
        b.ToTable("instagram_comment_rules");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).HasMaxLength(150);
        b.Property(x => x.Keyword).HasMaxLength(150);
        b.Property(x => x.PublicReplyTemplateRef).HasMaxLength(200);
        b.Property(x => x.DmInviteTemplateRef).HasMaxLength(200);
        b.Property(x => x.Mode).HasConversion<int>();
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.IsEnabled });
    }
}

public sealed class ChannelPlaybookConfiguration : IEntityTypeConfiguration<ChannelPlaybook>
{
    public void Configure(EntityTypeBuilder<ChannelPlaybook> b)
    {
        b.ToTable("channel_playbooks");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasConversion<int>();
        b.Property(x => x.DiscoveryMethods).HasMaxLength(2000);
        b.Property(x => x.PermittedFields).HasMaxLength(2000);
        b.Property(x => x.ConsentMethod).HasMaxLength(1000);
        b.Property(x => x.PlatformRisks).HasMaxLength(2000);
        b.Property(x => x.ExpectedCostAed).HasPrecision(18, 2);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Channel }).IsUnique();
    }
}

public sealed class CrmConnectionConfiguration : IEntityTypeConfiguration<CrmConnection>
{
    public void Configure(EntityTypeBuilder<CrmConnection> b)
    {
        b.ToTable("crm_connections");
        b.HasKey(x => x.Id);
        b.Property(x => x.Provider).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.DisplayName).HasMaxLength(200);
        b.Property(x => x.BaseUrl).HasMaxLength(1000);
        b.Property(x => x.SecretReference).HasMaxLength(250);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Provider });
    }
}

public sealed class CrmSyncRecordConfiguration : IEntityTypeConfiguration<CrmSyncRecord>
{
    public void Configure(EntityTypeBuilder<CrmSyncRecord> b)
    {
        b.ToTable("crm_sync_records");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.Outcome).HasMaxLength(1000);
        b.Property(x => x.ExternalId).HasMaxLength(200);
        b.Property(x => x.Error).HasMaxLength(1000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.CrmConnectionId, x.CreatedAtUtc });
    }
}
