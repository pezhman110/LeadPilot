using LeadPilot.Domain.Campaigns;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class CampaignPresetConfiguration : IEntityTypeConfiguration<CampaignPreset>
{
    public void Configure(EntityTypeBuilder<CampaignPreset> b)
    {
        b.ToTable("campaign_presets");
        b.HasKey(x => x.Id);
        b.Property(x => x.Context).HasConversion<int>();
        b.Property(x => x.DisplayName).HasMaxLength(200);
        b.Property(x => x.City).HasMaxLength(120);
        b.Property(x => x.MonthlyBudgetUsd).HasPrecision(18, 2);
        b.Property(x => x.MaxCostPerLeadPercent).HasPrecision(5, 2);
        b.Property(x => x.RowVersion).IsRowVersion();
        // تاکتیک‌ها به‌صورت CSV از intها ذخیره می‌شوند
        b.Property(x => x.Tactics)
            .HasConversion(
                v => string.Join(',', v.Select(t => (int)t)),
                v => v.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(s => (LaunchTactic)int.Parse(s)).ToList())
            .Metadata.SetValueComparer(new Microsoft.EntityFrameworkCore.ChangeTracking.ValueComparer<IReadOnlyList<LaunchTactic>>(
                (a, c) => a!.SequenceEqual(c!), v => v.Aggregate(0, (h, x) => HashCode.Combine(h, (int)x)), v => v.ToList()));
        b.Property(x => x.Tactics).HasColumnName("tactics").HasMaxLength(200);
        b.HasIndex(x => new { x.TenantId, x.Context, x.City });
    }
}
