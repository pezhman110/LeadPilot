using LeadPilot.Domain.Consent;
using LeadPilot.Domain.Partners;
using LeadPilot.Domain.Targets;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

// ── رضایت ──
public sealed class ProtectedContactPointConfiguration : IEntityTypeConfiguration<ProtectedContactPoint>
{
    public void Configure(EntityTypeBuilder<ProtectedContactPoint> b)
    {
        b.ToTable("contact_points");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasConversion<int>();
        b.Property(x => x.Visibility).HasConversion<int>();
        b.Property(x => x.EncryptedValue).IsRequired();
        b.Property(x => x.Provider).IsRequired().HasMaxLength(120);
        b.Property(x => x.LawfulBasis).IsRequired().HasMaxLength(400);
        b.HasIndex(x => x.ProspectId);
    }
}

public sealed class InvitationJourneyConfiguration : IEntityTypeConfiguration<InvitationJourney>
{
    public void Configure(EntityTypeBuilder<InvitationJourney> b)
    {
        b.ToTable("invitation_journeys");
        b.HasKey(x => x.Id);
        b.Property(x => x.State).HasConversion<int>();
        b.Property(x => x.Route).HasConversion<int?>();
        b.Property(x => x.Channel).HasMaxLength(60);
        b.HasIndex(x => x.ProspectId);
    }
}

// ── همکاران ──
public sealed class PartnerConfiguration : IEntityTypeConfiguration<Partner>
{
    public void Configure(EntityTypeBuilder<Partner> b)
    {
        b.ToTable("partners");
        b.HasKey(x => x.Id);
        b.Property(x => x.FullName).IsRequired().HasMaxLength(200);
        b.Property(x => x.Type).HasConversion<int>();
        // زبان‌ها و توانمندی‌ها به‌صورت CSV در دو ستون ذخیره می‌شوند (property داخلیِ EF).
        b.Property(x => x.LanguagesCsv).HasColumnName("languages").HasMaxLength(400).HasDefaultValue("");
        b.Property(x => x.SkillsCsv).HasColumnName("skills").HasMaxLength(1000).HasDefaultValue("");
        b.Ignore(x => x.Languages);
        b.Ignore(x => x.Skills);
    }
}

public sealed class PartnerAgreementConfiguration : IEntityTypeConfiguration<PartnerAgreement>
{
    public void Configure(EntityTypeBuilder<PartnerAgreement> b)
    {
        b.ToTable("partner_agreements");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.CommissionPercent).HasColumnType("numeric(5,2)");
        b.Property(x => x.BonusAed).HasColumnType("numeric(18,2)");
        b.HasIndex(x => x.PartnerId);
    }
}

// ── اهداف ──
public sealed class ProjectTargetConfiguration : IEntityTypeConfiguration<ProjectTarget>
{
    public void Configure(EntityTypeBuilder<ProjectTarget> b)
    {
        b.ToTable("project_targets");
        b.HasKey(x => x.Id);
        b.Property(x => x.Name).IsRequired().HasMaxLength(200);
        b.Property(x => x.MetricType).HasConversion<int>();
        b.Property(x => x.PeriodType).HasConversion<int>();
        b.Property(x => x.TargetValue).HasPrecision(28, 2);
        b.Property(x => x.ActualValue).HasPrecision(28, 2);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => x.ProjectId);
    }
}

public sealed class ProjectFunnelSettingsConfiguration : IEntityTypeConfiguration<ProjectFunnelSettings>
{
    public void Configure(EntityTypeBuilder<ProjectFunnelSettings> b)
    {
        b.ToTable("project_funnel_settings");
        b.HasKey(x => x.Id);
        b.Property(x => x.AverageDealValueAed).HasPrecision(28, 2);
        b.Property(x => x.AverageCollectedRevenueAed).HasPrecision(28, 2);
        b.HasIndex(x => x.ProjectId).IsUnique();
    }
}

public sealed class CrossProjectOfferConfiguration : IEntityTypeConfiguration<CrossProjectOffer>
{
    public void Configure(EntityTypeBuilder<CrossProjectOffer> b)
    {
        b.ToTable("cross_project_offers");
        b.HasKey(x => x.Id);
        b.Property(x => x.SourceEvent).IsRequired().HasMaxLength(200);
        b.Property(x => x.TargetProjectCode).IsRequired().HasMaxLength(20);
        b.Property(x => x.DiscountOrCreditAed).HasPrecision(18, 2);
    }
}

public sealed class AttributionRecordConfiguration : IEntityTypeConfiguration<AttributionRecord>
{
    public void Configure(EntityTypeBuilder<AttributionRecord> b)
    {
        b.ToTable("attribution_records");
        b.HasKey(x => x.Id);
        b.Property(x => x.Model).HasConversion<int>();
        b.HasIndex(x => x.SaleId);
    }
}
