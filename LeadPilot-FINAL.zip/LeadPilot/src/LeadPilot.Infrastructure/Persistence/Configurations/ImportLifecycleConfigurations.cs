using LeadPilot.Domain.Imports;
using LeadPilot.Domain.Lifecycle;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ContactImportBatchConfiguration : IEntityTypeConfiguration<ContactImportBatch>
{
    public void Configure(EntityTypeBuilder<ContactImportBatch> b)
    {
        b.ToTable("contact_import_batches");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.ProjectCode).HasMaxLength(100);
        b.Property(x => x.OriginalFileName).HasMaxLength(400);
        b.Property(x => x.SourceCode).HasMaxLength(100);
        b.Property(x => x.ImportedBy).HasMaxLength(120);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.ProjectId, x.CreatedAtUtc });
    }
}

public sealed class ConsentEvidenceConfiguration : IEntityTypeConfiguration<ConsentEvidence>
{
    public void Configure(EntityTypeBuilder<ConsentEvidence> b)
    {
        b.ToTable("consent_evidences");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasMaxLength(40);
        b.Property(x => x.Method).HasMaxLength(120);
        b.Property(x => x.EvidenceRef).HasMaxLength(400);
        b.HasIndex(x => new { x.TenantId, x.ProspectId });
    }
}

public sealed class DataRetentionPolicyConfiguration : IEntityTypeConfiguration<DataRetentionPolicy>
{
    public void Configure(EntityTypeBuilder<DataRetentionPolicy> b)
    {
        b.ToTable("data_retention_policies");
        b.HasKey(x => x.Id);
        b.Property(x => x.DataCategory).HasMaxLength(120);
        b.Property(x => x.LawfulBasis).HasMaxLength(400);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.DataCategory }).IsUnique();
    }
}

public sealed class DeletionRequestConfiguration : IEntityTypeConfiguration<DeletionRequest>
{
    public void Configure(EntityTypeBuilder<DeletionRequest> b)
    {
        b.ToTable("deletion_requests");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.RequestedBy).HasMaxLength(120);
        b.Property(x => x.Reason).HasMaxLength(1000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.ProspectId, x.Status });
    }
}
