using LeadPilot.Domain.Dedup;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ContactRecordConfiguration : IEntityTypeConfiguration<ContactRecord>
{
    public void Configure(EntityTypeBuilder<ContactRecord> b)
    {
        b.ToTable("contact_records"); b.HasKey(x => x.Id);
        b.Property(x => x.ContactType).HasConversion<int>();
        b.Property(x => x.ContactHash).IsRequired().HasMaxLength(64);
        // قید یکتاییِ سند: TenantId + ContactType + ContactHash
        b.HasIndex(x => new { x.TenantId, x.ContactType, x.ContactHash }).IsUnique();
        b.HasMany(x => x.Observations).WithOne().HasForeignKey(o => o.ContactRecordId);
    }
}

public sealed class ContactObservationConfiguration : IEntityTypeConfiguration<ContactObservation>
{
    public void Configure(EntityTypeBuilder<ContactObservation> b)
    {
        b.ToTable("contact_observations"); b.HasKey(x => x.Id);
        b.Property(x => x.Source).HasMaxLength(120);
        b.HasIndex(x => x.ContactRecordId);
    }
}

public sealed class EnrichmentReservationConfiguration : IEntityTypeConfiguration<EnrichmentReservation>
{
    public void Configure(EntityTypeBuilder<EnrichmentReservation> b)
    {
        b.ToTable("enrichment_reservations"); b.HasKey(x => x.Id);
        b.Property(x => x.Key).IsRequired().HasMaxLength(300);
        b.HasIndex(x => x.Key).IsUnique(); // کلید رزرو یکتاست
    }
}
