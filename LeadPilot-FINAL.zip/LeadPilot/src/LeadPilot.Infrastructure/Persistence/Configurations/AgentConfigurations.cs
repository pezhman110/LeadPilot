using LeadPilot.Domain.Agents;
using LeadPilot.Domain.Communications;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class AgentProfileConfiguration : IEntityTypeConfiguration<AgentProfile>
{
    public void Configure(EntityTypeBuilder<AgentProfile> b)
    {
        b.ToTable("agent_profiles");
        b.HasKey(x => x.Id);
        b.Property(x => x.DisplayName).HasMaxLength(200);
        b.Property<string>("ServicesCsv").HasColumnName("services_csv").HasMaxLength(2000);
        b.Property<string>("ChannelsCsv").HasColumnName("channels_csv").HasMaxLength(2000);
        b.Ignore(x => x.Services);
        b.Ignore(x => x.Channels);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.PartnerId }).IsUnique();
    }
}

public sealed class ContactAssignmentConfiguration : IEntityTypeConfiguration<ContactAssignment>
{
    public void Configure(EntityTypeBuilder<ContactAssignment> b)
    {
        b.ToTable("contact_assignments");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.ServiceCode).HasMaxLength(100);
        b.Property(x => x.PushedToCrm).HasMaxLength(200);
        b.Property(x => x.RowVersion).IsRowVersion();
        // قفلِ انحصاری: فقط یک تخصیصِ Active برای هر ContactPoint.
        // ActiveContactKey برای رکوردهای Active = ContactPointId، برای بقیه null → ایندکسِ یکتای فیلترشده.
        b.HasIndex(x => x.ActiveContactKey).IsUnique()
            .HasFilter("active_contact_key IS NOT NULL");
        b.Property(x => x.ActiveContactKey).HasColumnName("active_contact_key");
        b.HasIndex(x => new { x.AgentProfileId, x.Status });
    }
}

public sealed class ChannelProviderConfigConfiguration : IEntityTypeConfiguration<ChannelProviderConfig>
{
    public void Configure(EntityTypeBuilder<ChannelProviderConfig> b)
    {
        b.ToTable("channel_provider_configs");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasConversion<int>();
        b.Property(x => x.Provider).HasConversion<int>();
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Channel, x.Priority });
        b.HasIndex(x => new { x.TenantId, x.Channel, x.Provider }).IsUnique();
    }
}
