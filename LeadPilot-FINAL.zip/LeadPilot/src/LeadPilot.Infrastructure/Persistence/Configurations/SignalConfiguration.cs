using LeadPilot.Domain.Signals;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class SearchRunConfiguration : IEntityTypeConfiguration<SearchRun>
{
    public void Configure(EntityTypeBuilder<SearchRun> b)
    {
        b.ToTable("search_runs");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
    }
}

public sealed class RawSignalConfiguration : IEntityTypeConfiguration<RawSignal>
{
    public void Configure(EntityTypeBuilder<RawSignal> b)
    {
        b.ToTable("raw_signals");
        b.HasKey(x => x.Id);
        b.Property(x => x.SourceUrl).IsRequired();
        b.Property(x => x.QueryUsed).IsRequired();
        b.Property(x => x.SourceType).HasConversion<int>();
        b.Property(x => x.Language).HasConversion<int>();
        b.HasIndex(x => x.SearchRunId);
    }
}

public sealed class NormalizedSignalConfiguration : IEntityTypeConfiguration<NormalizedSignal>
{
    public void Configure(EntityTypeBuilder<NormalizedSignal> b)
    {
        b.ToTable("signals");
        b.HasKey(x => x.Id);
        b.Property(x => x.SourceType).HasConversion<int>();
        b.Property(x => x.Language).HasConversion<int>();
        b.Property(x => x.ComplianceStatus).HasConversion<int>();
        b.OwnsMany(x => x.Evidence, e => { e.ToTable("signal_evidence"); e.WithOwner().HasForeignKey("SignalId"); e.HasKey(x => x.Id); });
        b.Property(x => x.ReasonForScore).HasConversion(
            v => string.Join('\u0001', v),
            v => v.Split('\u0001', System.StringSplitOptions.RemoveEmptyEntries).ToList(),
            new Microsoft.EntityFrameworkCore.ChangeTracking.ValueComparer<List<string>>(
                (a, c) => (a ?? new()).SequenceEqual(c ?? new()),
                v => v.Aggregate(0, (h, s) => System.HashCode.Combine(h, s.GetHashCode())),
                v => v.ToList()));
        b.HasIndex(x => new { x.ProjectId, x.FinalScore });
    }
}
