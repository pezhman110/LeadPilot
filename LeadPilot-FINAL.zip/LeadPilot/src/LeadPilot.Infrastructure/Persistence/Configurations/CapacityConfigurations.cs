using LeadPilot.Domain.Capacity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class DailyCapacityPlanConfiguration : IEntityTypeConfiguration<DailyCapacityPlan>
{
    public void Configure(EntityTypeBuilder<DailyCapacityPlan> b)
    {
        b.ToTable("DailyCapacityPlans");
        b.HasKey(x => x.Id);
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.CreatedBy).HasMaxLength(200).IsRequired();
        b.Property(x => x.RowVersion).IsRowVersion();
        // یک برنامهٔ اصلی برای هر روز و Tenant
        b.HasIndex(x => new { x.TenantId, x.BusinessDate }).IsUnique();
        b.HasIndex(x => x.Status);
        b.HasMany(x => x.Quotas).WithOne(x => x.DailyCapacityPlan)
            .HasForeignKey(x => x.DailyCapacityPlanId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class ProjectDailyQuotaConfiguration : IEntityTypeConfiguration<ProjectDailyQuota>
{
    public void Configure(EntityTypeBuilder<ProjectDailyQuota> b)
    {
        b.ToTable("ProjectDailyQuotas");
        b.HasKey(x => x.Id);
        b.Property(x => x.GroupCode).HasMaxLength(100).IsRequired();
        b.HasIndex(x => new { x.DailyCapacityPlanId, x.GroupCode, x.ProjectId }).IsUnique();
    }
}

public sealed class CapacitySnapshotConfiguration : IEntityTypeConfiguration<CapacitySnapshot>
{
    public void Configure(EntityTypeBuilder<CapacitySnapshot> b)
    {
        b.ToTable("CapacitySnapshots");
        b.HasKey(x => x.Id);
        b.Property(x => x.CostAed).HasPrecision(28, 2);
        b.HasIndex(x => new { x.PlanId, x.QuotaId, x.CapturedAtUtc });
    }
}
