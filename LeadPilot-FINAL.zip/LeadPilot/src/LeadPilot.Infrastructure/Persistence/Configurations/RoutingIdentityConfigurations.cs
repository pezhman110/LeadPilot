using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Identity;
using LeadPilot.Domain.Suppression;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class GlobalSuppressionEntryConfiguration : IEntityTypeConfiguration<GlobalSuppressionEntry>
{
    public void Configure(EntityTypeBuilder<GlobalSuppressionEntry> b)
    {
        b.ToTable("global_suppression_entries");
        b.HasKey(x => x.Id);
        b.Property(x => x.Scope).HasConversion<int>();
        b.Property(x => x.IdentityHash).HasMaxLength(128);
        b.Property(x => x.Channel).HasMaxLength(40);
        b.Property(x => x.Reason).HasMaxLength(500);
        b.Property(x => x.Source).HasMaxLength(120);
        b.HasIndex(x => new { x.TenantId, x.IdentityHash });
    }
}

public sealed class IdentityLinkConfiguration : IEntityTypeConfiguration<IdentityLink>
{
    public void Configure(EntityTypeBuilder<IdentityLink> b)
    {
        b.ToTable("identity_links");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasMaxLength(40);
        b.Property(x => x.AccountHandle).HasMaxLength(200);
        b.Property(x => x.Evidence).HasConversion<int>();
        b.Property(x => x.Confidence).HasConversion<int>();
        b.Property(x => x.ConfirmedBy).HasMaxLength(120);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.UnifiedProfileId });
        b.HasIndex(x => new { x.TenantId, x.Channel, x.AccountHandle });
    }
}

public sealed class PrimaryConnectorBindingConfiguration : IEntityTypeConfiguration<PrimaryConnectorBinding>
{
    public void Configure(EntityTypeBuilder<PrimaryConnectorBinding> b)
    {
        b.ToTable("primary_connector_bindings");
        b.HasKey(x => x.Id);
        b.Property(x => x.Channel).HasConversion<int>();
        b.Property(x => x.Provider).HasConversion<int>();
        b.Property(x => x.AccountRef).HasMaxLength(200);
        b.Property(x => x.Role).HasConversion<int>();
        b.Property(x => x.PrimaryKey).HasColumnName("primary_key").HasMaxLength(200);
        b.Property(x => x.RowVersion).IsRowVersion();
        // فقط یک Primary برای هر Tenant+Channel+Account.
        b.HasIndex(x => x.PrimaryKey).IsUnique().HasFilter("primary_key IS NOT NULL");
    }
}
