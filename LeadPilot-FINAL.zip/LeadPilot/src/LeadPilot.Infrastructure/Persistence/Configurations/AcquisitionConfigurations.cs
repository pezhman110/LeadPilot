using LeadPilot.Domain.Acquisition;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class FirstTenRunConfiguration : IEntityTypeConfiguration<FirstTenRun>
{
    public void Configure(EntityTypeBuilder<FirstTenRun> b)
    {
        b.ToTable("first_ten_runs");
        b.HasKey(x => x.Id);
        b.Property(x => x.ProjectCode).HasMaxLength(60).IsRequired();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.StartedBy).HasMaxLength(200).IsRequired();
        b.Property(x => x.MaximumCostAed).HasPrecision(18, 2);
        b.Property(x => x.ConsumedCostAed).HasPrecision(18, 2);
        b.Property(x => x.FailureReason).HasMaxLength(1000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Status });
        b.HasMany(x => x.Results).WithOne().HasForeignKey(x => x.RunId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class FirstTenRunResultConfiguration : IEntityTypeConfiguration<FirstTenRunResult>
{
    public void Configure(EntityTypeBuilder<FirstTenRunResult> b)
    {
        b.ToTable("first_ten_run_results");
        b.HasKey(x => x.Id);
        b.Property(x => x.ContactType).HasMaxLength(20);
        b.Property(x => x.MaskedValue).HasMaxLength(80).IsRequired();
        b.Property(x => x.SourceCode).HasMaxLength(80).IsRequired();
        b.Property(x => x.SourceReference).HasMaxLength(500).IsRequired();
        b.Property(x => x.SourceUrl).HasMaxLength(1000);
        b.Property(x => x.CostAed).HasPrecision(18, 2);
        b.HasIndex(x => x.RunId);
        b.HasIndex(x => new { x.RunId, x.ContactPointId }).IsUnique();
    }
}
