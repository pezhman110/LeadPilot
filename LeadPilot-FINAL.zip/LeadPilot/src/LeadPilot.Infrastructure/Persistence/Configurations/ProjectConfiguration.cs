using LeadPilot.Domain.Projects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ProjectConfiguration : IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        builder.ToTable("projects");
        builder.HasKey(x => x.Id);

        builder.Property(x => x.PersianName).IsRequired().HasMaxLength(200);
        builder.Property(x => x.EnglishName).IsRequired().HasMaxLength(200);
        builder.Property(x => x.CustomerType).HasConversion<int>();
        builder.Property(x => x.Status).HasConversion<int>();
        builder.Property(x => x.MinimumBudgetAed).HasColumnType("numeric(18,2)");

        // کنترل همزمانی با ستون سیستمیِ xmin در PostgreSQL (الگوی رسمی Npgsql)
        builder.Property(x => x.RowVersion).IsRowVersion();

        builder.HasMany(x => x.Languages)
            .WithOne(l => l.Project)
            .HasForeignKey(l => l.ProjectId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(x => x.Geographies)
            .WithOne(g => g.Project)
            .HasForeignKey(g => g.ProjectId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Navigation(x => x.Languages).UsePropertyAccessMode(PropertyAccessMode.Field);
        builder.Navigation(x => x.Geographies).UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class ProjectLanguageConfiguration : IEntityTypeConfiguration<ProjectLanguage>
{
    public void Configure(EntityTypeBuilder<ProjectLanguage> builder)
    {
        builder.ToTable("project_languages");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Code).IsRequired().HasMaxLength(5);
        builder.HasIndex(x => new { x.ProjectId, x.Code }).IsUnique();
    }
}

public sealed class ProjectGeographyConfiguration : IEntityTypeConfiguration<ProjectGeography>
{
    public void Configure(EntityTypeBuilder<ProjectGeography> builder)
    {
        builder.ToTable("project_geographies");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.CountryCode).IsRequired().HasMaxLength(3);
        builder.Property(x => x.City).HasMaxLength(120);
    }
}
