using LeadPilot.Domain.Connections;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ConnectorDefinitionConfiguration : IEntityTypeConfiguration<ConnectorDefinition>
{
    public void Configure(EntityTypeBuilder<ConnectorDefinition> builder)
    {
        builder.ToTable("connector_definitions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Code).HasMaxLength(100).IsRequired();
        builder.Property(x => x.DisplayName).HasMaxLength(250).IsRequired();
        builder.Property(x => x.Category).HasConversion<int>().IsRequired();
        builder.Property(x => x.CostLevel).HasConversion<int>().IsRequired();
        builder.Property(x => x.Status).HasConversion<int>().IsRequired();
        builder.Property(x => x.SecretReference).HasMaxLength(250);
        builder.Property(x => x.BaseUrl).HasMaxLength(1000);
        builder.Property(x => x.MaximumDailyCostAed).HasPrecision(28, 2);
        builder.Property(x => x.LastHealthMessage).HasMaxLength(2000);
        builder.Property(x => x.RowVersion).IsRowVersion(); // Postgres xmin
        builder.HasIndex(x => new { x.TenantId, x.Code }).IsUnique();
        builder.HasIndex(x => new { x.TenantId, x.IsEnabled, x.Status });
        builder.HasIndex(x => new { x.CostLevel, x.ExecutionOrder });
    }
}

public sealed class ConnectorHealthCheckConfiguration : IEntityTypeConfiguration<ConnectorHealthCheck>
{
    public void Configure(EntityTypeBuilder<ConnectorHealthCheck> builder)
    {
        builder.ToTable("connector_health_checks");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Status).HasConversion<int>().IsRequired();
        builder.Property(x => x.ErrorCode).HasMaxLength(100);
        builder.Property(x => x.Message).HasMaxLength(2000);
        builder.HasIndex(x => new { x.ConnectorDefinitionId, x.CheckedAtUtc });
    }
}
