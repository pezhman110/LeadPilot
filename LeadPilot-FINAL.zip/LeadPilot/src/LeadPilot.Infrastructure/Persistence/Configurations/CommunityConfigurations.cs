using LeadPilot.Domain.Community;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class CommunitySourceConfiguration : IEntityTypeConfiguration<CommunitySource>
{
    public void Configure(EntityTypeBuilder<CommunitySource> b)
    {
        b.ToTable("community_sources");
        b.HasKey(x => x.Id);
        b.Property(x => x.Platform).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.Name).HasMaxLength(200);
        b.Property(x => x.Url).HasMaxLength(1000);
        b.Property(x => x.Country).HasMaxLength(80);
        b.Property(x => x.City).HasMaxLength(120);
        b.Property(x => x.Language).HasMaxLength(40);
        b.Property(x => x.Industries).HasMaxLength(1000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Platform, x.Status });
    }
}

public sealed class OpportunityConfiguration : IEntityTypeConfiguration<Opportunity>
{
    public void Configure(EntityTypeBuilder<Opportunity> b)
    {
        b.ToTable("community_opportunities");
        b.HasKey(x => x.Id);
        b.Property(x => x.Platform).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.Community).HasMaxLength(200);
        b.Property(x => x.PublicThreadUrl).HasMaxLength(1000);
        b.Property(x => x.PublicPostId).HasMaxLength(200);
        b.Property(x => x.Topic).HasMaxLength(300);
        b.Property(x => x.QuestionSummary).HasMaxLength(2000);
        b.Property(x => x.Language).HasMaxLength(40);
        b.Property(x => x.Industry).HasMaxLength(120);
        b.Property(x => x.DeclaredLocation).HasMaxLength(200);
        b.Property(x => x.PublishedResponseUrl).HasMaxLength(1000);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.TenantId, x.Status, x.IntentScore });
        // dedup: یک Thread عمومی دوبار Opportunity نشود.
        b.HasIndex(x => new { x.TenantId, x.PublicThreadUrl }).IsUnique();
    }
}
