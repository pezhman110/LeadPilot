using LeadPilot.Domain.Content;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ContentHeadingConfiguration : IEntityTypeConfiguration<ContentHeading>
{
    public void Configure(EntityTypeBuilder<ContentHeading> b)
    {
        b.ToTable("content_headings"); b.HasKey(x => x.Id);
        b.Property(x => x.Title).IsRequired().HasMaxLength(300);
        b.Property(x => x.AudienceGroup).HasMaxLength(200);
        b.Property(x => x.Language).HasMaxLength(10);
        b.HasIndex(x => x.ProjectId);
    }
}
public sealed class ContentAssetConfiguration : IEntityTypeConfiguration<ContentAsset>
{
    public void Configure(EntityTypeBuilder<ContentAsset> b)
    {
        b.ToTable("content_assets"); b.HasKey(x => x.Id);
        b.Property(x => x.Type).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.Language).HasMaxLength(10);
        b.Property(x => x.Title).HasMaxLength(300);
        b.HasIndex(x => new { x.ProjectId, x.Type, x.Language });
    }
}
public sealed class LandingPageConfiguration : IEntityTypeConfiguration<LandingPage>
{
    public void Configure(EntityTypeBuilder<LandingPage> b)
    {
        b.ToTable("landing_pages"); b.HasKey(x => x.Id);
        b.Property(x => x.Slug).IsRequired().HasMaxLength(120);
        b.Property(x => x.TemplateCode).HasMaxLength(60);
        b.Property(x => x.Language).HasMaxLength(10);
        b.Property(x => x.Headline).HasMaxLength(300);
        b.HasIndex(x => x.Slug).IsUnique();
    }
}
public sealed class CampaignConfiguration : IEntityTypeConfiguration<Campaign>
{
    public void Configure(EntityTypeBuilder<Campaign> b)
    {
        b.ToTable("campaigns"); b.HasKey(x => x.Id);
        b.Property(x => x.Name).IsRequired().HasMaxLength(200);
        b.Property(x => x.Scope).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.HasIndex(x => x.ProjectId);
    }
}
public sealed class PresentationConfiguration : IEntityTypeConfiguration<Presentation>
{
    public void Configure(EntityTypeBuilder<Presentation> b)
    {
        b.ToTable("presentations"); b.HasKey(x => x.Id);
        b.Property(x => x.Presenter).HasConversion<int>();
        b.Property(x => x.Status).HasConversion<int>();
        b.Property(x => x.Language).HasMaxLength(10);
        b.HasIndex(x => x.ProspectId);
    }
}
