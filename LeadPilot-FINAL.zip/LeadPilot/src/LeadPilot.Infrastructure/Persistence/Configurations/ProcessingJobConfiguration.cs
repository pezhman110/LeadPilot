using LeadPilot.Domain.Processing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LeadPilot.Infrastructure.Persistence.Configurations;

public sealed class ProcessingJobConfiguration : IEntityTypeConfiguration<ProcessingJob>
{
    public void Configure(EntityTypeBuilder<ProcessingJob> b)
    {
        b.ToTable("ProcessingJobs");
        b.HasKey(x => x.Id);
        b.Property(x => x.JobType).HasMaxLength(150).IsRequired();
        b.Property(x => x.Payload).HasColumnType("text").IsRequired(); // Postgres: text (نه nvarchar(max))
        b.Property(x => x.IdempotencyKey).HasMaxLength(500).IsRequired();
        b.Property(x => x.CorrelationId).HasMaxLength(200).IsRequired();
        b.Property(x => x.Status).HasConversion<int>().IsRequired();
        b.Property(x => x.Priority).HasConversion<int>().IsRequired();
        b.Property(x => x.LockedBy).HasMaxLength(200);
        b.Property(x => x.LastErrorCode).HasMaxLength(200);
        b.Property(x => x.LastError).HasMaxLength(4000);
        b.Property(x => x.RowVersion).IsRowVersion(); // Postgres xmin

        b.HasIndex(x => x.IdempotencyKey).IsUnique();
        b.HasIndex(x => new { x.Status, x.ScheduledAtUtc, x.Priority });
        b.HasIndex(x => new { x.JobType, x.Status, x.ScheduledAtUtc });
        b.HasIndex(x => new { x.Status, x.LockedUntilUtc });
        b.HasIndex(x => x.ProjectId);
        b.HasIndex(x => x.ProspectId);
        b.HasIndex(x => x.CorrelationId);
    }
}
