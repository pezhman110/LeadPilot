using LeadPilot.Application.Dedup;
using LeadPilot.Domain.Dedup;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class DeduplicationRepository(LeadPilotDbContext db) : IDeduplicationRepository
{
    public Task<ContactRecord?> FindByHashAsync(Guid tenantId, ContactType type, string hash, CancellationToken ct) =>
        db.ContactRecords.Include(x => x.Observations)
            .FirstOrDefaultAsync(x => x.TenantId == tenantId && x.ContactType == type && x.ContactHash == hash, ct);
    public async Task AddAsync(ContactRecord record, CancellationToken ct) => await db.ContactRecords.AddAsync(record, ct);
    public Task<bool> ReservationExistsAsync(string key, CancellationToken ct) =>
        db.EnrichmentReservations.AnyAsync(x => x.Key == key, ct);
    public async Task AddReservationAsync(EnrichmentReservation r, CancellationToken ct) =>
        await db.EnrichmentReservations.AddAsync(r, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
