using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace LeadPilot.Infrastructure.Persistence;

/// <summary>برای «dotnet ef migrations add ...» لازم است.</summary>
public sealed class LeadPilotDbContextFactory : IDesignTimeDbContextFactory<LeadPilotDbContext>
{
    public LeadPilotDbContext CreateDbContext(string[] args)
    {
        var cs = Environment.GetEnvironmentVariable("ConnectionStrings__MainDatabase")
                 ?? "Host=localhost;Port=5432;Database=leadpilot;Username=leadpilot;Password=leadpilot";
        var options = new DbContextOptionsBuilder<LeadPilotDbContext>()
            .UseNpgsql(cs)
            .Options;
        return new LeadPilotDbContext(options);
    }
}
