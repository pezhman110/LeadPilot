using LeadPilot.Application.Abstractions;
using LeadPilot.Domain.Signals;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class SignalRepository(LeadPilotDbContext db) : ISignalRepository
{
    public async Task AddNormalizedAsync(NormalizedSignal signal, CancellationToken ct) =>
        await db.Signals.AddAsync(signal, ct);

    public async Task<IReadOnlyList<NormalizedSignal>> ListByProjectAsync(Guid projectId, CancellationToken ct) =>
        await db.Signals.AsNoTracking()
            .Where(s => s.ProjectId == projectId)
            .OrderByDescending(s => s.FinalScore)
            .ToListAsync(ct);

    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}

public sealed class SearchRunRepository(LeadPilotDbContext db) : ISearchRunRepository
{
    public async Task AddAsync(SearchRun run, CancellationToken ct) => await db.SearchRuns.AddAsync(run, ct);
    public Task<SearchRun?> GetAsync(Guid id, CancellationToken ct) =>
        db.SearchRuns.FirstOrDefaultAsync(x => x.Id == id, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
