using LeadPilot.Application.Consent;
using LeadPilot.Domain.Consent;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class ConsentRepository(LeadPilotDbContext db) : IConsentRepository
{
    public async Task AddContactAsync(ProtectedContactPoint cp, CancellationToken ct) =>
        await db.ContactPoints.AddAsync(cp, ct);
    public Task<ProtectedContactPoint?> GetContactAsync(Guid id, CancellationToken ct) =>
        db.ContactPoints.FirstOrDefaultAsync(x => x.Id == id, ct);
    public async Task<IReadOnlyList<ProtectedContactPoint>> ListByProspectAsync(Guid prospectId, CancellationToken ct) =>
        await db.ContactPoints.Where(x => x.ProspectId == prospectId).ToListAsync(ct);
    public async Task AddJourneyAsync(InvitationJourney j, CancellationToken ct) =>
        await db.InvitationJourneys.AddAsync(j, ct);
    public Task<InvitationJourney?> GetJourneyAsync(Guid id, CancellationToken ct) =>
        db.InvitationJourneys.FirstOrDefaultAsync(x => x.Id == id, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
