using LeadPilot.Domain.Consent;
using LeadPilot.Domain.Partners;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;
using LeadPilot.Domain.Targets;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class LeadPilotDbContext(DbContextOptions<LeadPilotDbContext> options) : DbContext(options)
{
    // پروژه‌ها
    public DbSet<Project> Projects => Set<Project>();
    public DbSet<ProjectLanguage> ProjectLanguages => Set<ProjectLanguage>();
    public DbSet<ProjectGeography> ProjectGeographies => Set<ProjectGeography>();

    // جست‌وجو
    public DbSet<SearchRun> SearchRuns => Set<SearchRun>();
    public DbSet<RawSignal> RawSignals => Set<RawSignal>();
    public DbSet<NormalizedSignal> Signals => Set<NormalizedSignal>();

    // رضایت
    public DbSet<ProtectedContactPoint> ContactPoints => Set<ProtectedContactPoint>();
    public DbSet<InvitationJourney> InvitationJourneys => Set<InvitationJourney>();

    // همکاران
    public DbSet<Partner> Partners => Set<Partner>();
    public DbSet<PartnerAgreement> PartnerAgreements => Set<PartnerAgreement>();

    // اهداف و زنجیرهٔ درآمد
    public DbSet<ProjectTarget> ProjectTargets => Set<ProjectTarget>();
    public DbSet<ProjectFunnelSettings> FunnelSettings => Set<ProjectFunnelSettings>();
    public DbSet<CrossProjectOffer> CrossProjectOffers => Set<CrossProjectOffer>();
    public DbSet<AttributionRecord> AttributionRecords => Set<AttributionRecord>();

    // محتوا و کمپین
    public DbSet<LeadPilot.Domain.Content.ContentHeading> ContentHeadings => Set<LeadPilot.Domain.Content.ContentHeading>();
    public DbSet<LeadPilot.Domain.Content.ContentAsset> ContentAssets => Set<LeadPilot.Domain.Content.ContentAsset>();
    public DbSet<LeadPilot.Domain.Content.LandingPage> LandingPages => Set<LeadPilot.Domain.Content.LandingPage>();
    public DbSet<LeadPilot.Domain.Content.Campaign> Campaigns => Set<LeadPilot.Domain.Content.Campaign>();
    public DbSet<LeadPilot.Domain.Content.Presentation> Presentations => Set<LeadPilot.Domain.Content.Presentation>();

    // جلوگیری از دریافت/پرداخت مجدد
    public DbSet<LeadPilot.Domain.Dedup.ContactRecord> ContactRecords => Set<LeadPilot.Domain.Dedup.ContactRecord>();
    public DbSet<LeadPilot.Domain.Dedup.ContactObservation> ContactObservations => Set<LeadPilot.Domain.Dedup.ContactObservation>();
    public DbSet<LeadPilot.Domain.Dedup.EnrichmentReservation> EnrichmentReservations => Set<LeadPilot.Domain.Dedup.EnrichmentReservation>();

    // صف پردازشِ پایدار
    public DbSet<LeadPilot.Domain.Processing.ProcessingJob> ProcessingJobs => Set<LeadPilot.Domain.Processing.ProcessingJob>();

    // برنامه‌ریز ظرفیت روزانه
    public DbSet<LeadPilot.Domain.Capacity.DailyCapacityPlan> DailyCapacityPlans => Set<LeadPilot.Domain.Capacity.DailyCapacityPlan>();
    public DbSet<LeadPilot.Domain.Capacity.ProjectDailyQuota> ProjectDailyQuotas => Set<LeadPilot.Domain.Capacity.ProjectDailyQuota>();
    public DbSet<LeadPilot.Domain.Capacity.CapacitySnapshot> CapacitySnapshots => Set<LeadPilot.Domain.Capacity.CapacitySnapshot>();

    // صف همگام‌سازی موبایل
    public DbSet<LeadPilot.Domain.MobileSync.MobileContactSyncJob> MobileContactSyncJobs => Set<LeadPilot.Domain.MobileSync.MobileContactSyncJob>();

    // Connection Center (اتصالات واقعی)
    public DbSet<LeadPilot.Domain.Connections.ConnectorDefinition> ConnectorDefinitions => Set<LeadPilot.Domain.Connections.ConnectorDefinition>();
    public DbSet<LeadPilot.Domain.Connections.ConnectorHealthCheck> ConnectorHealthChecks => Set<LeadPilot.Domain.Connections.ConnectorHealthCheck>();

    // ماژول ارتباطات (Communications) + CRM
    public DbSet<LeadPilot.Domain.Communications.OutreachAttempt> OutreachAttempts => Set<LeadPilot.Domain.Communications.OutreachAttempt>();
    public DbSet<LeadPilot.Domain.Communications.InstagramCommentRule> InstagramCommentRules => Set<LeadPilot.Domain.Communications.InstagramCommentRule>();
    public DbSet<LeadPilot.Domain.Communications.ChannelPlaybook> ChannelPlaybooks => Set<LeadPilot.Domain.Communications.ChannelPlaybook>();
    public DbSet<LeadPilot.Domain.Crm.CrmConnection> CrmConnections => Set<LeadPilot.Domain.Crm.CrmConnection>();
    public DbSet<LeadPilot.Domain.Crm.CrmSyncRecord> CrmSyncRecords => Set<LeadPilot.Domain.Crm.CrmSyncRecord>();

    // فروشنده‌ها و تخصیص + Failover ابزارها
    public DbSet<LeadPilot.Domain.Agents.AgentProfile> AgentProfiles => Set<LeadPilot.Domain.Agents.AgentProfile>();
    public DbSet<LeadPilot.Domain.Agents.ContactAssignment> ContactAssignments => Set<LeadPilot.Domain.Agents.ContactAssignment>();
    public DbSet<LeadPilot.Domain.Communications.ChannelProviderConfig> ChannelProviderConfigs => Set<LeadPilot.Domain.Communications.ChannelProviderConfig>();

    // مسیریابی، هویت، Suppression سراسری
    public DbSet<LeadPilot.Domain.Suppression.GlobalSuppressionEntry> GlobalSuppressionEntries => Set<LeadPilot.Domain.Suppression.GlobalSuppressionEntry>();
    public DbSet<LeadPilot.Domain.Identity.IdentityLink> IdentityLinks => Set<LeadPilot.Domain.Identity.IdentityLink>();
    public DbSet<LeadPilot.Domain.Communications.PrimaryConnectorBinding> PrimaryConnectorBindings => Set<LeadPilot.Domain.Communications.PrimaryConnectorBinding>();

    // جذب (Acquisition): کشف منبع، تأیید Provider، قرنطینه، سیگنال قصد، Lead Magnet، Tracked Link
    public DbSet<LeadPilot.Domain.Discovery.AcquisitionSource> AcquisitionSources => Set<LeadPilot.Domain.Discovery.AcquisitionSource>();
    public DbSet<LeadPilot.Domain.Discovery.ProviderApproval> ProviderApprovals => Set<LeadPilot.Domain.Discovery.ProviderApproval>();
    public DbSet<LeadPilot.Domain.Discovery.ImportRecord> ImportRecords => Set<LeadPilot.Domain.Discovery.ImportRecord>();
    public DbSet<LeadPilot.Domain.Discovery.IntentSignal> IntentSignals => Set<LeadPilot.Domain.Discovery.IntentSignal>();
    public DbSet<LeadPilot.Domain.Discovery.LeadMagnet> LeadMagnets => Set<LeadPilot.Domain.Discovery.LeadMagnet>();
    public DbSet<LeadPilot.Domain.Discovery.TrackedLink> TrackedLinks => Set<LeadPilot.Domain.Discovery.TrackedLink>();

    // ورود CSV/CRM + چرخهٔ عمر داده
    public DbSet<LeadPilot.Domain.Imports.ContactImportBatch> ContactImportBatches => Set<LeadPilot.Domain.Imports.ContactImportBatch>();
    public DbSet<LeadPilot.Domain.Lifecycle.ConsentEvidence> ConsentEvidences => Set<LeadPilot.Domain.Lifecycle.ConsentEvidence>();
    public DbSet<LeadPilot.Domain.Lifecycle.DataRetentionPolicy> DataRetentionPolicies => Set<LeadPilot.Domain.Lifecycle.DataRetentionPolicy>();
    public DbSet<LeadPilot.Domain.Lifecycle.DeletionRequest> DeletionRequests => Set<LeadPilot.Domain.Lifecycle.DeletionRequest>();

    // انجمن‌ها و فروم‌ها (Community & Forum Opportunities)
    public DbSet<LeadPilot.Domain.Community.CommunitySource> CommunitySources => Set<LeadPilot.Domain.Community.CommunitySource>();
    public DbSet<LeadPilot.Domain.Community.Opportunity> CommunityOpportunities => Set<LeadPilot.Domain.Community.Opportunity>();

    // Launcher کمپین (زمینه‌محور: هتل/برج/مال/…)
    public DbSet<LeadPilot.Domain.Campaigns.CampaignPreset> CampaignPresets => Set<LeadPilot.Domain.Campaigns.CampaignPreset>();

    // اجرای آزمایشی ۱۰ نتیجهٔ اول
    public DbSet<LeadPilot.Domain.Acquisition.FirstTenRun> FirstTenRuns => Set<LeadPilot.Domain.Acquisition.FirstTenRun>();
    public DbSet<LeadPilot.Domain.Acquisition.FirstTenRunResult> FirstTenRunResults => Set<LeadPilot.Domain.Acquisition.FirstTenRunResult>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(LeadPilotDbContext).Assembly);
    }
}
