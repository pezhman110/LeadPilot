using LeadPilot.Application.Targets;
using LeadPilot.Domain.Targets;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class TargetRepository(LeadPilotDbContext db) : ITargetRepository
{
    public async Task AddTargetAsync(ProjectTarget t, CancellationToken ct) => await db.ProjectTargets.AddAsync(t, ct);
    public async Task<IReadOnlyList<ProjectTarget>> ListTargetsAsync(Guid projectId, CancellationToken ct) =>
        await db.ProjectTargets.AsNoTracking().Where(x => x.ProjectId == projectId).ToListAsync(ct);
    public Task<ProjectFunnelSettings?> GetFunnelAsync(Guid projectId, CancellationToken ct) =>
        db.FunnelSettings.FirstOrDefaultAsync(x => x.ProjectId == projectId, ct);
    public async Task AddFunnelAsync(ProjectFunnelSettings f, CancellationToken ct) => await db.FunnelSettings.AddAsync(f, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
