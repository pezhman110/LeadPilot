using LeadPilot.Application.Partners;
using LeadPilot.Domain.Partners;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Persistence;

public sealed class PartnerRepository(LeadPilotDbContext db) : IPartnerRepository
{
    public async Task AddAsync(Partner p, CancellationToken ct) => await db.Partners.AddAsync(p, ct);
    public Task<Partner?> GetAsync(Guid id, CancellationToken ct) =>
        db.Partners.FirstOrDefaultAsync(x => x.Id == id, ct);
    public async Task<IReadOnlyList<Partner>> ListAsync(CancellationToken ct) =>
        await db.Partners.AsNoTracking().ToListAsync(ct);
    public async Task AddAgreementAsync(PartnerAgreement a, CancellationToken ct) =>
        await db.PartnerAgreements.AddAsync(a, ct);
    public Task<PartnerAgreement?> GetAgreementAsync(Guid id, CancellationToken ct) =>
        db.PartnerAgreements.FirstOrDefaultAsync(x => x.Id == id, ct);
    public Task SaveChangesAsync(CancellationToken ct) => db.SaveChangesAsync(ct);
}
