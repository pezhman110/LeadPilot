using LeadPilot.Application.Communications;
using LeadPilot.Domain.Communications;

namespace LeadPilot.Infrastructure.Communications;

/// <summary>
/// پایهٔ ابزارِ پیام‌رسانِ آزمایشی. هر ابزار کانال‌های پشتیبانی‌شده‌اش را اعلام می‌کند.
/// نسخهٔ واقعیِ هر کدام با API رسمیِ خودش و کلید (در Key Vault) در build ساخته می‌شود.
/// </summary>
public abstract class TestMessagingProviderBase(MessagingProviderCode code, CommunicationChannel[] channels)
    : IMessagingProvider
{
    private readonly HashSet<CommunicationChannel> _channels = [.. channels];
    public MessagingProviderCode Provider => code;
    public bool Supports(CommunicationChannel channel) => _channels.Contains(channel);
    public Task<ProviderSendResult> SendAsync(ChannelSendRequest request, CancellationToken ct) =>
        Task.FromResult(new ProviderSendResult(true, $"TEST-{code}-{Guid.NewGuid():N}", null));
}

public sealed class ManyChatProvider() : TestMessagingProviderBase(MessagingProviderCode.ManyChat,
    [CommunicationChannel.InstagramDm, CommunicationChannel.MessengerDm, CommunicationChannel.WhatsApp, CommunicationChannel.TelegramDm]);

public sealed class RespondIoProvider() : TestMessagingProviderBase(MessagingProviderCode.RespondIo,
    [CommunicationChannel.InstagramDm, CommunicationChannel.MessengerDm, CommunicationChannel.WhatsApp, CommunicationChannel.TelegramDm, CommunicationChannel.TikTokDm]);

public sealed class WatiProvider() : TestMessagingProviderBase(MessagingProviderCode.Wati,
    [CommunicationChannel.WhatsApp]);

public sealed class WhatsAppCloudProvider() : TestMessagingProviderBase(MessagingProviderCode.WhatsAppCloudApi,
    [CommunicationChannel.WhatsApp]);

public sealed class WhatsAppProProvider() : TestMessagingProviderBase(MessagingProviderCode.WhatsAppBusinessPro,
    [CommunicationChannel.WhatsApp]);

public sealed class ZohoProvider() : TestMessagingProviderBase(MessagingProviderCode.Zoho,
    [CommunicationChannel.Email, CommunicationChannel.WhatsApp]);

public sealed class NovoChatProvider() : TestMessagingProviderBase(MessagingProviderCode.NovoChat,
    [CommunicationChannel.InstagramDm, CommunicationChannel.WhatsApp, CommunicationChannel.TelegramDm]);

public sealed class PabblyProvider() : TestMessagingProviderBase(MessagingProviderCode.Pabbly,
    [CommunicationChannel.WhatsApp, CommunicationChannel.Email]);
