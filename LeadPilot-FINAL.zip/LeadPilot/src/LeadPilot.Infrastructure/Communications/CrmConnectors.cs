using LeadPilot.Application.Communications;
using LeadPilot.Domain.Crm;

namespace LeadPilot.Infrastructure.Communications;

/// <summary>
/// کانکتورِ آزمایشیِ CRM. نسخهٔ واقعی با API رسمیِ HubSpot/Salesforce/… و کلید در build ساخته می‌شود.
/// </summary>
public abstract class TestCrmConnectorBase(CrmProvider provider) : ICrmConnector
{
    public CrmProvider Provider => provider;
    public Task<CrmPushResult> PushOutcomeAsync(CrmPushRequest request, CancellationToken ct) =>
        Task.FromResult(new CrmPushResult(true, $"TEST-{provider}-{Guid.NewGuid():N}", null));
}

public sealed class HubSpotConnector()       : TestCrmConnectorBase(CrmProvider.HubSpot);
public sealed class SalesforceConnector()    : TestCrmConnectorBase(CrmProvider.Salesforce);
public sealed class ZohoConnector()          : TestCrmConnectorBase(CrmProvider.Zoho);
public sealed class PipedriveConnector()     : TestCrmConnectorBase(CrmProvider.Pipedrive);
public sealed class GenericWebhookConnector(): TestCrmConnectorBase(CrmProvider.GenericWebhook);
