using LeadPilot.Application.Communications;
using LeadPilot.Domain.Communications;

namespace LeadPilot.Infrastructure.Communications;

/// <summary>
/// پایهٔ فرستندهٔ آزمایشی. هر کانال کلاسِ اختصاصیِ خودش را دارد (سند: نسخهٔ اختصاصی هر سوشیال).
/// نسخهٔ واقعیِ هر کدام با API رسمیِ همان پلتفرم و کلید در build ساخته و جایگزین می‌شود.
/// این نسخه فقط زیرساخت را تست می‌کند و چیزی واقعاً ارسال نمی‌کند (برچسبِ TEST).
/// </summary>
public abstract class TestChannelSenderBase(CommunicationChannel channel) : IChannelSender
{
    public CommunicationChannel Channel => channel;
    public Task<ChannelSendResult> SendAsync(ChannelSendRequest request, CancellationToken ct) =>
        Task.FromResult(new ChannelSendResult(true, $"TEST-{channel}-{Guid.NewGuid():N}", null));
}

// نسخهٔ اختصاصیِ هر کانال — جای Adapterِ واقعیِ API رسمی.
public sealed class InstagramDmSender()   : TestChannelSenderBase(CommunicationChannel.InstagramDm);
public sealed class WhatsAppSender()      : TestChannelSenderBase(CommunicationChannel.WhatsApp);
public sealed class EmailSender()         : TestChannelSenderBase(CommunicationChannel.Email);
public sealed class SmsSender()           : TestChannelSenderBase(CommunicationChannel.Sms);
public sealed class MessengerDmSender()   : TestChannelSenderBase(CommunicationChannel.MessengerDm);
public sealed class TelegramDmSender()    : TestChannelSenderBase(CommunicationChannel.TelegramDm);
public sealed class TikTokDmSender()      : TestChannelSenderBase(CommunicationChannel.TikTokDm);
