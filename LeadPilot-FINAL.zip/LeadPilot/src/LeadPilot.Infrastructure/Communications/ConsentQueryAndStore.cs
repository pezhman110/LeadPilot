using LeadPilot.Application.Communications;
using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Consent;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Communications;

/// <summary>
/// گیتِ رضایت را از لایهٔ Consent می‌خواند: فقط ProtectedContactPointِ Usable (رضایت آمده) و
/// غیرِ Suppressed قابلِ ارتباط است. نگاشتِ کانالِ ارتباط به کانالِ تماس انجام می‌شود.
/// </summary>
public sealed class ConsentQuery(LeadPilotDbContext db) : IContactConsentQuery
{
    public async Task<ContactConsentSnapshot> GetAsync(Guid contactPointId, CommunicationChannel channel, CancellationToken ct)
    {
        var cp = await db.ContactPoints.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == contactPointId, ct);

        if (cp is null)
            return new ContactConsentSnapshot(ChannelConsentStatus.Unknown, false, false, string.Empty);

        bool suppressed = cp.Visibility == ContactVisibility.Suppressed;
        // Usable یعنی رضایت آمده و آزاد شده؛ در غیر این صورت هنوز Granted نیست.
        var status = cp.Visibility == ContactVisibility.Usable
            ? ChannelConsentStatus.Granted
            : ChannelConsentStatus.Unknown;

        return new ContactConsentSnapshot(status, suppressed, cp.ManagerBlocked, cp.Id.ToString());
    }
}

/// <summary>ذخیرهٔ تلاش‌ها و رکوردهای CRM.</summary>
public sealed class CommunicationStore(LeadPilotDbContext db) : ICommunicationStore
{
    public async Task SaveAttemptAsync(OutreachAttempt attempt, CancellationToken ct)
    {
        db.OutreachAttempts.Add(attempt);
        await db.SaveChangesAsync(ct);
    }

    public async Task SaveCrmSyncAsync(Domain.Crm.CrmSyncRecord record, CancellationToken ct)
    {
        db.CrmSyncRecords.Add(record);
        await db.SaveChangesAsync(ct);
    }
}
