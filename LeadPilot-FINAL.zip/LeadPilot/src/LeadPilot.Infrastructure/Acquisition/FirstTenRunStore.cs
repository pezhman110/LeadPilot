using LeadPilot.Application.Acquisition;
using LeadPilot.Domain.Acquisition;
using LeadPilot.Domain.Consent;
using LeadPilot.Domain.Dedup;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Acquisition;

public sealed class FirstTenRunStore(LeadPilotDbContext db, IContactValueProtector protector)
    : IFirstTenRunStore
{
    public async Task SaveAsync(FirstTenRun run, CancellationToken ct)
    {
        if (!await db.FirstTenRuns.AnyAsync(x => x.Id == run.Id, ct))
            db.FirstTenRuns.Add(run);
        await db.SaveChangesAsync(ct);
    }

    public Task<FirstTenRun?> GetAsync(Guid runId, CancellationToken ct) =>
        db.FirstTenRuns.Include(x => x.Results).FirstOrDefaultAsync(x => x.Id == runId, ct);

    /// <summary>ساختِ ContactPoint با وضعیت Hidden (ManagerOnly)؛ شماره رمزنگاری می‌شود.</summary>
    public async Task<Guid> CreateManagerOnlyContactPointAsync(
        Guid tenantId, Guid projectId, Guid prospectId, ContactType type,
        string rawValue, string sourceCode, CancellationToken ct)
    {
        var channel = type == ContactType.Email ? ContactChannel.Email : ContactChannel.Phone;
        var encrypted = protector.Protect(rawValue);
        var contact = new ProtectedContactPoint(
            prospectId, channel, encrypted,
            provider: sourceCode, lawfulBasis: "FirstTenRun/ManagerOnly", countryScope: "AE",
            tenantId: tenantId, projectId: projectId);
        db.ContactPoints.Add(contact);
        await db.SaveChangesAsync(ct);
        return contact.Id;
    }
}
