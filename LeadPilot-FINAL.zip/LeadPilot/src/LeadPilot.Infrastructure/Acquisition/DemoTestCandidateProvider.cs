using LeadPilot.Application.Acquisition;

namespace LeadPilot.Infrastructure.Acquisition;

/// <summary>
/// منبعِ کاندیدِ نمونه (برای اثباتِ جریان). نسخهٔ واقعی سیگنال‌های واقعیِ پروژه
/// را از منابع مجاز می‌آورد. اینجا چند کاندیدِ ساختگی برای تستِ جریان می‌سازد.
/// </summary>
public sealed class DemoTestCandidateProvider : ITestCandidateProvider
{
    public Task<IReadOnlyList<AcquisitionCandidate>> GetCandidatesAsync(
        Guid tenantId, Guid projectId, bool isCorporateProject, int maximumCandidates, CancellationToken ct)
    {
        int count = Math.Min(maximumCandidates, 30);
        var list = new List<AcquisitionCandidate>();
        for (int i = 0; i < count; i++)
        {
            list.Add(new AcquisitionCandidate(
                ProspectId: Guid.NewGuid(),
                PersonName: isCorporateProject ? null : $"Candidate {i + 1}",
                CompanyName: isCorporateProject ? $"Company {i + 1}" : null,
                CompanyDomain: isCorporateProject ? $"company{i + 1}.ae" : null,
                SourceProfileUrl: $"https://example.com/signal/{i + 1}",
                LanguageCode: "ar", CountryCode: "AE",
                SourceCode: isCorporateProject ? "linkedin_lead_gen" : "instagram_lead_ads",
                SourceReference: $"https://example.com/signal/{i + 1}",
                NeedsPhone: true, NeedsEmail: false));
        }
        return Task.FromResult<IReadOnlyList<AcquisitionCandidate>>(list);
    }
}
