using System.Security.Cryptography;
using System.Text;
using LeadPilot.Application.Acquisition;

namespace LeadPilot.Infrastructure.Acquisition;

/// <summary>
/// رمزنگاریِ AES-256-GCM با کلید از پیکربندی ("Security:ContactEncryptionKey").
/// این مقدار هرگز به‌صورت خام ذخیره نمی‌شود؛ فقط مدیرِ مجاز (با Audit) رمزگشایی می‌کند.
/// </summary>
public sealed class DataProtectionContactValueProtector : IContactValueProtector
{
    private readonly byte[] _key;
    public DataProtectionContactValueProtector(string keyText)
    {
        // کلید ۳۲ بایتی از متنِ پیکربندی مشتق می‌شود.
        _key = SHA256.HashData(Encoding.UTF8.GetBytes(keyText));
    }

    public string Protect(string plaintext)
    {
        var nonce = RandomNumberGenerator.GetBytes(AesGcm.NonceByteSizes.MaxSize);
        var plain = Encoding.UTF8.GetBytes(plaintext);
        var cipher = new byte[plain.Length];
        var tag = new byte[AesGcm.TagByteSizes.MaxSize];
        using var aes = new AesGcm(_key, tag.Length);
        aes.Encrypt(nonce, plain, cipher, tag);
        return $"{Convert.ToBase64String(nonce)}.{Convert.ToBase64String(cipher)}.{Convert.ToBase64String(tag)}";
    }

    public string Unprotect(string ciphertext)
    {
        var parts = ciphertext.Split('.');
        if (parts.Length != 3) throw new FormatException("قالب مقدار رمزشده نامعتبر است.");
        var nonce = Convert.FromBase64String(parts[0]);
        var cipher = Convert.FromBase64String(parts[1]);
        var tag = Convert.FromBase64String(parts[2]);
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(_key, tag.Length);
        aes.Decrypt(nonce, cipher, tag, plain);
        return Encoding.UTF8.GetString(plain);
    }
}
