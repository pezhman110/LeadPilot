using LeadPilot.Application.Acquisition;
using LeadPilot.Domain.Sources;

namespace LeadPilot.Infrastructure.Acquisition;

/// <summary>
/// آبشارِ نمونه: اول «رایگان» تلاش می‌کند، اگر نشد «پولی». نسخهٔ واقعی به
/// Connectorهای واقعی (سایت/سوشیال رایگان → Provider پولی) وصل می‌شود.
/// </summary>
public sealed class DemoEnrichmentCascade : IContactEnrichmentCascade
{
    public Task<EnrichmentOutcome> RunAsync(AcquisitionCandidate candidate, bool isCorporateProject,
        decimal remainingBudgetAed, CancellationToken ct)
    {
        // تلاش رایگان (بدون هزینه) — اغلب موفق.
        bool freeHit = Random.Shared.NextDouble() < 0.7;
        if (freeHit)
        {
            var phone = "+9715" + Random.Shared.Next(10000000, 99999999);
            return Task.FromResult(new EnrichmentOutcome(
                Found: true, RawValue: phone, ContactType: "PHONE",
                SourceCode: candidate.SourceCode, SourceReference: candidate.SourceReference,
                SourceUrl: candidate.SourceProfileUrl,
                Classification: isCorporateProject ? ContactClassification.Corporate : ContactClassification.PersonalSelfSubmitted,
                ConfidenceScore: Random.Shared.Next(85, 100), CostAed: 0m, IsValid: true));
        }

        // تلاش پولی — فقط اگر بودجه باقی است.
        if (remainingBudgetAed >= 2m)
        {
            var phone = "+9715" + Random.Shared.Next(10000000, 99999999);
            return Task.FromResult(new EnrichmentOutcome(
                Found: true, RawValue: phone, ContactType: "PHONE",
                SourceCode: "apollo", SourceReference: "https://apollo.io/contact",
                SourceUrl: "https://apollo.io/contact",
                Classification: ContactClassification.Corporate,
                ConfidenceScore: Random.Shared.Next(80, 95), CostAed: 2m, IsValid: true));
        }

        return Task.FromResult(new EnrichmentOutcome(
            false, null, "PHONE", candidate.SourceCode, candidate.SourceReference,
            null, ContactClassification.Unknown, 0, 0m, false));
    }
}
