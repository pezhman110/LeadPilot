using System.Text.Json;
using LeadPilot.Application.Capacity;
using LeadPilot.Application.Processing;
using LeadPilot.Domain.Capacity;
using LeadPilot.Domain.Processing;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Capacity;

/// <summary>
/// هستهٔ کسری‌محور: هر چرخه، کسریِ لحظه‌ای را نسبت به پیشرفتِ زمانی محاسبه
/// و فقط به‌اندازهٔ کسری Job می‌سازد (Batch کوچک). توقفِ خودکار پس از هدف.
/// </summary>
public sealed class DailyCapacityOrchestrator(
    LeadPilotDbContext db, IProcessingJobRepository jobs, TimeProvider timeProvider)
    : IDailyCapacityOrchestrator
{
    private const int MaximumJobsPerCycle = 250;

    public async Task<CapacityOrchestrationResult> RunCycleAsync(Guid planId, CancellationToken ct)
    {
        var plan = await db.DailyCapacityPlans.Include(x => x.Quotas)
            .SingleOrDefaultAsync(x => x.Id == planId, ct)
            ?? throw new InvalidOperationException("برنامه ظرفیت پیدا نشد.");

        var now = timeProvider.GetUtcNow();

        if (plan.Status == DailyCapacityPlanStatus.Scheduled) plan.Start(now);
        if (plan.Status != DailyCapacityPlanStatus.Running)
            return new CapacityOrchestrationResult(plan.Id, 0, 0, 0, 0, false);

        var windowStart = CreateWindowDateTime(plan.BusinessDate, plan.WindowStartUtc);
        var windowEnd = CreateWindowDateTime(plan.BusinessDate, plan.WindowEndUtc);

        if (now >= windowEnd)
        {
            bool shortage = await HasShortageAsync(plan, windowStart, ct);
            plan.Complete(shortage, now);
            await db.SaveChangesAsync(ct);
            return new CapacityOrchestrationResult(plan.Id, 0, 0, 0, shortage ? 1 : 0, true);
        }
        if (now < windowStart)
            return new CapacityOrchestrationResult(plan.Id, 0, 0, 0, 0, false);

        decimal progress = CalculateWindowProgress(now, windowStart, windowEnd);

        int created = 0, duplicates = 0, completedQuotas = 0, behindQuotas = 0;

        foreach (var quota in plan.Quotas.Where(x => x.IsActive && !x.IsFlexible).OrderByDescending(x => x.Priority))
        {
            int completedContacts = await CountCreatedContactsAsync(plan, quota, windowStart, ct);
            if (completedContacts >= quota.ContactTarget) { completedQuotas++; continue; }

            int expectedByNow = Math.Min(quota.ContactTarget, (int)Math.Ceiling(quota.ContactTarget * progress));
            int shortage = Math.Max(0, expectedByNow - completedContacts);
            if (shortage == 0) continue;

            behindQuotas++;
            int jobsToCreate = Math.Min(shortage, MaximumJobsPerCycle - created);

            for (int i = 0; i < jobsToCreate; i++)
            {
                string slot = $"{plan.BusinessDate:yyyyMMdd}:{quota.Id}:{completedContacts + i + 1}";
                var payload = new CapacitySearchJobPayload(plan.Id, quota.Id, quota.GroupCode, quota.ProjectId, slot);
                var job = new ProcessingJob(
                    ProcessingJobTypes.Search, JsonSerializer.Serialize(payload),
                    idempotencyKey: $"CAPACITY_SEARCH:{plan.Id}:{quota.Id}:{slot}",
                    correlationId: plan.Id.ToString("N"),
                    priority: ToJobPriority(quota.Priority),
                    maximumAttempts: 4, scheduledAtUtc: now, projectId: quota.ProjectId);

                bool wasCreated = await jobs.EnqueueAsync(job, ct);
                if (wasCreated) created++; else duplicates++;
                if (created >= MaximumJobsPerCycle) break;
            }
            if (created >= MaximumJobsPerCycle) break;
        }

        await db.SaveChangesAsync(ct);
        return new CapacityOrchestrationResult(plan.Id, created, duplicates, completedQuotas, behindQuotas, false);
    }

    private async Task<int> CountCreatedContactsAsync(DailyCapacityPlan plan, ProjectDailyQuota quota, DateTimeOffset startUtc, CancellationToken ct)
    {
        var query = db.ContactPoints.AsNoTracking()
            .Where(x => x.TenantId == plan.TenantId && x.CreatedAtUtc >= startUtc);
        if (quota.ProjectId.HasValue) query = query.Where(x => x.ProjectId == quota.ProjectId.Value);
        return await query.CountAsync(ct);
    }

    private async Task<bool> HasShortageAsync(DailyCapacityPlan plan, DateTimeOffset windowStart, CancellationToken ct)
    {
        int total = await db.ContactPoints.AsNoTracking()
            .CountAsync(x => x.TenantId == plan.TenantId && x.CreatedAtUtc >= windowStart, ct);
        return total < plan.TargetContacts;
    }

    private static DateTimeOffset CreateWindowDateTime(DateOnly date, TimeOnly time) =>
        new(date.ToDateTime(time, DateTimeKind.Utc));

    private static decimal CalculateWindowProgress(DateTimeOffset now, DateTimeOffset start, DateTimeOffset end)
    {
        decimal elapsed = (decimal)(now - start).TotalSeconds;
        decimal total = (decimal)(end - start).TotalSeconds;
        return Math.Clamp(elapsed / total, 0, 1);
    }

    private static ProcessingJobPriority ToJobPriority(int priority) => priority switch
    {
        >= 90 => ProcessingJobPriority.Critical,
        >= 70 => ProcessingJobPriority.High,
        >= 40 => ProcessingJobPriority.Normal,
        _ => ProcessingJobPriority.Low
    };
}
