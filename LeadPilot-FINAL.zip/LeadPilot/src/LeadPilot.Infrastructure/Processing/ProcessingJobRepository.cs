using System.Data;
using LeadPilot.Application.Processing;
using LeadPilot.Domain.Processing;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Processing;

/// <summary>
/// برداشتِ امنِ Job با PostgreSQL: FOR UPDATE SKIP LOCKED
/// (معادلِ READPAST سند — دو Worker یک Job را برنمی‌دارند).
/// </summary>
public sealed class ProcessingJobRepository(LeadPilotDbContext db, TimeProvider timeProvider)
    : IProcessingJobRepository
{
    public async Task<bool> EnqueueAsync(ProcessingJob job, CancellationToken ct)
    {
        bool exists = await db.ProcessingJobs.AnyAsync(x => x.IdempotencyKey == job.IdempotencyKey, ct);
        if (exists) return false;

        db.ProcessingJobs.Add(job);
        try
        {
            await db.SaveChangesAsync(ct);
            return true;
        }
        catch (DbUpdateException)
        {
            // ایندکسِ یکتا مرجعِ نهاییِ جلوگیری از تکرار است.
            db.Entry(job).State = EntityState.Detached;
            bool duplicate = await db.ProcessingJobs.AnyAsync(x => x.IdempotencyKey == job.IdempotencyKey, ct);
            if (duplicate) return false;
            throw;
        }
    }

    public async Task<IReadOnlyList<ProcessingJob>> ClaimBatchAsync(
        string workerId, IReadOnlyCollection<string> jobTypes, int batchSize,
        TimeSpan leaseDuration, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(workerId)) throw new ArgumentException("شناسه Worker الزامی است.");
        if (jobTypes.Count == 0) return [];
        if (batchSize is < 1 or > 500) throw new ArgumentOutOfRangeException(nameof(batchSize));

        var now = timeProvider.GetUtcNow();
        var types = jobTypes.ToArray();

        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted, ct);

        // PostgreSQL: FOR UPDATE SKIP LOCKED — ردیفِ قفل‌شدهٔ Worker دیگر رد می‌شود.
        var pending = (int)ProcessingJobStatus.Pending;
        var retry = (int)ProcessingJobStatus.RetryScheduled;
        var processing = (int)ProcessingJobStatus.Processing;

        var jobs = await db.ProcessingJobs
            .FromSql($"""
                SELECT * FROM "ProcessingJobs"
                WHERE (
                    ( "Status" IN ({pending}, {retry}) AND "ScheduledAtUtc" <= {now} )
                    OR
                    ( "Status" = {processing} AND "LockedUntilUtc" IS NOT NULL AND "LockedUntilUtc" <= {now} )
                )
                AND "JobType" = ANY({types})
                ORDER BY "Priority" DESC, "ScheduledAtUtc" ASC, "CreatedAtUtc" ASC
                LIMIT {batchSize}
                FOR UPDATE SKIP LOCKED
                """)
            .ToArrayAsync(ct);

        foreach (var job in jobs) job.Claim(workerId, now, leaseDuration);

        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return jobs;
    }

    public async Task RenewLeaseAsync(Guid jobId, string workerId, TimeSpan leaseDuration, CancellationToken ct)
    {
        var job = await FindOwnedJobAsync(jobId, workerId, ct);
        job.RenewLease(workerId, timeProvider.GetUtcNow(), leaseDuration);
        await db.SaveChangesAsync(ct);
    }

    public async Task CompleteAsync(Guid jobId, string workerId, CancellationToken ct)
    {
        var job = await FindOwnedJobAsync(jobId, workerId, ct);
        job.Complete(workerId, timeProvider.GetUtcNow());
        await db.SaveChangesAsync(ct);
    }

    public async Task FailAsync(Guid jobId, string workerId, string errorCode, string error, bool isTransient, CancellationToken ct)
    {
        var job = await FindOwnedJobAsync(jobId, workerId, ct);
        var now = timeProvider.GetUtcNow();
        if (!isTransient) job.SendToDeadLetter(workerId, errorCode, error, now);
        else job.Fail(workerId, errorCode, error, now, now.Add(RetryPolicy.CalculateDelay(job.AttemptCount)));
        await db.SaveChangesAsync(ct);
    }

    public async Task<ProcessingSummary> GetSummaryAsync(CancellationToken ct)
    {
        var now = timeProvider.GetUtcNow();
        var startOfDay = new DateTimeOffset(now.Date, TimeSpan.Zero);
        int pending = await db.ProcessingJobs.CountAsync(x => x.Status == ProcessingJobStatus.Pending, ct);
        int processing = await db.ProcessingJobs.CountAsync(x => x.Status == ProcessingJobStatus.Processing, ct);
        int retry = await db.ProcessingJobs.CountAsync(x => x.Status == ProcessingJobStatus.RetryScheduled, ct);
        int completedToday = await db.ProcessingJobs.CountAsync(x => x.Status == ProcessingJobStatus.Completed && x.CompletedAtUtc >= startOfDay, ct);
        int deadLetter = await db.ProcessingJobs.CountAsync(x => x.Status == ProcessingJobStatus.DeadLetter, ct);
        var oldest = await db.ProcessingJobs.Where(x => x.Status == ProcessingJobStatus.Pending)
            .OrderBy(x => x.ScheduledAtUtc).Select(x => (DateTimeOffset?)x.ScheduledAtUtc).FirstOrDefaultAsync(ct);
        int oldestAge = oldest.HasValue ? (int)Math.Max(0, (now - oldest.Value).TotalSeconds) : 0;
        return new ProcessingSummary(pending, processing, retry, completedToday, deadLetter, oldestAge);
    }

    private async Task<ProcessingJob> FindOwnedJobAsync(Guid jobId, string workerId, CancellationToken ct) =>
        await db.ProcessingJobs.SingleOrDefaultAsync(x => x.Id == jobId && x.LockedBy == workerId, ct)
            ?? throw new InvalidOperationException("Job پیدا نشد یا متعلق به این Worker نیست.");
}
