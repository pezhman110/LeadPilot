using LeadPilot.Application.Abstractions;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace LeadPilot.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("MainDatabase")
            ?? throw new InvalidOperationException("رشته اتصال MainDatabase تعریف نشده است.");

        services.AddDbContext<LeadPilotDbContext>(options =>
        {
            options.UseNpgsql(connectionString, npgsql =>
            {
                npgsql.EnableRetryOnFailure(
                    maxRetryCount: 5,
                    maxRetryDelay: TimeSpan.FromSeconds(10),
                    errorCodesToAdd: null);
            });
        });

        services.AddScoped<IProjectRepository, ProjectRepository>();
        services.AddScoped<ISearchRunRepository, SearchRunRepository>();
        services.AddScoped<ISignalRepository, SignalRepository>();

        // فاز ۲ — Connectorها (فعلاً فقط Demo؛ Connector واقعی با قرارداد اضافه می‌شود)
        services.AddScoped<ISignalConnector, Connectors.DemoConnector>();

        // ماژول‌ها — repositoryها
        services.AddScoped<Application.Consent.IConsentRepository, Persistence.ConsentRepository>();
        services.AddScoped<Application.Partners.IPartnerRepository, Persistence.PartnerRepository>();
        services.AddScoped<Application.Targets.ITargetRepository, Persistence.TargetRepository>();
        services.AddScoped<Application.Content.IContentRepository, Persistence.ContentRepository>();
        services.AddScoped<Application.Content.IAiContentBrain, Content.StubAiContentBrain>();
        services.AddScoped<Application.Dedup.IDeduplicationRepository, Persistence.DeduplicationRepository>();
        // صف پردازشِ پایدار
        services.AddSingleton(TimeProvider.System);
        services.AddScoped<Application.Processing.IProcessingJobRepository, Processing.ProcessingJobRepository>();
        services.AddScoped<Application.Processing.IProcessingJobHandler, ContactDiscovery.ContactDiscoveryJobHandler>();
        // برنامه‌ریز ظرفیت
        services.AddScoped<Application.Capacity.IDailyCapacityOrchestrator, Capacity.DailyCapacityOrchestrator>();
        services.AddSingleton<Application.Capacity.CapacityCalculator>();
        // اصلاح امنیتی: دسترسی مدیر با Audit
        services.AddScoped<Application.ContactAccess.IContactAccessAudit, ContactAccess.ContactAccessAudit>();
        services.AddScoped<Application.ContactAccess.ContactAccessService>();
        // شرط ۱۰ شماره اول
        services.AddSingleton<Application.Connections.FirstResultsQualifier>();

        // Connection Center واقعی (سند): Secret Store + Health Service + Adapterها.
        // Secret فقط از Secret Store خوانده می‌شود؛ در دیتابیس فقط SecretReference است.
        services.AddScoped<Application.Security.ISecretStore, Security.ConfigurationSecretStore>();
        services.AddScoped<Application.Connections.IConnectorHealthService, Connections.ConnectorHealthService>();
        // Adapterهای واقعی اینجا ثبت می‌شوند؛ فعلاً فقط Adapter آزمایشی برای تستِ زیرساخت.
        services.AddScoped<Application.Connections.IConnectorAdapter, Connections.TestConnectorAdapter>();

        // ماژول ارتباطات (Communications) — کنسولِ کارشناسِ فروش، فقط مخاطبانِ دارای رضایت.
        services.AddScoped<Application.Communications.IContactConsentQuery, Communications.ConsentQuery>();
        services.AddScoped<Application.Communications.ICommunicationStore, Communications.CommunicationStore>();
        services.AddScoped<Application.Communications.CommunicationsService>();
        services.AddSingleton<Application.Communications.InstagramCommentAutomationService>();
        services.AddScoped<Application.Communications.CrmSyncService>();
        // فرستندهٔ اختصاصیِ هر کانال (نسخهٔ TEST؛ واقعی با API رسمی در build).
        services.AddScoped<Application.Communications.IChannelSender, Communications.InstagramDmSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.WhatsAppSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.EmailSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.SmsSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.MessengerDmSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.TelegramDmSender>();
        services.AddScoped<Application.Communications.IChannelSender, Communications.TikTokDmSender>();
        // کانکتورهای CRM (نسخهٔ TEST؛ واقعی با API رسمی در build).
        services.AddScoped<Application.Communications.ICrmConnector, Communications.HubSpotConnector>();
        services.AddScoped<Application.Communications.ICrmConnector, Communications.SalesforceConnector>();
        services.AddScoped<Application.Communications.ICrmConnector, Communications.ZohoConnector>();
        services.AddScoped<Application.Communications.ICrmConnector, Communications.PipedriveConnector>();
        services.AddScoped<Application.Communications.ICrmConnector, Communications.GenericWebhookConnector>();

        // فروشنده‌ها: تخصیصِ انحصاری + بازیابی بر اساسِ ویژگی
        services.AddScoped<Application.Agents.IAgentAssignmentStore, Agents.AgentAssignmentStore>();
        services.AddScoped<Application.Agents.AgentAssignmentService>();
        // Failover ابزارهای پیام‌رسان (نسخهٔ TEST؛ واقعی با API رسمی در build)
        services.AddScoped<Application.Communications.ProviderFailoverRouter>();

        // موتور مسیریابی کانال + هویت + Suppression سراسری + نقش‌محور
        services.AddSingleton<Application.Communications.ChannelRoutingEngine>();
        services.AddSingleton<Application.Identity.IdentityResolutionService>();
        services.AddScoped<Application.Suppression.IGlobalSuppressionStore, Suppression.GlobalSuppressionStore>();
        services.AddScoped<Application.Suppression.GlobalSuppressionService>();

        // جذب: قرنطینه (گاردِ داده و کشف، ثابت/خالص‌اند و DI لازم ندارند)
        services.AddSingleton<Application.Discovery.QuarantineService>();
        services.AddSingleton<Application.Discovery.EnrichmentGovernanceService>();

        // ورود CSV/CRM
        services.AddScoped<Application.Imports.IImportProspectResolver, Imports.DeterministicImportProspectResolver>();
        services.AddScoped<Application.Imports.IImportContactSink, Imports.ImportContactSink>();
        services.AddScoped<Application.Imports.ContactImportService>();

        // انجمن‌ها و فروم‌ها
        services.AddSingleton<Application.Community.IntentScoringEngine>();
        services.AddSingleton<Application.Community.OpportunityIngestionService>();

        // Launcher کمپین
        services.AddSingleton<Application.Campaigns.CampaignLauncherService>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.ManyChatProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.RespondIoProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.WatiProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.WhatsAppCloudProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.WhatsAppProProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.ZohoProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.NovoChatProvider>();
        services.AddScoped<Application.Communications.IMessagingProvider, Communications.PabblyProvider>();

        // موتور «۱۰ نتیجهٔ اول» (Start Test Run)
        services.AddSingleton<Application.Acquisition.IContactValueProtector>(_ =>
            new Acquisition.DataProtectionContactValueProtector(
                configuration["Security:ContactEncryptionKey"] ?? "dev-only-change-me"));
        services.AddScoped<Application.Acquisition.ITestCandidateProvider, Acquisition.DemoTestCandidateProvider>();
        services.AddScoped<Application.Acquisition.IContactEnrichmentCascade, Acquisition.DemoEnrichmentCascade>();
        services.AddScoped<Application.Acquisition.IFirstTenRunStore, Acquisition.FirstTenRunStore>();
        services.AddScoped<Application.Acquisition.IFirstTenRunService, Application.Acquisition.FirstTenRunService>();
        services.AddScoped(sp =>
        {
            // کلیدِ HMAC از پیکربندی؛ در نبودِ آن یک کلیدِ توسعه.
            var cfg = sp.GetService<Microsoft.Extensions.Configuration.IConfiguration>();
            var keyText = cfg?["Security:ContactHashKey"] ?? "dev-only-contact-hash-key-change-me";
            var key = System.Text.Encoding.UTF8.GetBytes(keyText);
            return new Application.Dedup.DeduplicationService(
                sp.GetRequiredService<Application.Dedup.IDeduplicationRepository>(), key);
        });
        return services;
    }
}
