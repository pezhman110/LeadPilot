using LeadPilot.Application.Connections;
using LeadPilot.Domain.Connections;

namespace LeadPilot.Infrastructure.Connections;

/// <summary>
/// Adapterِ آزمایشی فقط برای تستِ زیرساختِ Connection Center (سند بخش ۶).
/// نتیجه‌اش باید با برچسبِ TEST نمایش داده شود. Adapterهای واقعی بعداً با API رسمی اضافه می‌شوند.
/// </summary>
public sealed class TestConnectorAdapter : IConnectorAdapter
{
    public string ConnectorCode => "TEST_SOURCE";

    public async Task<ConnectorTestResult> TestAsync(ConnectorRuntimeConfiguration configuration, CancellationToken cancellationToken)
    {
        var startedAt = DateTimeOffset.UtcNow;
        await Task.Delay(TimeSpan.FromMilliseconds(100), cancellationToken);
        return new ConnectorTestResult(ConnectorStatus.Healthy, DateTimeOffset.UtcNow - startedAt,
            10_000, null, "اتصال آزمایشی سالم است.");
    }
}
