using System.Diagnostics;
using LeadPilot.Application.Connections;
using LeadPilot.Application.Security;
using LeadPilot.Domain.Connections;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Connections;

/// <summary>
/// سرویسِ مرکزیِ Health Check (سند بخش ۵). کارِ واقعی:
///  • Secret را از Secret Store می‌خواند (نه از دیتابیس)،
///  • Adapterِ واقعی را با Timeout آزمایش می‌کند،
///  • نتیجه + تاریخچه را ذخیره می‌کند،
///  • گیتِ آمادگیِ شروع را محاسبه می‌کند (اتصالِ حیاتیِ خراب → شروع ممنوع).
/// </summary>
public sealed class ConnectorHealthService : IConnectorHealthService
{
    private readonly LeadPilotDbContext _db;
    private readonly ISecretStore _secretStore;
    private readonly IReadOnlyDictionary<string, IConnectorAdapter> _adapters;
    private readonly TimeProvider _timeProvider;

    public ConnectorHealthService(
        LeadPilotDbContext db, ISecretStore secretStore,
        IEnumerable<IConnectorAdapter> adapters, TimeProvider timeProvider)
    {
        _db = db;
        _secretStore = secretStore;
        _timeProvider = timeProvider;
        _adapters = adapters.ToDictionary(x => x.ConnectorCode, StringComparer.OrdinalIgnoreCase);
    }

    public async Task<ConnectorHealthResponse> TestAsync(Guid connectorId, CancellationToken cancellationToken)
    {
        var connector = await _db.ConnectorDefinitions
            .SingleOrDefaultAsync(x => x.Id == connectorId, cancellationToken)
            ?? throw new InvalidOperationException("اتصال پیدا نشد.");

        var now = _timeProvider.GetUtcNow();

        if (!connector.IsEnabled)
            return Map(connector, ConnectorStatus.Disabled, TimeSpan.Zero, null, "DISABLED", "اتصال غیرفعال است.", now);

        if (!_adapters.TryGetValue(connector.Code, out var adapter))
            return await SaveResultAsync(connector, ConnectorStatus.Unavailable, TimeSpan.Zero, null,
                "ADAPTER_NOT_REGISTERED", "Adapter این اتصال در برنامه ثبت نشده است.", now, cancellationToken);

        connector.MarkTesting(now);
        await _db.SaveChangesAsync(cancellationToken);

        string? secret = null;
        if (!string.IsNullOrWhiteSpace(connector.SecretReference))
        {
            secret = await _secretStore.GetAsync(connector.SecretReference, cancellationToken);
            if (string.IsNullOrWhiteSpace(secret))
                return await SaveResultAsync(connector, ConnectorStatus.AuthenticationFailed, TimeSpan.Zero, null,
                    "SECRET_NOT_FOUND", "Secret موردنیاز پیدا نشد.", now, cancellationToken);
        }

        var configuration = new ConnectorRuntimeConfiguration(
            connector.Code, connector.BaseUrl, secret,
            connector.TimeoutSeconds, connector.RequestsPerMinute, connector.MaximumConcurrency);

        ConnectorTestResult result;
        var stopwatch = Stopwatch.StartNew();
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(connector.TimeoutSeconds));
            result = await adapter.TestAsync(configuration, timeout.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            result = new ConnectorTestResult(ConnectorStatus.Unavailable, stopwatch.Elapsed, null,
                "TIMEOUT", "زمان آزمایش اتصال پایان یافت.");
        }
        catch (Exception exception)
        {
            result = new ConnectorTestResult(ConnectorStatus.Unavailable, stopwatch.Elapsed, null,
                "CONNECTION_TEST_FAILED", exception.Message);
        }
        stopwatch.Stop();

        var latency = result.Latency == TimeSpan.Zero ? stopwatch.Elapsed : result.Latency;
        return await SaveResultAsync(connector, result.Status, latency, result.RemainingDailyQuota,
            result.ErrorCode, result.Message, _timeProvider.GetUtcNow(), cancellationToken);
    }

    public async Task<IReadOnlyList<ConnectorHealthResponse>> TestAllAsync(Guid tenantId, CancellationToken cancellationToken)
    {
        var connectorIds = await _db.ConnectorDefinitions.AsNoTracking()
            .Where(x => x.TenantId == tenantId && x.IsEnabled)
            .OrderBy(x => x.ExecutionOrder)
            .Select(x => x.Id)
            .ToArrayAsync(cancellationToken);

        var results = new List<ConnectorHealthResponse>();
        // ترتیبی اجرا می‌شود تا از فشار ناگهانی جلوگیری شود.
        foreach (var connectorId in connectorIds)
            results.Add(await TestAsync(connectorId, cancellationToken));
        return results;
    }

    public async Task<StartupReadinessResult> CheckStartupReadinessAsync(Guid tenantId, CancellationToken cancellationToken)
    {
        var snapshots = await _db.ConnectorDefinitions.AsNoTracking()
            .Where(x => x.TenantId == tenantId && x.IsEnabled)
            .Select(x => new ConnectorReadinessSnapshot(x.Code, x.Category, x.Status, x.IsCritical))
            .ToArrayAsync(cancellationToken);

        return StartupReadinessCalculator.Compute(snapshots);
    }

    private async Task<ConnectorHealthResponse> SaveResultAsync(
        ConnectorDefinition connector, ConnectorStatus status, TimeSpan latency,
        int? remainingQuota, string? errorCode, string? message,
        DateTimeOffset checkedAtUtc, CancellationToken cancellationToken)
    {
        connector.RecordHealth(status, message, remainingQuota, checkedAtUtc);
        _db.ConnectorHealthChecks.Add(new ConnectorHealthCheck(
            connector.Id, status, Math.Max(0, (long)latency.TotalMilliseconds),
            remainingQuota, errorCode, message, checkedAtUtc));
        await _db.SaveChangesAsync(cancellationToken);
        return Map(connector, status, latency, remainingQuota, errorCode, message, checkedAtUtc);
    }

    private static ConnectorHealthResponse Map(
        ConnectorDefinition connector, ConnectorStatus status, TimeSpan latency,
        int? remainingQuota, string? errorCode, string? message, DateTimeOffset checkedAtUtc)
    {
        bool usable = status is ConnectorStatus.Healthy or ConnectorStatus.Degraded;
        return new ConnectorHealthResponse(
            connector.Id, connector.Code, connector.DisplayName, status.ToString(),
            usable, connector.IsCritical, Math.Max(0, (long)latency.TotalMilliseconds),
            remainingQuota, errorCode, message, checkedAtUtc);
    }
}
