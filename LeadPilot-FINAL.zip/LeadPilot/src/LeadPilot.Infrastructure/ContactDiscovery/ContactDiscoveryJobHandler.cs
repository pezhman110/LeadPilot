using LeadPilot.Application.Processing;
using LeadPilot.Domain.Processing;
using Microsoft.Extensions.Logging;

namespace LeadPilot.Infrastructure.ContactDiscovery;

/// <summary>
/// Handlerِ آبشارِ دریافت تلفن/ایمیل. نسخهٔ فعلی ساختار را اجرا می‌کند؛
/// نسخهٔ واقعی به SourceCascadePlanner + Connectorهای واقعی + Dedup وصل می‌شود.
/// Payload فقط شناسه‌هاست (نه شماره/ایمیل خام).
/// </summary>
public sealed class ContactDiscoveryJobHandler(ILogger<ContactDiscoveryJobHandler> logger)
    : IProcessingJobHandler
{
    public string JobType => ProcessingJobTypes.ContactDiscovery;

    public Task<ProcessingJobExecutionResult> ExecuteAsync(ProcessingJob job, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(job.Payload))
            return Task.FromResult(ProcessingJobExecutionResult.PermanentFailure("EMPTY_PAYLOAD", "Payload خالی است."));

        // اینجا در نسخهٔ واقعی: آبشار منبع (رایگان→پولی) + dedup + ثبت ContactPoint (Hidden).
        logger.LogInformation("ContactDiscovery job {JobId} processed (structural).", job.Id);
        return Task.FromResult(ProcessingJobExecutionResult.Success());
    }
}
