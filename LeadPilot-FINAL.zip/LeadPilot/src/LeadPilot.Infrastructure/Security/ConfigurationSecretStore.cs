using LeadPilot.Application.Security;
using Microsoft.Extensions.Configuration;

namespace LeadPilot.Infrastructure.Security;

/// <summary>
/// پیاده‌سازیِ Development برای Secret Store — از پیکربندی (User Secrets/ENV) می‌خواند.
/// در Production با Key Vault/Vault/Docker Secrets جایگزین می‌شود. مطابق سند بخش ۴.
/// </summary>
public sealed class ConfigurationSecretStore(IConfiguration configuration) : ISecretStore
{
    public Task<string?> GetAsync(string secretReference, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(secretReference))
            return Task.FromResult<string?>(null);
        return Task.FromResult(configuration[$"ConnectorSecrets:{secretReference}"]);
    }
}
