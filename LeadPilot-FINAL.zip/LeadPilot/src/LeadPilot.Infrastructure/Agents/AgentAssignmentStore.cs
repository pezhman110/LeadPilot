using LeadPilot.Application.Agents;
using LeadPilot.Domain.Agents;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LeadPilot.Infrastructure.Agents;

public sealed class AgentAssignmentStore(LeadPilotDbContext db) : IAgentAssignmentStore
{
    public Task<AgentProfile?> GetAgentAsync(Guid agentProfileId, CancellationToken ct) =>
        db.AgentProfiles.FirstOrDefaultAsync(x => x.Id == agentProfileId, ct);

    public Task<ContactAssignment?> GetActiveAssignmentAsync(Guid contactPointId, CancellationToken ct) =>
        db.ContactAssignments.FirstOrDefaultAsync(
            x => x.ContactPointId == contactPointId && x.Status == AssignmentStatus.Active, ct);

    public async Task AddAssignmentAsync(ContactAssignment assignment, CancellationToken ct) =>
        await db.ContactAssignments.AddAsync(assignment, ct);

    public Task SaveAsync(CancellationToken ct) => db.SaveChangesAsync(ct);

    public async Task<IReadOnlyList<ContactAssignment>> QueryAgentAssignmentsAsync(
        Guid agentProfileId, bool? hasAccount, bool? hasEmail, bool? hasPhone, bool activeOnly, CancellationToken ct)
    {
        var q = db.ContactAssignments.AsNoTracking().Where(x => x.AgentProfileId == agentProfileId);
        if (activeOnly) q = q.Where(x => x.Status == AssignmentStatus.Active);
        if (hasAccount == true) q = q.Where(x => x.HasAccount);
        if (hasEmail == true) q = q.Where(x => x.HasEmail);
        if (hasPhone == true) q = q.Where(x => x.HasPhone);
        return await q.OrderByDescending(x => x.AssignedAtUtc).Take(500).ToListAsync(ct);
    }
}
