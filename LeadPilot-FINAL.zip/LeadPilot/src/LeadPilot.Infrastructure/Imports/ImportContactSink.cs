using System.Security.Cryptography;
using System.Text;
using LeadPilot.Application.Acquisition;
using LeadPilot.Application.Imports;
using LeadPilot.Domain.Consent;
using LeadPilot.Domain.Dedup;
using LeadPilot.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LeadPilot.Infrastructure.Imports;

/// <summary>
/// ذخیرهٔ امنِ مقدارِ تماسِ واردشده: استانداردسازی → Hash (dedup از ContactRecords) →
/// رمزنگاری (AES) → ProtectedContactPoint با وضعیتِ Hidden/ManagerOnly.
/// مقدارِ خام هرگز در جدولِ Import یا Log ذخیره نمی‌شود.
/// </summary>
public sealed class ImportContactSink(
    LeadPilotDbContext db, IContactValueProtector protector, IConfiguration configuration) : IImportContactSink
{
    public async Task<bool> StoreManagerOnlyAsync(ImportContactCommand c, CancellationToken ct)
    {
        var type = c.ChannelKind == "Phone" ? ContactType.Phone : ContactType.Email;
        var keyText = configuration["Security:ContactHashKey"] ?? "dev-only-change-me";
        var key = SHA256.HashData(Encoding.UTF8.GetBytes(keyText));
        string hash = ContactNormalizer.Hash(type, c.RawValue, key);

        // dedup: قید یکتاییِ TenantId+ContactType+ContactHash. اگر هست → تکراری.
        bool exists = await db.ContactRecords
            .AnyAsync(x => x.TenantId == c.TenantId && x.ContactHash == hash, ct);
        if (exists) return false;

        db.ContactRecords.Add(new ContactRecord(c.TenantId, type, hash, c.SourceReference));

        // مقدارِ خام فقط رمزنگاری‌شده در ProtectedContactPoint (Hidden/ManagerOnly).
        var channel = type == ContactType.Phone ? ContactChannel.Phone : ContactChannel.Email;
        string encrypted = protector.Protect(c.RawValue);
        db.ContactPoints.Add(new ProtectedContactPoint(c.ProspectId, channel, encrypted,
            provider: "import", lawfulBasis: c.LawfulSourceReference, countryScope: "AE",
            tenantId: c.TenantId, projectId: c.ProjectId));

        await db.SaveChangesAsync(ct);
        return true;
    }
}

/// <summary>Resolver پیش‌فرض: یک ProspectId قطعی از (TenantId+ProjectId+ExternalId) می‌سازد.</summary>
public sealed class DeterministicImportProspectResolver : IImportProspectResolver
{
    public Task<Guid> ResolveAsync(ImportProspectRequest r, CancellationToken ct)
    {
        var seed = $"{r.TenantId}:{r.ProjectId}:{r.ExternalId}";
        var bytes = MD5.HashData(Encoding.UTF8.GetBytes(seed));
        return Task.FromResult(new Guid(bytes));
    }
}
