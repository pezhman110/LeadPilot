#!/usr/bin/env bash
# نصبِ کلیک اول (سند بخش ۹): API + Web + Workers + SQL + Redis + Broker + Scheduler + Monitoring
set -e
echo "LeadPilot — کلیک اول: نصب زیرساخت"
cd "$(dirname "$0")"
docker compose -f docker-compose.production.yml up -d --build
echo ""
echo "✓ نصب کامل شد. حالا کلیک دوم را اجرا کنید (Wizard اتصالات):"
echo "  به http://localhost:8080/setup بروید و اتصالات را سبز کنید."
