using LeadPilot.Application.Sources;
using LeadPilot.Domain.Sources;
using Xunit;

namespace LeadPilot.Tests;

public class SourceTests
{
    [Fact] // کاتالوگ هر ۱۴ گروه را پوشش می‌دهد
    public void Catalog_covers_all_14_groups()
    {
        var groups = SourceCatalog.Seed().Select(s => s.Group).Distinct().ToList();
        Assert.Equal(14, groups.Count);
    }

    [Fact] // Google Maps / About فقط شرکتی است
    public void Maps_and_directories_are_corporate_only()
    {
        var seed = SourceCatalog.Seed();
        Assert.True(seed.First(s => s.Code == "google_places").CorporateOnly);
        Assert.True(seed.First(s => s.Code == "company_registry").CorporateOnly);
        // فرم و CRM شخصی مجازند
        Assert.False(seed.First(s => s.Code == "crm").CorporateOnly);
    }

    [Fact] // پروژهٔ شخصی: منابعِ فقط-شرکتی حذف می‌شوند
    public void Personal_project_excludes_corporate_only()
    {
        var planner = new SourceCascadePlanner(SourceCatalog.Seed());
        var plan = planner.PlanFor(projectIsPersonal: true);
        Assert.DoesNotContain(plan, s => s.Code == "google_places");
        Assert.DoesNotContain(plan, s => s.Code == "apollo"); // Provider شرکتی
        Assert.Contains(plan, s => s.Code == "crm");
    }

    [Fact] // آبشار: ارزان/سریع قبل از گران/کند
    public void Cascade_orders_cheap_and_fast_first()
    {
        var planner = new SourceCascadePlanner(SourceCatalog.Seed());
        var plan = planner.PlanFor(projectIsPersonal: false);
        // اولین منبع باید رتبهٔ سرعت ۱ باشد (دادهٔ خودِ مجموعه)
        Assert.Equal(1, plan[0].SpeedRank);
        // منابعِ سوشیال/انجمن (رتبهٔ ۶) باید انتها باشند
        Assert.Equal(6, plan[^1].SpeedRank);
    }

    [Fact] // کامنت/انجمن SignalSource است، نه PhoneSource
    public void Forums_are_signal_sources()
    {
        var seed = SourceCatalog.Seed();
        Assert.Equal(SourceRole.SignalSource, seed.First(s => s.Code == "reddit_api").Role);
        Assert.Equal(SourceRole.SignalSource, seed.First(s => s.Code == "linkedin_public").Role);
    }

    [Fact] // ترتیب اختصاصیِ سالن: اول CRM/رزرو، شامل سوشیالِ سالن
    public void Salon_order_starts_with_owned_data()
    {
        var planner = new SourceCascadePlanner(SourceCatalog.Seed());
        var plan = planner.PlanForProjectKind(ProjectSourceKind.SalonHomeService);
        Assert.Equal("crm", plan[0].Code);
        Assert.Contains(plan, s => s.Code == "instagram_lead_ads");
        Assert.DoesNotContain(plan, s => s.Code == "google_places"); // شخصی → بدون مپ
    }

    [Fact] // رتبهٔ سرعت خارج از ۱..۶ رد می‌شود
    public void Invalid_speed_rank_rejected() =>
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            new SourceDefinition("x", "X", SourceGroup.A_OwnedData, SourceRole.PhoneSource, 9, false, false));
}
