using System.Text;
using LeadPilot.Application.Imports;
using LeadPilot.Domain.Imports;
using LeadPilot.Domain.Lifecycle;
using Xunit;

namespace LeadPilot.Tests;

file sealed class FakeResolver : IImportProspectResolver
{
    public Task<Guid> ResolveAsync(ImportProspectRequest r, CancellationToken ct) =>
        Task.FromResult(Guid.NewGuid());
}
file sealed class FakeSink : IImportContactSink
{
    public readonly HashSet<string> Seen = new();
    public int Stored;
    public Task<bool> StoreManagerOnlyAsync(ImportContactCommand c, CancellationToken ct)
    {
        var key = c.ChannelKind + ":" + c.RawValue;
        if (!Seen.Add(key)) return Task.FromResult(false); // تکراری
        Stored++; return Task.FromResult(true);
    }
}

public class ContactImportServiceTests
{
    private static Stream Csv(string body) => new MemoryStream(Encoding.UTF8.GetBytes(body));
    private static ContactImportBatch Batch() =>
        new(Guid.NewGuid(), Guid.NewGuid(), "P02", "f.csv", "CRM", "mgr", DateTimeOffset.UtcNow);

    private const string Header =
        "external_id,project_code,full_name,company_name,phone,email,country_code,language_code,source_reference,lawful_source_reference\n";

    [Fact] // سطر معتبر وارد می‌شود
    public async Task Valid_row_imported()
    {
        var sink = new FakeSink();
        var svc = new ContactImportService(new FakeResolver(), sink);
        var csv = Header + "C1,P02,Ali,LLC,+971501234567,ali@x.ae,AE,fa,CRM-1,CONTRACT-1\n";
        var b = await svc.ImportAsync(Batch(), Csv(csv), default);
        Assert.Equal(1, b.TotalRows);
        Assert.Equal(1, b.ImportedRows);
        Assert.True(sink.Stored >= 1);
    }

    [Fact] // سطر بدونِ phone و email نامعتبر است
    public async Task Row_without_contact_invalid()
    {
        var svc = new ContactImportService(new FakeResolver(), new FakeSink());
        var csv = Header + "C2,P02,Sara,Co,,,AE,en,CRM-2,CONTRACT-1\n";
        var b = await svc.ImportAsync(Batch(), Csv(csv), default);
        Assert.Equal(1, b.InvalidRows);
        Assert.Equal(ContactImportBatchStatus.CompletedWithErrors, b.Status);
    }

    [Fact] // سطر بدونِ lawful_source_reference نامعتبر است
    public async Task Missing_lawful_ref_invalid()
    {
        var svc = new ContactImportService(new FakeResolver(), new FakeSink());
        var csv = Header + "C3,P02,X,Y,+971500000000,,AE,fa,CRM-3,\n";
        var b = await svc.ImportAsync(Batch(), Csv(csv), default);
        Assert.Equal(1, b.InvalidRows);
    }

    [Fact] // شمارهٔ تکراری دوباره ذخیره نمی‌شود (dedup)
    public async Task Duplicate_phone_not_stored_twice()
    {
        var sink = new FakeSink();
        var svc = new ContactImportService(new FakeResolver(), sink);
        var csv = Header
            + "C4,P02,A,Co,+971509999999,,AE,fa,CRM-4,CONTRACT-1\n"
            + "C5,P02,B,Co,+971509999999,,AE,fa,CRM-5,CONTRACT-1\n";
        await svc.ImportAsync(Batch(), Csv(csv), default);
        Assert.Equal(1, sink.Stored); // فقط یک‌بار
    }
}

public class DataLifecycleTests
{
    [Fact] // سیاست نگهداری انقضا را درست حساب می‌کند
    public void Retention_expiry()
    {
        var p = new DataRetentionPolicy(Guid.NewGuid(), "phone", 30, "contract");
        var collected = new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
        Assert.True(p.IsExpired(collected, collected.AddDays(31)));
        Assert.False(p.IsExpired(collected, collected.AddDays(10)));
    }

    [Fact] // چرخهٔ درخواستِ حذف
    public void Deletion_lifecycle()
    {
        var d = new DeletionRequest(Guid.NewGuid(), Guid.NewGuid(), "user", "erasure");
        Assert.Equal(DeletionRequestStatus.Received, d.Status);
        d.MarkVerifying(); d.Approve(); d.MarkExecuted();
        Assert.Equal(DeletionRequestStatus.Executed, d.Status);
        Assert.NotNull(d.ExecutedAtUtc);
    }

    [Fact] // ConsentEvidence بدونِ مرجع رد می‌شود
    public void Consent_evidence_requires_ref() =>
        Assert.Throws<ArgumentException>(() =>
            new ConsentEvidence(Guid.NewGuid(), Guid.NewGuid(), "wa", "double-optin", "", DateTimeOffset.UtcNow));
}
