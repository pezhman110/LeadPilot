using LeadPilot.Application.Connections;
using LeadPilot.Domain.Connections;
using Xunit;

namespace LeadPilot.Tests;

public class ConnectorDefinitionTests
{
    private static ConnectorDefinition New(bool critical = true) =>
        new(Guid.NewGuid(), "test_source", "Test Source",
            ConnectorCategory.Search, ConnectorCostLevel.Free, 10, critical, true, true);

    [Fact] // ساخت: کد به upper، وضعیت اولیه NotConfigured و غیرفعال
    public void New_connector_starts_notconfigured_disabled()
    {
        var c = New();
        Assert.Equal("TEST_SOURCE", c.Code);
        Assert.Equal(ConnectorStatus.NotConfigured, c.Status);
        Assert.False(c.IsEnabled);
    }

    [Fact] // پیکربندی فقط SecretReference را نگه می‌دارد، نه مقدار Secret
    public void Configure_keeps_reference_only()
    {
        var c = New();
        c.Configure("https://api.x", "SEARCH_PRIMARY", 2, 60, 30, 3, 5m, 1000, DateTimeOffset.UtcNow);
        Assert.Equal("SEARCH_PRIMARY", c.SecretReference);
        Assert.Equal("https://api.x", c.BaseUrl);
        // هیچ فیلدی برای مقدارِ کلید وجود ندارد → کلید هرگز ذخیره نمی‌شود.
    }

    [Fact] // تنظیمات نامعتبر رد می‌شود
    public void Configure_rejects_invalid()
    {
        var c = New();
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            c.Configure(null, null, 0, 60, 30, 3, null, null, DateTimeOffset.UtcNow));
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            c.Configure(null, null, 2, 60, 400, 3, null, null, DateTimeOffset.UtcNow));
    }

    [Fact] // MarkTesting روی اتصالِ غیرفعال ممنوع است
    public void MarkTesting_requires_enabled()
    {
        var c = New();
        Assert.Throws<InvalidOperationException>(() => c.MarkTesting(DateTimeOffset.UtcNow));
        c.Enable(DateTimeOffset.UtcNow);
        c.MarkTesting(DateTimeOffset.UtcNow);
        Assert.Equal(ConnectorStatus.Testing, c.Status);
    }

    [Fact] // RecordHealth نمی‌تواند Testing باشد؛ روی غیرفعال Disabled می‌شود
    public void RecordHealth_rules()
    {
        var c = New();
        c.Enable(DateTimeOffset.UtcNow);
        Assert.Throws<ArgumentException>(() =>
            c.RecordHealth(ConnectorStatus.Testing, "x", null, DateTimeOffset.UtcNow));
        c.RecordHealth(ConnectorStatus.Healthy, "ok", 100, DateTimeOffset.UtcNow);
        Assert.Equal(ConnectorStatus.Healthy, c.Status);
        Assert.Equal(100, c.RemainingDailyQuota);

        c.Disable(DateTimeOffset.UtcNow);
        c.RecordHealth(ConnectorStatus.Healthy, "ok", 100, DateTimeOffset.UtcNow);
        Assert.Equal(ConnectorStatus.Disabled, c.Status); // غیرفعال، هر نتیجه‌ای Disabled می‌ماند
    }
}

public class StartupReadinessTests
{
    private static ConnectorReadinessSnapshot S(string code, ConnectorCategory cat, ConnectorStatus st, bool crit) =>
        new(code, cat, st, crit);

    [Fact] // اتصال حیاتیِ خراب → شروع مسدود
    public void Critical_failed_blocks()
    {
        var r = StartupReadinessCalculator.Compute(
        [
            S("DB", ConnectorCategory.Storage, ConnectorStatus.AuthenticationFailed, true),
            S("SEARCH", ConnectorCategory.Search, ConnectorStatus.Healthy, false)
        ]);
        Assert.False(r.CanStart);
        Assert.Contains("DB", r.BlockingConnectors);
    }

    [Fact] // غیرحیاتیِ خراب فقط Warning است، شروع مجاز
    public void Noncritical_failed_only_warns()
    {
        var r = StartupReadinessCalculator.Compute(
        [
            S("SEARCH", ConnectorCategory.Search, ConnectorStatus.Healthy, true),
            S("TIKTOK", ConnectorCategory.LeadForm, ConnectorStatus.RateLimited, false)
        ]);
        Assert.True(r.CanStart);
        Assert.NotEmpty(r.Warnings);
    }

    [Fact] // بدونِ منبعِ کشفِ سالم → مسدود (۱۰ نتیجه غیرممکن)
    public void No_discovery_source_blocks()
    {
        var r = StartupReadinessCalculator.Compute(
        [
            S("MSG", ConnectorCategory.Messaging, ConnectorStatus.Healthy, true)
        ]);
        Assert.False(r.CanStart);
        Assert.Contains("NO_USABLE_DISCOVERY_SOURCE", r.BlockingConnectors);
    }

    [Fact] // همه سالم + منبعِ کشف → آماده
    public void Ready_when_healthy_with_source()
    {
        var r = StartupReadinessCalculator.Compute(
        [
            S("CRM", ConnectorCategory.InternalData, ConnectorStatus.Healthy, true),
            S("SEARCH", ConnectorCategory.Search, ConnectorStatus.Degraded, false)
        ]);
        Assert.True(r.CanStart);
        Assert.Equal(1, r.Healthy);
        Assert.Equal(1, r.Degraded);
    }
}

public class ConnectorTestResultTests
{
    [Fact] // Healthy/Degraded قابل‌استفاده‌اند؛ بقیه نه
    public void IsUsable_semantics()
    {
        Assert.True(new ConnectorTestResult(ConnectorStatus.Healthy, TimeSpan.Zero, null, null, null).IsUsable);
        Assert.True(new ConnectorTestResult(ConnectorStatus.Degraded, TimeSpan.Zero, null, null, null).IsUsable);
        Assert.False(new ConnectorTestResult(ConnectorStatus.RateLimited, TimeSpan.Zero, null, null, null).IsUsable);
        Assert.False(new ConnectorTestResult(ConnectorStatus.Unavailable, TimeSpan.Zero, null, null, null).IsUsable);
    }
}

// شرط ۱۰ شماره اول (بدون تغییر — همچنان معتبر)
public class FirstResultsQualifierTests
{
    private static ContactQualificationInput Good() => new(
        IsNormalized: true, Hash: "h1", IsDuplicate: false, SourceReference: "linkedin_lead_gen",
        Classification: ContactClass.PersonalSelfSubmitted, ProjectRuleSatisfied: true,
        MaskedValue: "+9715****4567", ContactRecordCreated: true,
        IsAiFabricated: false, IsSuppressed: false, IsExtractedFromDisallowedPersonalSource: false);

    [Fact] public void Fully_valid_qualifies() =>
        Assert.True(new FirstResultsQualifier().Qualify(Good()).IsQualified);

    [Fact] public void Ai_fabricated_disqualified() =>
        Assert.False(new FirstResultsQualifier().Qualify(Good() with { IsAiFabricated = true }).IsQualified);

    [Fact] public void No_source_disqualified() =>
        Assert.False(new FirstResultsQualifier().Qualify(Good() with { SourceReference = "" }).IsQualified);

    [Fact] public void Duplicate_disqualified() =>
        Assert.False(new FirstResultsQualifier().Qualify(Good() with { IsDuplicate = true }).IsQualified);

    [Fact] public void Corporate_for_personal_disqualified() =>
        Assert.False(new FirstResultsQualifier().Qualify(Good() with { ProjectRuleSatisfied = false }).IsQualified);
}
