using LeadPilot.Application.Targets;
using LeadPilot.Domain.Targets;
using Xunit;

namespace LeadPilot.Tests;

public class TargetTests
{
    [Fact] // هدف بدون نام/مقدار نامعتبر رد می‌شود
    public void Target_requires_name_and_positive_value()
    {
        Assert.Throws<ArgumentException>(() => new ProjectTarget(
            Guid.NewGuid(), "", TargetMetricType.ClosedDeals, TargetPeriodType.Daily, 5, DateTimeOffset.UtcNow, null));
        Assert.Throws<ArgumentOutOfRangeException>(() => new ProjectTarget(
            Guid.NewGuid(), "T", TargetMetricType.ClosedDeals, TargetPeriodType.Daily, 0, DateTimeOffset.UtcNow, null));
    }

    [Fact] // درصد تحقق و باقی‌مانده درست است
    public void Achievement_and_remaining_are_correct()
    {
        var t = new ProjectTarget(Guid.NewGuid(), "GMV", TargetMetricType.GrossMerchandiseValueAed,
            TargetPeriodType.Daily, 1_000_000m, DateTimeOffset.UtcNow, null);
        t.SetActualValue(250_000m);
        Assert.Equal(25m, t.AchievementPercentage);
        Assert.Equal(750_000m, t.RemainingValue);
    }

    [Fact] // محاسبهٔ معکوس قیف مطابق نمونهٔ سند
    public void Reverse_funnel_matches_doc_example()
    {
        // نمونهٔ سند: GMV روزانه ۱M، متوسط معامله ۲۰۰k → ۵ معامله
        // نرخ بستن ۱۰٪ → ۵۰ لید، رضایت→واجد ۲۵٪ → ۲۰۰ رضایت،
        // تماس→رضایت ۲۰٪ → ۱۰۰۰ تماس، سیگنال→تماس ۲۰٪ → ۵۰۰۰ سیگنال
        var f = new ProjectFunnelSettings(Guid.NewGuid())
        {
            AverageDealValueAed = 200_000m,
            ProposalToCloseRate = 0.10m,
            ConsentToQualifiedRate = 0.25m,
            ContactToConsentRate = 0.20m,
            SignalToContactRate = 0.20m
        };
        var plan = new ReverseFunnelCalculator().Calculate(1_000_000m, f);
        Assert.Equal(5, plan.RequiredDeals);
        Assert.Equal(50, plan.RequiredQualifiedLeads);
        Assert.Equal(200, plan.RequiredConsents);
        Assert.Equal(1000, plan.RequiredContacts);
        Assert.Equal(5000, plan.RequiredSignals);
    }

    [Fact] // پیشنهاد متقابل نیازمند مقصد است
    public void CrossProjectOffer_requires_target()
    {
        Assert.Throws<ArgumentException>(() => new CrossProjectOffer(
            "salon-service-done", "P04", "", "10% off", 0, 7, true));
        var o = new CrossProjectOffer("salon-service-done", "P04", "P09", "10% off product", 0, 7, true);
        Assert.True(o.RequiresConsent);
        Assert.Equal("P09", o.TargetProjectCode);
    }

    [Fact] // Attribution از پرداخت دوباره جلوگیری می‌کند
    public void Attribution_tracks_payment()
    {
        var a = new AttributionRecord(Guid.NewGuid(), AttributionModel.PrimaryPlusAssist);
        a.SetSources("influencer", "freelancer", "CLUB123");
        Assert.False(a.CommissionPaid);
        a.MarkCommissionPaid();
        Assert.True(a.CommissionPaid);
    }
}
