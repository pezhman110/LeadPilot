using LeadPilot.Application.Communications;
using LeadPilot.Domain.Communications;
using Xunit;

namespace LeadPilot.Tests;

file sealed class P(MessagingProviderCode code, CommunicationChannel ch, bool ok) : IMessagingProvider
{
    public MessagingProviderCode Provider => code;
    public bool Supports(CommunicationChannel c) => c == ch;
    public Task<ProviderSendResult> SendAsync(ChannelSendRequest r, CancellationToken ct) =>
        Task.FromResult(ok ? new ProviderSendResult(true, "id-"+code, null) : new ProviderSendResult(false, null, "failed"));
}

public class ProviderFailoverTests
{
    private static ChannelProviderConfig Cfg(MessagingProviderCode p, int prio) =>
        new(Guid.NewGuid(), CommunicationChannel.WhatsApp, p, prio);
    private static ChannelSendRequest Req() =>
        new(Guid.NewGuid(), Guid.NewGuid(), "dest", "hi", OutreachMode.Manual);

    [Fact] // اولین ابزارِ موفق استفاده می‌شود
    public async Task Uses_first_successful()
    {
        var router = new ProviderFailoverRouter([
            new P(MessagingProviderCode.Wati, CommunicationChannel.WhatsApp, true),
            new P(MessagingProviderCode.WhatsAppCloudApi, CommunicationChannel.WhatsApp, true)]);
        var outcome = await router.SendAsync(CommunicationChannel.WhatsApp,
            [Cfg(MessagingProviderCode.Wati, 1), Cfg(MessagingProviderCode.WhatsAppCloudApi, 2)], Req(), default);
        Assert.True(outcome.Ok);
        Assert.Equal(MessagingProviderCode.Wati, outcome.UsedProvider);
    }

    [Fact] // وقتی اولی ناموفق شد، به دومی Failover می‌شود
    public async Task Falls_over_to_next()
    {
        var router = new ProviderFailoverRouter([
            new P(MessagingProviderCode.Wati, CommunicationChannel.WhatsApp, false),
            new P(MessagingProviderCode.WhatsAppCloudApi, CommunicationChannel.WhatsApp, true)]);
        var outcome = await router.SendAsync(CommunicationChannel.WhatsApp,
            [Cfg(MessagingProviderCode.Wati, 1), Cfg(MessagingProviderCode.WhatsAppCloudApi, 2)], Req(), default);
        Assert.True(outcome.Ok);
        Assert.Equal(MessagingProviderCode.WhatsAppCloudApi, outcome.UsedProvider);
        Assert.Equal(2, outcome.Attempts.Count);
    }

    [Fact] // اگر همه ناموفق شدند → ناموفق با فهرست تلاش‌ها
    public async Task All_fail_returns_failure()
    {
        var router = new ProviderFailoverRouter([
            new P(MessagingProviderCode.Wati, CommunicationChannel.WhatsApp, false)]);
        var outcome = await router.SendAsync(CommunicationChannel.WhatsApp,
            [Cfg(MessagingProviderCode.Wati, 1)], Req(), default);
        Assert.False(outcome.Ok);
        Assert.Null(outcome.UsedProvider);
    }
}
