using LeadPilot.Application.Capacity;
using LeadPilot.Domain.Capacity;
using Xunit;

namespace LeadPilot.Tests;

public class CapacityTests
{
    private static DailyCapacityPlan NewPlan() => new(
        Guid.NewGuid(), new DateOnly(2026, 7, 15),
        new TimeOnly(4, 0), new TimeOnly(8, 0),
        targetSignals: 15000, targetContacts: 3000, targetConsents: 1150,
        designCapacity: 5000, createdBy: "manager");

    [Fact] // پنجرهٔ نامعتبر رد می‌شود
    public void Invalid_window_rejected()
    {
        Assert.Throws<ArgumentException>(() => new DailyCapacityPlan(
            Guid.NewGuid(), new DateOnly(2026, 7, 15),
            new TimeOnly(8, 0), new TimeOnly(4, 0), 15000, 3000, 1150, 5000, "m"));
    }

    [Fact] // جمع سهمیه بیشتر از ظرفیت طراحی → Schedule رد می‌شود
    public void Schedule_rejects_over_capacity()
    {
        var plan = NewPlan();
        plan.AddQuota("INVEST", null, 4000, 500, 100, false);
        plan.AddQuota("SALON", null, 2000, 250, 80, false); // جمع ۶۰۰۰ > ۵۰۰۰
        Assert.Throws<InvalidOperationException>(() => plan.Schedule());
    }

    [Fact] // چرخهٔ عمر: Draft → Scheduled → Running → Paused
    public void Lifecycle_transitions()
    {
        var plan = NewPlan();
        plan.AddQuota("INVEST_BUY_SELL", null, 1000, 500, 100, false);
        Assert.Equal(DailyCapacityPlanStatus.Draft, plan.Status);
        plan.Schedule();
        Assert.Equal(DailyCapacityPlanStatus.Scheduled, plan.Status);
        plan.Start(DateTimeOffset.UtcNow);
        Assert.Equal(DailyCapacityPlanStatus.Running, plan.Status);
        plan.Pause();
        Assert.Equal(DailyCapacityPlanStatus.Paused, plan.Status);
    }

    [Fact] // سهمیه فقط در پیش‌نویس قابل تغییر است
    public void Quota_only_editable_in_draft()
    {
        var plan = NewPlan();
        plan.AddQuota("INVEST", null, 1000, 500, 100, false);
        plan.Schedule();
        Assert.Throws<InvalidOperationException>(() => plan.AddQuota("X", null, 10, 5, 50, false));
    }

    [Fact] // محاسبهٔ ظرفیت با نرخ‌های واقعی (مثال سند)
    public void Calculator_matches_doc_example()
    {
        var calc = new CapacityCalculator();
        // رضایت ۵۰۰، نرخ رضایت ۵۰٪، تکرار ۱۰٪، دریافت ۲۵٪، حاشیه ۱۵٪
        var r = calc.Calculate(500, 0.50m, 0.25m, 0.10m, 0.15m);
        Assert.Equal(1000, r.ValidContactsRequired);          // 500/0.5
        Assert.Equal(1112, r.ContactsIncludingDuplicateAllowance); // 1000/0.9 → ceil
        // 1112/0.25 = 4448 → *1.15 = 5116 → ceil
        Assert.True(r.SignalsRequired is >= 5100 and <= 5130);
    }

    [Fact] // نرخ نامعتبر رد می‌شود
    public void Calculator_rejects_invalid_rate()
    {
        var calc = new CapacityCalculator();
        Assert.Throws<ArgumentOutOfRangeException>(() => calc.Calculate(500, 0m, 0.25m, 0.1m, 0.15m));
        Assert.Throws<ArgumentOutOfRangeException>(() => calc.Calculate(500, 0.5m, 0.25m, 1.0m, 0.15m));
    }

    [Fact] // SignalTarget از نرخ دریافت محاسبه می‌شود
    public void Quota_signal_target_from_rate()
    {
        var plan = NewPlan();
        plan.AddQuota("INVEST", null, 1000, 500, 100, false);
        var quota = plan.Quotas.First();
        quota.SetSignalTarget(0.25m); // 1000/0.25 = 4000
        Assert.Equal(4000, quota.SignalTarget);
    }

    [Fact] // پایان با کمبود
    public void Complete_with_shortage()
    {
        var plan = NewPlan();
        plan.AddQuota("INVEST", null, 1000, 500, 100, false);
        plan.Schedule(); plan.Start(DateTimeOffset.UtcNow);
        plan.Complete(hasShortage: true, DateTimeOffset.UtcNow);
        Assert.Equal(DailyCapacityPlanStatus.CompletedWithShortage, plan.Status);
    }
}
