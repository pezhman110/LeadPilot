using LeadPilot.Application.Agents;
using LeadPilot.Domain.Agents;
using Xunit;

namespace LeadPilot.Tests;

file sealed class FakeStore : IAgentAssignmentStore
{
    public AgentProfile? Agent;
    public readonly List<ContactAssignment> Items = [];
    public Task<AgentProfile?> GetAgentAsync(Guid id, CancellationToken ct) => Task.FromResult(Agent);
    public Task<ContactAssignment?> GetActiveAssignmentAsync(Guid cpId, CancellationToken ct) =>
        Task.FromResult(Items.FirstOrDefault(x => x.ContactPointId == cpId && x.Status == AssignmentStatus.Active));
    public Task AddAssignmentAsync(ContactAssignment a, CancellationToken ct) { Items.Add(a); return Task.CompletedTask; }
    public Task SaveAsync(CancellationToken ct) => Task.CompletedTask;
    public Task<IReadOnlyList<ContactAssignment>> QueryAgentAssignmentsAsync(
        Guid agentId, bool? acc, bool? em, bool? ph, bool activeOnly, CancellationToken ct)
    {
        var q = Items.Where(x => x.AgentProfileId == agentId);
        if (activeOnly) q = q.Where(x => x.Status == AssignmentStatus.Active);
        q = q.Where(x => x.MatchesAttribute(acc, em, ph));
        return Task.FromResult<IReadOnlyList<ContactAssignment>>(q.ToList());
    }
}

public class AgentAssignmentTests
{
    private static AgentProfile Agent(params string[] services)
    {
        var a = new AgentProfile(Guid.NewGuid(), Guid.NewGuid(), "فروشنده ۱", 100, false, true);
        foreach (var s in services) a.AllowService(s);
        return a;
    }

    [Fact] // تخصیص موفق وقتی خدمت در حیطهٔ فروشنده است
    public async Task Assign_ok_when_service_matches()
    {
        var store = new FakeStore { Agent = Agent("SALON") };
        var svc = new AgentAssignmentService(store);
        var r = await svc.AssignAsync(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), store.Agent.Id,
            "SALON", true, false, true, default);
        Assert.True(r.Ok);
        Assert.Single(store.Items);
    }

    [Fact] // خدمتِ خارج از حیطه → رد
    public async Task Assign_rejected_when_service_not_handled()
    {
        var store = new FakeStore { Agent = Agent("SALON") };
        var r = await new AgentAssignmentService(store).AssignAsync(Guid.NewGuid(), Guid.NewGuid(),
            Guid.NewGuid(), store.Agent.Id, "INVESTMENT", true, false, true, default);
        Assert.False(r.Ok);
    }

    [Fact] // قفلِ انحصاری: شمارهٔ تخصیص‌یافته به فروشندهٔ دیگر → رد (یک شماره دو جا نرود)
    public async Task Exclusive_lock_blocks_second_agent()
    {
        var cpId = Guid.NewGuid();
        var agent1 = Agent("SALON");
        var store = new FakeStore { Agent = agent1 };
        var svc = new AgentAssignmentService(store);
        await svc.AssignAsync(Guid.NewGuid(), cpId, Guid.NewGuid(), agent1.Id, "SALON", true, false, true, default);

        // فروشندهٔ دوم همان شماره را می‌خواهد
        var agent2 = Agent("SALON");
        store.Agent = agent2;
        var r = await svc.AssignAsync(Guid.NewGuid(), cpId, Guid.NewGuid(), agent2.Id, "SALON", true, false, true, default);
        Assert.False(r.Ok);
        Assert.Contains("فروشندهٔ دیگری", r.Reason);
    }

    [Fact] // بازیابیِ بانک بر اساسِ ویژگی «دارای ایمیل»
    public async Task Retrieve_bank_by_attribute()
    {
        var agent = Agent("SALON");
        var store = new FakeStore { Agent = agent };
        var svc = new AgentAssignmentService(store);
        await svc.AssignAsync(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), agent.Id, "SALON", true, true,  false, default);
        await svc.AssignAsync(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), agent.Id, "SALON", true, false, true,  default);

        var withEmail = await svc.RetrieveBankAsync(agent.Id, null, hasEmail: true, null, true, default);
        Assert.Single(withEmail);
    }

    [Fact] // پس از ارسال به CRM، تخصیص آزاد و قفل برداشته می‌شود
    public async Task Release_after_crm_frees_lock()
    {
        var cpId = Guid.NewGuid();
        var agent = Agent("SALON");
        var store = new FakeStore { Agent = agent };
        var svc = new AgentAssignmentService(store);
        await svc.AssignAsync(Guid.NewGuid(), cpId, Guid.NewGuid(), agent.Id, "SALON", true, false, true, default);
        await svc.ReleaseAfterCrmAsync(cpId, "hs-123", default);
        Assert.Equal(AssignmentStatus.Released, store.Items[0].Status);
        Assert.Null(store.Items[0].ActiveContactKey);
    }
}
