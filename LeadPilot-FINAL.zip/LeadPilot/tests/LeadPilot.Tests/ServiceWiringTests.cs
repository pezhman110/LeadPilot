using LeadPilot.Application.Consent;
using LeadPilot.Application.Partners;
using LeadPilot.Application.Targets;
using LeadPilot.Domain.Consent;
using LeadPilot.Domain.Partners;
using LeadPilot.Domain.Targets;
using Xunit;

namespace LeadPilot.Tests;

// مخزن‌های در-حافظه برای تستِ سرویس‌ها (بدون دیتابیس).
file sealed class InMemConsentRepo : IConsentRepository
{
    private readonly List<ProtectedContactPoint> _c = [];
    private readonly List<InvitationJourney> _j = [];
    public Task AddContactAsync(ProtectedContactPoint cp, CancellationToken ct) { _c.Add(cp); return Task.CompletedTask; }
    public Task<ProtectedContactPoint?> GetContactAsync(Guid id, CancellationToken ct) => Task.FromResult(_c.FirstOrDefault(x => x.Id == id));
    public Task<IReadOnlyList<ProtectedContactPoint>> ListByProspectAsync(Guid p, CancellationToken ct) => Task.FromResult<IReadOnlyList<ProtectedContactPoint>>(_c.Where(x => x.ProspectId == p).ToList());
    public Task AddJourneyAsync(InvitationJourney j, CancellationToken ct) { _j.Add(j); return Task.CompletedTask; }
    public Task<InvitationJourney?> GetJourneyAsync(Guid id, CancellationToken ct) => Task.FromResult(_j.FirstOrDefault(x => x.Id == id));
    public Task SaveChangesAsync(CancellationToken ct) => Task.CompletedTask;
}

file sealed class InMemPartnerRepo : IPartnerRepository
{
    private readonly List<Partner> _p = [];
    private readonly List<PartnerAgreement> _a = [];
    public Task AddAsync(Partner p, CancellationToken ct) { _p.Add(p); return Task.CompletedTask; }
    public Task<Partner?> GetAsync(Guid id, CancellationToken ct) => Task.FromResult(_p.FirstOrDefault(x => x.Id == id));
    public Task<IReadOnlyList<Partner>> ListAsync(CancellationToken ct) => Task.FromResult<IReadOnlyList<Partner>>(_p);
    public Task AddAgreementAsync(PartnerAgreement a, CancellationToken ct) { _a.Add(a); return Task.CompletedTask; }
    public Task<PartnerAgreement?> GetAgreementAsync(Guid id, CancellationToken ct) => Task.FromResult(_a.FirstOrDefault(x => x.Id == id));
    public Task SaveChangesAsync(CancellationToken ct) => Task.CompletedTask;
}

file sealed class InMemTargetRepo : ITargetRepository
{
    private readonly List<ProjectTarget> _t = [];
    private ProjectFunnelSettings? _f;
    public Task AddTargetAsync(ProjectTarget t, CancellationToken ct) { _t.Add(t); return Task.CompletedTask; }
    public Task<IReadOnlyList<ProjectTarget>> ListTargetsAsync(Guid p, CancellationToken ct) => Task.FromResult<IReadOnlyList<ProjectTarget>>(_t.Where(x => x.ProjectId == p).ToList());
    public Task<ProjectFunnelSettings?> GetFunnelAsync(Guid p, CancellationToken ct) => Task.FromResult(_f);
    public Task AddFunnelAsync(ProjectFunnelSettings f, CancellationToken ct) { _f = f; return Task.CompletedTask; }
    public Task SaveChangesAsync(CancellationToken ct) => Task.CompletedTask;
}

public class ServiceWiringTests
{
    [Fact] // رضایت → آزادسازیِ خودکارِ همهٔ تماس‌ها
    public async Task Consent_flow_auto_releases_contacts()
    {
        var svc = new ConsentService(new InMemConsentRepo());
        var prospect = Guid.NewGuid();
        var c = await svc.AddContactAsync(new CreateContactRequest(prospect, 0, "enc", "partner", "basis", "AE"), default);
        Assert.Equal("Hidden", c.Visibility);
        var j = await svc.InviteAsync(new InviteRequest(prospect, 95, "WhatsApp"), default);
        await svc.ConsentAsync(j.Id, default);
        var after = await svc.ListContactsAsync(prospect, default);
        Assert.Equal("Usable", after[0].Visibility);
    }

    [Fact] // پیشنهاد تخصیص از سرویس با طبقه‌بندیِ مبلغ
    public async Task Partner_recommend_by_amount_tier()
    {
        var svc = new PartnerService(new InMemPartnerRepo());
        await svc.CreateAsync(new CreatePartnerRequest("Sara", 1, 92, ["ar", "en"], ["investment"]), default);
        var recs = await svc.RecommendAsync(new RecommendRequest("ar", (int)DealKind.Investment, 40_000_000m, 95), default);
        Assert.NotEmpty(recs);
        Assert.Equal("Sara", recs[0].PartnerName);
    }

    [Fact] // موتور هدف: محاسبهٔ معکوس قیف از سرویس
    public async Task Target_plan_computes_required_signals()
    {
        var svc = new TargetService(new InMemTargetRepo());
        var plan = await svc.PlanAsync(new PlanRequest(Guid.NewGuid(), 1_000_000m), default);
        Assert.True(plan.RequiredSignals > 0);
        Assert.True(plan.RequiredSignals >= plan.RequiredContacts);
    }
}
