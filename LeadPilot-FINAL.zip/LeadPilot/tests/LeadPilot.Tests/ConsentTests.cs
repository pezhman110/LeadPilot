using LeadPilot.Domain.Consent;
using Xunit;

namespace LeadPilot.Tests;

public class ConsentTests
{
    [Fact] // ProtectedContactPoint بدون Provider/LawfulBasis ساخته نمی‌شود
    public void ContactPoint_requires_provider_and_basis()
    {
        Assert.Throws<ArgumentException>(() =>
            new ProtectedContactPoint(Guid.NewGuid(), ContactChannel.Phone, "enc", "", "basis", "AE"));
        Assert.Throws<ArgumentException>(() =>
            new ProtectedContactPoint(Guid.NewGuid(), ContactChannel.Phone, "enc", "prov", "", "AE"));
    }

    [Fact] // شماره تا رضایت Hidden است، بعد Usable می‌شود
    public void Contact_is_hidden_until_consent()
    {
        var cp = new ProtectedContactPoint(Guid.NewGuid(), ContactChannel.Phone, "enc", "partner", "contract", "AE");
        Assert.Equal(ContactVisibility.Hidden, cp.Visibility);
        cp.MakeUsableAfterConsent();
        Assert.Equal(ContactVisibility.Usable, cp.Visibility);
    }

    [Fact] // رد → Suppressed
    public void Declined_contact_is_suppressed()
    {
        var cp = new ProtectedContactPoint(Guid.NewGuid(), ContactChannel.Phone, "enc", "partner", "contract", "AE");
        cp.Suppress();
        Assert.Equal(ContactVisibility.Suppressed, cp.Visibility);
    }

    [Fact] // رضایت + نمرهٔ بالا → کارشناس انسانی
    public void High_score_consent_routes_to_human()
    {
        var j = new InvitationJourney(Guid.NewGuid(), score: 96, channel: "WhatsApp");
        var route = j.Consented(salesThreshold: 90);
        Assert.Equal(ProspectRoute.HumanExpert, route);
        Assert.Equal(InvitationStatus.Consented, j.State);
    }

    [Fact] // رضایت + نمرهٔ پایین‌تر → AI
    public void Low_score_consent_routes_to_ai()
    {
        var j = new InvitationJourney(Guid.NewGuid(), score: 72, channel: "WhatsApp");
        Assert.Equal(ProspectRoute.AiNurture, j.Consented(90));
    }

    [Fact] // بی‌جواب تا سقف، سپس Exhausted
    public void NoResponse_stops_after_max_followups()
    {
        var j = new InvitationJourney(Guid.NewGuid(), 80, "Email");
        j.NoResponse(); // 1
        j.NoResponse(); // 2
        j.NoResponse(); // exceeds max (2)
        Assert.Equal(InvitationStatus.Exhausted, j.State);
    }
}

public class ManagerOverrideTests
{
    private static LeadPilot.Domain.Consent.ProtectedContactPoint New() =>
        new(Guid.NewGuid(), LeadPilot.Domain.Consent.ContactChannel.Phone, "enc", "partner", "contract", "AE");

    [Fact] // رضایت → آزادسازیِ خودکار
    public void Consent_auto_releases()
    {
        var cp = New();
        cp.MakeUsableAfterConsent();
        Assert.Equal(LeadPilot.Domain.Consent.ContactVisibility.Usable, cp.Visibility);
    }

    [Fact] // اختیارِ جلوگیریِ مدیر بر آزادسازیِ خودکار مقدم است
    public void Manager_block_prevents_auto_release()
    {
        var cp = New();
        cp.ManagerBlock("بررسی دستی");
        cp.MakeUsableAfterConsent(); // نباید آزاد شود
        Assert.Equal(LeadPilot.Domain.Consent.ContactVisibility.Hidden, cp.Visibility);
        Assert.True(cp.ManagerBlocked);
    }

    [Fact] // رفع جلوگیری، سپس آزادسازی
    public void Manager_unblock_allows_release()
    {
        var cp = New();
        cp.ManagerBlock("hold");
        cp.ManagerUnblock();
        cp.MakeUsableAfterConsent();
        Assert.Equal(LeadPilot.Domain.Consent.ContactVisibility.Usable, cp.Visibility);
    }
}
