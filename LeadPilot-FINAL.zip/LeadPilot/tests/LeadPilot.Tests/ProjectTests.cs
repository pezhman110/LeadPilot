using LeadPilot.Domain.Projects;
using Xunit;

namespace LeadPilot.Tests;

public class ProjectTests
{
    private static Project Valid() => new(
        persianName: "پروژه آزمایشی",
        englishName: "Test Project",
        customerType: CustomerType.Personal,
        minimumBudgetAed: 500_000m,
        minimumSignalScore: 75,
        managerReviewScore: 90,
        salesAssignmentScore: 97);

    [Fact] // 1) پروژه بدون نام ساخته نشود
    public void Rejects_empty_persian_name() =>
        Assert.Throws<ArgumentException>(() => new Project(
            "", "Test", CustomerType.Personal, null, 10, 20, 30));

    [Fact] // 2) امتیاز بالاتر از ۱۰۰ رد شود
    public void Rejects_score_above_100() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new Project(
            "نام", "Name", CustomerType.Personal, null, 10, 20, 101));

    [Fact] // 3) امتیاز فروش کمتر از امتیاز مدیر رد شود
    public void Rejects_sales_below_manager() =>
        Assert.Throws<ArgumentException>(() => new Project(
            "نام", "Name", CustomerType.Personal, null, 50, 90, 80));

    [Fact] // 4) زبان ناشناخته رد شود
    public void Rejects_unknown_language()
    {
        var p = Valid();
        Assert.Throws<ArgumentException>(() => p.AddLanguage("zz"));
    }

    [Fact] // 5) زبان تکراری دوباره ذخیره نشود
    public void Duplicate_language_is_ignored()
    {
        var p = Valid();
        p.AddLanguage("fa");
        p.AddLanguage("FA");
        Assert.Single(p.Languages);
    }

    [Fact] // 6) پروژه بدون جغرافیا فعال نشود
    public void Cannot_activate_without_geography()
    {
        var p = Valid();
        Assert.Throws<InvalidOperationException>(() => p.Activate());
    }

    [Fact] // 7) پروژهٔ فعال قابل توقف باشد
    public void Active_project_can_pause()
    {
        var p = Valid();
        p.AddGeography("AE", "Dubai", 1);
        p.Activate();
        p.Pause();
        Assert.Equal(ProjectStatus.Paused, p.Status);
    }

    [Fact] // 8) پروژهٔ Draft مستقیماً Pause نشود
    public void Draft_cannot_pause_directly()
    {
        var p = Valid();
        Assert.Throws<InvalidOperationException>(() => p.Pause());
    }

    [Fact] // فعال‌سازی درست وضعیت را Active می‌کند
    public void Activate_with_geography_succeeds()
    {
        var p = Valid();
        p.AddGeography("AE", "Dubai", 1);
        p.Activate();
        Assert.Equal(ProjectStatus.Active, p.Status);
    }

    [Fact] // پروژهٔ متوقف دوباره فعال می‌شود
    public void Paused_can_reactivate()
    {
        var p = Valid();
        p.AddGeography("AE", "Dubai", 1);
        p.Activate();
        p.Pause();
        p.Activate();
        Assert.Equal(ProjectStatus.Active, p.Status);
    }

    [Fact] // پروژهٔ جدید در وضعیت Draft است
    public void New_project_is_draft() => Assert.Equal(ProjectStatus.Draft, Valid().Status);
}
