using LeadPilot.Application.Discovery;
using LeadPilot.Domain.Discovery;
using Xunit;

namespace LeadPilot.Tests;

public class EnrichmentGovernanceTests
{
    private static ProviderApproval Approved(ProviderApprovalState st = ProviderApprovalState.ApprovedForEnrichment)
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.Apollo, "mgr");
        p.Transition(st, "mgr");
        return p;
    }

    [Fact] // Provider بدونِ تأییدِ Enrichment → رد
    public void Unapproved_provider_blocked()
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.Apollo, "mgr"); // NotReviewed
        var d = new EnrichmentGovernanceService().Evaluate(p,
            DataFieldKind.CompanyName, DataFieldKind.CompanyDomain, false);
        Assert.False(d.Allowed);
        Assert.Equal("PROVIDER_NOT_APPROVED", d.Code);
    }

    [Fact] // Apollo تأییدشده + دادهٔ سطحِ شرکت → مجاز
    public void Approved_company_enrichment_ok()
    {
        var d = new EnrichmentGovernanceService().Evaluate(Approved(),
            DataFieldKind.CompanyDomain, DataFieldKind.BusinessRole, false);
        Assert.True(d.Allowed);
        Assert.Equal("COMPANY_ENRICHMENT_OK", d.Code);
    }

    [Fact] // جیمیلِ شخصی → موبایلِ شخصی بدونِ رضایت → رد (قلبِ سند)
    public void Personal_gmail_to_phone_without_consent_blocked()
    {
        var d = new EnrichmentGovernanceService().Evaluate(Approved(),
            DataFieldKind.PersonalEmail, DataFieldKind.PersonalPhone, hasProvenConsent: false);
        Assert.False(d.Allowed);
        Assert.Equal("DATA_CLASS_BLOCKED", d.Code);
    }

    [Fact] // همان مورد با رضایتِ اثبات‌شده → مجاز (مسیرِ قانونی)
    public void Personal_with_consent_ok()
    {
        var d = new EnrichmentGovernanceService().Evaluate(Approved(),
            DataFieldKind.PersonalEmail, DataFieldKind.PersonalPhone, hasProvenConsent: true);
        Assert.True(d.Allowed);
        Assert.Equal("CONSENTED_PERSONAL_OK", d.Code);
    }

    [Fact] // هویت‌یابی از Cookie → موبایلِ شخصی → همیشه رد (حتی با «رضایت»)
    public void Cookie_deanonymization_always_blocked()
    {
        var d = new EnrichmentGovernanceService().Evaluate(Approved(),
            DataFieldKind.CookieIdentity, DataFieldKind.PersonalPhone, hasProvenConsent: true);
        Assert.False(d.Allowed);
    }
}
