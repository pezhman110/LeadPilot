using LeadPilot.Application.Campaigns;
using LeadPilot.Domain.Campaigns;
using Xunit;

namespace LeadPilot.Tests;

public class CampaignLauncherTests
{
    private static CampaignPreset Preset(CampaignContext ctx, decimal budget = 1000m, decimal pct = 1m) =>
        new(Guid.NewGuid(), ctx, "Dubai " + ctx, "Dubai", budget, pct,
            CampaignLauncherService.DefaultTactics(ctx).ToList());

    [Fact] // هر زمینه تاکتیک‌های پیش‌فرضِ خودش را دارد
    public void Context_has_default_tactics()
    {
        Assert.NotEmpty(CampaignLauncherService.DefaultTactics(CampaignContext.Hotels));
        Assert.Contains(LaunchTactic.B2bCompanyEnrichment, CampaignLauncherService.DefaultTactics(CampaignContext.Investment));
    }

    [Fact] // مسیرِ پشتِ دکمه همیشه به opt-in و CRM ختم می‌شود
    public void Plan_ends_with_optin_and_crm()
    {
        var plan = new CampaignLauncherService().BuildPlan(Preset(CampaignContext.Malls));
        var keys = plan.Steps.Select(s => s.Key).ToList();
        Assert.Contains("VoluntaryOptIn", keys);
        Assert.Contains("CaptureConsentEvidence", keys);
        Assert.Contains("SyncToCrm", keys);
    }

    [Fact] // سقفِ «حداکثر ۱٪» درست حساب می‌شود
    public void Max_cost_percent()
    {
        var p = Preset(CampaignContext.Hotels, budget: 1000m, pct: 1m);
        Assert.Equal(10m, p.MaxCostPerLeadUsd); // ۱٪ از ۱۰۰۰
        Assert.True(p.IsWithinBudget(9m));
        Assert.False(p.IsWithinBudget(11m));
    }

    [Fact] // گام‌ها به‌ترتیب‌اند و تاکتیک‌ها اولِ مسیرند
    public void Steps_ordered()
    {
        var plan = new CampaignLauncherService().BuildPlan(Preset(CampaignContext.HomeService));
        var orders = plan.Steps.Select(s => s.Order).ToList();
        Assert.Equal(orders.OrderBy(x => x).ToList(), orders);
        Assert.StartsWith("Tactic:", plan.Steps.First().Key);
    }

    [Fact] // درصدِ نامعتبر رد می‌شود
    public void Invalid_percent_rejected() =>
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            new CampaignPreset(Guid.NewGuid(), CampaignContext.Salon, "x", "Dubai", 1000m, 150m,
                [LaunchTactic.LandingLeadForm]));
}
