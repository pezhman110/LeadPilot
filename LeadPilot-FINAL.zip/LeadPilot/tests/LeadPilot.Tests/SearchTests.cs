using LeadPilot.Application.Compliance;
using LeadPilot.Application.Scoring;
using LeadPilot.Application.Search;
using LeadPilot.Domain.Common;
using LeadPilot.Domain.Projects;
using LeadPilot.Domain.Signals;
using Xunit;

namespace LeadPilot.Tests;

public class SearchTests
{
    private static Project Project()
    {
        var p = new Project("سرمایه‌گذار شخصی", "Personal Investor", CustomerType.Personal, 500000m, 75, 90, 97);
        foreach (var c in new[] { "ar", "en", "fa", "hi", "fr", "ru" }) p.AddLanguage(c);
        p.AddGeography("AE", "Dubai", 1);
        return p;
    }
    private static RawSignal Raw(string text, SourceType src, string url = "https://x.local/1") =>
        new(Guid.NewGuid(), Guid.NewGuid(), "demo", url, src, "q", text, false);

    [Fact]
    public void Gateway_blocks_disallowed_source()
    {
        var d = new ComplianceGateway().Evaluate(Raw("hi", SourceType.Unknown), Project());
        Assert.Equal(ComplianceStatus.Blocked, d.Status);
    }

    [Fact]
    public void Gateway_blocks_directory_markers()
    {
        var d = new ComplianceGateway().Evaluate(Raw("We are a company, contact us via About Us", SourceType.PublicApi), Project());
        Assert.Equal(ComplianceStatus.Blocked, d.Status);
    }

    [Fact]
    public void OptIn_source_is_safe()
    {
        var d = new ComplianceGateway().Evaluate(Raw("I invest personally", SourceType.OptIn), Project());
        Assert.Equal(ComplianceStatus.Safe, d.Status);
    }

    [Fact]
    public void High_intent_personal_signal_scores_high()
    {
        var gw = new ComplianceGateway();
        var sc = new RuleScoringEngine();
        var raw = Raw("private investor, looking to buy a business in dubai, i have 1 million aed, passive income", SourceType.OptIn);
        var d = gw.Evaluate(raw, Project());
        var norm = sc.Score(raw, Project(), d);
        Assert.True(norm.IntentScore >= 70);
        Assert.True(norm.FitScore >= 40);
    }

    [Fact]
    public void Corporate_signal_scores_lower_intent()
    {
        var gw = new ComplianceGateway();
        var sc = new RuleScoringEngine();
        var raw = Raw("corporate VC fund looking for portfolio companies", SourceType.OptIn);
        var d = gw.Evaluate(raw, Project());
        var norm = sc.Score(raw, Project(), d);
        Assert.True(norm.IntentScore < 40);
    }

    [Fact]
    public void QueryBuilder_makes_one_query_per_language()
    {
        var queries = new QueryBuilder().Build(Project());
        Assert.Equal(6, queries.Count);
        Assert.Contains(queries, q => q.LanguageCode == "fa");
    }

    [Fact]
    public void LanguageDetector_detects_persian_and_arabic()
    {
        var d = new LanguageDetector();
        Assert.Equal(DetectedLanguage.Persian, d.Detect("دنبال سرمایه گذاری در دبی هستم"));
        Assert.Equal(DetectedLanguage.Arabic, d.Detect("أبحث عن استثمار في دبي"));
        Assert.Equal(DetectedLanguage.English, d.Detect("looking to invest in dubai"));
    }

    [Fact]
    public void Dedupe_key_matches_same_url_and_text()
    {
        var a = Raw("Same text", SourceType.OptIn, "https://x.local/same");
        var b = Raw("Same text", SourceType.OptIn, "https://x.local/same");
        Assert.Equal(a.DedupeKey(), b.DedupeKey());
    }
}
