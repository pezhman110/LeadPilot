using System.Text;
using LeadPilot.Application.Dedup;
using LeadPilot.Domain.Dedup;
using Xunit;

namespace LeadPilot.Tests;

file sealed class InMemDedupRepo : IDeduplicationRepository
{
    public readonly List<ContactRecord> Records = [];
    public readonly HashSet<string> Reservations = [];
    public Task<ContactRecord?> FindByHashAsync(Guid t, ContactType ct, string h, CancellationToken c) =>
        Task.FromResult(Records.FirstOrDefault(x => x.TenantId == t && x.ContactType == ct && x.ContactHash == h));
    public Task AddAsync(ContactRecord r, CancellationToken c) { Records.Add(r); return Task.CompletedTask; }
    public Task<bool> ReservationExistsAsync(string key, CancellationToken c) => Task.FromResult(Reservations.Contains(key));
    public Task AddReservationAsync(EnrichmentReservation r, CancellationToken c) { Reservations.Add(r.Key); return Task.CompletedTask; }
    public Task SaveChangesAsync(CancellationToken c) => Task.CompletedTask;
}

public class DedupTests
{
    private static readonly byte[] Key = Encoding.UTF8.GetBytes("test-key");

    [Theory] // فرمت‌های مختلفِ یک شماره به یک مقدار نرمال می‌شوند
    [InlineData("0501234567")]
    [InlineData("00971501234567")]
    [InlineData("+971 50 123 4567")]
    [InlineData("971501234567")]
    public void Phone_formats_normalize_to_same(string input)
    {
        Assert.Equal("+971501234567", ContactNormalizer.NormalizePhone(input));
    }

    [Fact] // ایمیل نرمال (lowercase/trim)
    public void Email_normalizes()
    {
        Assert.Equal("name@example.com", ContactNormalizer.NormalizeEmail("  Name@Example.COM "));
    }

    [Fact] // هشِ یک شماره در فرمت‌های مختلف یکسان است
    public void Hash_is_stable_across_formats()
    {
        var a = ContactNormalizer.Hash(ContactType.Phone, "0501234567", Key);
        var b = ContactNormalizer.Hash(ContactType.Phone, "+971501234567", Key);
        Assert.Equal(a, b);
    }

    [Fact] // شمارهٔ تکراری: پرونده جدید ساخته نمی‌شود، فقط Observation
    public async Task Duplicate_creates_observation_not_new_record()
    {
        var repo = new InMemDedupRepo();
        var svc = new DeduplicationService(repo, Key);
        var tenant = Guid.NewGuid();
        var r1 = await svc.RegisterAsync(tenant, ContactType.Phone, "0501234567", "crm", default);
        var r2 = await svc.RegisterAsync(tenant, ContactType.Phone, "+971501234567", "google_places", default);
        Assert.True(r1.IsNew);
        Assert.False(r2.IsNew);                       // همان شماره
        Assert.Equal(r1.ContactRecordId, r2.ContactRecordId);
        Assert.Single(repo.Records);                  // فقط یک پرونده
        Assert.Equal(2, repo.Records[0].Observations.Count); // دو مشاهده
    }

    [Fact] // رزروِ Enrichment از پرداخت دوبارهٔ دو Worker جلوگیری می‌کند
    public async Task Reservation_prevents_double_pay()
    {
        var repo = new InMemDedupRepo();
        var svc = new DeduplicationService(repo, Key);
        var prospect = Guid.NewGuid();
        var first = await svc.TryReserveEnrichmentAsync(prospect, "apollo", "phone", default);
        var second = await svc.TryReserveEnrichmentAsync(prospect, "apollo", "phone", default);
        Assert.True(first);   // اولی موفق
        Assert.False(second); // دومی رد (رزرو وجود دارد)
    }

    [Fact] // شمارهٔ موجود دوباره خریداری نمی‌شود
    public void Existing_contact_not_repurchased()
    {
        var rec = new ContactRecord(Guid.NewGuid(), ContactType.Phone, "hash123", "crm");
        Assert.False(rec.ShouldRepurchase());
    }
}
