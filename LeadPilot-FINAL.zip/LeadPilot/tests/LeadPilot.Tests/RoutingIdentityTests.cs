using LeadPilot.Application.Communications;
using LeadPilot.Application.Identity;
using LeadPilot.Application.Agents;
using LeadPilot.Domain.Communications;
using LeadPilot.Domain.Identity;
using LeadPilot.Domain.Suppression;
using Xunit;

namespace LeadPilot.Tests;

public class ChannelRoutingTests
{
    private static IReadOnlySet<CommunicationChannel> S(params CommunicationChannel[] c) => c.ToHashSet();

    private static ChannelRoutingInput Input(
        CommunicationChannel? pref, CommunicationChannel[] fallback,
        CommunicationChannel[] consent, CommunicationChannel[] suppressed = null,
        CommunicationChannel[] window = null, bool automation = true) =>
        new(true, pref, fallback.ToList(),
            consent.ToHashSet(), (suppressed ?? []).ToHashSet(),
            S(CommunicationChannel.WhatsApp, CommunicationChannel.Email, CommunicationChannel.InstagramDm),
            S(), (window ?? [CommunicationChannel.InstagramDm]).ToHashSet(),
            S(CommunicationChannel.WhatsApp), automation);

    [Fact] // کانالِ ترجیحیِ مجاز انتخاب می‌شود
    public void Preferred_permitted_chosen()
    {
        var d = new ChannelRoutingEngine().Decide(Input(
            CommunicationChannel.Email, [CommunicationChannel.WhatsApp],
            [CommunicationChannel.Email, CommunicationChannel.WhatsApp]));
        Assert.Equal(CommunicationChannel.Email, d.ChosenChannel);
    }

    [Fact] // اگر ترجیحی رضایت ندارد، به fallbackِ دارای رضایتِ مستقل می‌رود، ولی HumanReview
    public void Fallback_requires_independent_consent_and_is_human_review()
    {
        // ترجیحی WhatsApp رضایت ندارد؛ Email رضایتِ مستقل دارد
        var d = new ChannelRoutingEngine().Decide(Input(
            CommunicationChannel.WhatsApp, [CommunicationChannel.Email],
            [CommunicationChannel.Email]));
        Assert.Equal(CommunicationChannel.Email, d.ChosenChannel);
        Assert.Equal(SendMode.HumanReview, d.Mode); // fallback هرگز خودکار نیست
    }

    [Fact] // opt-out سراسری کانال را می‌بندد
    public void Suppressed_channel_blocked()
    {
        var d = new ChannelRoutingEngine().Decide(Input(
            CommunicationChannel.Email, [],
            [CommunicationChannel.Email], suppressed: [CommunicationChannel.Email]));
        Assert.Null(d.ChosenChannel);
    }

    [Fact] // اینستاگرام بدونِ پنجرهٔ باز → مسدود (پنجرهٔ پلتفرم)
    public void Instagram_without_window_blocked()
    {
        var d = new ChannelRoutingEngine().Decide(Input(
            CommunicationChannel.InstagramDm, [],
            [CommunicationChannel.InstagramDm], window: []));
        Assert.Null(d.ChosenChannel);
    }

    [Fact] // تیک‌تاک outbound ندارد → همیشه HumanReview/انتقال
    public void TikTok_needs_human()
    {
        var status = new ChannelRoutingEngine().EvaluateChannel(Input(
            CommunicationChannel.TikTokDm, [], [CommunicationChannel.TikTokDm]), CommunicationChannel.TikTokDm);
        Assert.Equal(RoutingStatus.NeedsHumanApproval, status);
    }
}

public class IdentityLinkTests
{
    [Fact] // شباهتِ عکس/نام → Rejected و قابلِ تأیید نیست
    public void Photo_similarity_rejected()
    {
        var link = new IdentityLink(Guid.NewGuid(), Guid.NewGuid(), "instagram", "@x", IdentityEvidence.PhotoOrNameSimilarity);
        Assert.Equal(IdentityConfidence.Rejected, link.Confidence);
        Assert.Throws<InvalidOperationException>(() => link.Confirm("mgr"));
    }

    [Fact] // OAuth → Verified و قابلِ ادغام
    public void Oauth_verified_mergeable()
    {
        var link = new IdentityLink(Guid.NewGuid(), Guid.NewGuid(), "instagram", "@x", IdentityEvidence.OAuthOrOfficialLogin);
        Assert.Equal(IdentityConfidence.Verified, link.Confidence);
        Assert.True(link.IsUsableForMerge);
    }

    [Fact] // لینکِ عمومی → NeedsReview، نیازمندِ تأیید
    public void Public_link_needs_review()
    {
        var svc = new IdentityResolutionService();
        var link = svc.Propose(Guid.NewGuid(), Guid.NewGuid(), "instagram", "@x", IdentityEvidence.PublicLinkSimilarity);
        Assert.True(svc.RequiresHumanApproval(link));
        Assert.False(svc.CanAutoMerge(link));
    }
}

public class SuppressionScopeTests
{
    [Fact] // AllMarketing همهٔ کانال‌ها را می‌بندد
    public void All_marketing_blocks_every_channel()
    {
        var e = new GlobalSuppressionEntry(Guid.NewGuid(), "h", SuppressionScope.AllMarketing, null, "opt-out", "wa");
        Assert.True(e.Blocks("whatsapp"));
        Assert.True(e.Blocks("email"));
    }

    [Fact] // ChannelOnly فقط همان کانال را می‌بندد
    public void Channel_only_blocks_one()
    {
        var e = new GlobalSuppressionEntry(Guid.NewGuid(), "h", SuppressionScope.ChannelOnly, "whatsapp", "stop", "wa");
        Assert.True(e.Blocks("whatsapp"));
        Assert.False(e.Blocks("email"));
    }
}

public class AgentRoleModeTests
{
    [Fact] // Junior فقط دستی
    public void Junior_manual_only()
    {
        Assert.True(AgentRolePolicy.IsModeAllowed(AgentRole.JuniorSales, SendMode.Manual));
        Assert.False(AgentRolePolicy.IsModeAllowed(AgentRole.JuniorSales, SendMode.Automatic));
    }

    [Fact] // Supervisor اتوماسیونِ تأییدشده دارد؛ فقط Administrator پیکربندی
    public void Supervisor_automation_admin_config()
    {
        Assert.True(AgentRolePolicy.IsModeAllowed(AgentRole.Supervisor, SendMode.Automatic));
        Assert.False(AgentRolePolicy.CanConfigure(AgentRole.Supervisor));
        Assert.True(AgentRolePolicy.CanConfigure(AgentRole.Administrator));
    }
}

public class PrimaryConnectorTests
{
    [Fact] // پشتیبان فقط وقتی اصلی خراب است و دستی فعال شده کار می‌کند
    public void Fallback_only_when_primary_down_and_activated()
    {
        var fb = new PrimaryConnectorBinding(Guid.NewGuid(), CommunicationChannel.WhatsApp, "num",
            MessagingProviderCode.WhatsAppCloudApi, ConnectorRole.FallbackManual);
        Assert.False(fb.CanSendNow(primaryHealthy: false)); // هنوز فعال نشده
        fb.ActivateFallbackManually();
        Assert.True(fb.CanSendNow(primaryHealthy: false));
        Assert.False(fb.CanSendNow(primaryHealthy: true)); // اصلی سالم است → پشتیبان نه
    }

    [Fact] // اصلی فقط وقتی سالم است می‌فرستد
    public void Primary_sends_when_healthy()
    {
        var p = new PrimaryConnectorBinding(Guid.NewGuid(), CommunicationChannel.WhatsApp, "num",
            MessagingProviderCode.RespondIo, ConnectorRole.Primary);
        Assert.True(p.CanSendNow(true));
        Assert.False(p.CanSendNow(false));
    }
}
