using LeadPilot.Application.Discovery;
using LeadPilot.Domain.Discovery;
using Xunit;

namespace LeadPilot.Tests;

public class ProviderApprovalTests
{
    [Fact] // تازه‌ساخته هیچ اجازه‌ای ندارد
    public void NotReviewed_no_permission()
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.Apify, "mgr");
        Assert.False(p.CanDiscover); Assert.False(p.CanEnrich); Assert.False(p.CanOutreach);
    }

    [Fact] // تأییدِ Outreach شاملِ Discovery و Enrichment هم هست
    public void Outreach_includes_lower()
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.Outscraper, "mgr");
        p.Transition(ProviderApprovalState.ApprovedForOutreach, "mgr");
        Assert.True(p.CanDiscover); Assert.True(p.CanEnrich); Assert.True(p.CanOutreach);
    }

    [Fact] // تأییدِ Discovery فقط کشف می‌دهد، نه enrichment
    public void Discovery_only()
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.ZoomInfo, "mgr");
        p.Transition(ProviderApprovalState.ApprovedForDiscovery, "mgr");
        Assert.True(p.CanDiscover); Assert.False(p.CanEnrich);
    }

    [Fact] // Suspended همه را می‌بندد
    public void Suspended_blocks_all()
    {
        var p = new ProviderApproval(Guid.NewGuid(), DataProviderCode.Lusha, "mgr");
        p.Transition(ProviderApprovalState.ApprovedForOutreach, "mgr");
        p.Transition(ProviderApprovalState.Suspended, "mgr");
        Assert.False(p.CanDiscover);
    }
}

public class QuarantinePipelineTests
{
    private static ImportRecord Rec(bool prov = true, bool consent = true) =>
        new(Guid.NewGuid(), DataProviderCode.Apify, "src", "https://x", DateTimeOffset.UtcNow, prov, consent);

    [Fact] // مسیرِ کامل با همه‌چیز درست → Approved و ارسال فعال
    public void Full_valid_approved()
    {
        var r = Rec();
        var stage = new QuarantineService().RunPipeline(r, sourceValid: true, isDuplicate: false, humanApproved: true);
        Assert.Equal(QuarantineStage.Approved, stage);
        Assert.True(r.SendingEnabled);
    }

    [Fact] // بدونِ منشأ → Quarantined
    public void No_provenance_quarantined()
    {
        var r = Rec(prov: false);
        var stage = new QuarantineService().RunPipeline(r, true, false, true);
        Assert.Equal(QuarantineStage.Quarantined, stage);
        Assert.False(r.SendingEnabled);
    }

    [Fact] // بدونِ مدرکِ رضایت → Quarantined
    public void No_consent_quarantined() =>
        Assert.Equal(QuarantineStage.Quarantined,
            new QuarantineService().RunPipeline(Rec(consent: false), true, false, true));

    [Fact] // تکراری → Rejected
    public void Duplicate_rejected() =>
        Assert.Equal(QuarantineStage.Rejected,
            new QuarantineService().RunPipeline(Rec(), true, isDuplicate: true, true));

    [Fact] // بدونِ بازبینیِ انسانی → Quarantined
    public void No_human_review_quarantined() =>
        Assert.Equal(QuarantineStage.Quarantined,
            new QuarantineService().RunPipeline(Rec(), true, false, humanApproved: false));
}

public class DataClassGuardTests
{
    [Fact] // Gmail شخصی → تلفن بدونِ رضایت → رد
    public void Gmail_to_phone_blocked()
    {
        var d = DataClassGuard.EvaluateEnrichment(DataFieldKind.PersonalEmail, DataFieldKind.PersonalPhone, hasProvenConsent: false);
        Assert.False(d.Allowed);
    }

    [Fact] // با رضایتِ اثبات‌شده → مجاز
    public void With_consent_allowed()
    {
        var d = DataClassGuard.EvaluateEnrichment(DataFieldKind.PersonalEmail, DataFieldKind.PersonalPhone, hasProvenConsent: true);
        Assert.True(d.Allowed);
    }

    [Fact] // کوکی/هویتِ دیجیتال → تماسِ شخصی → همیشه رد
    public void Cookie_to_personal_blocked()
    {
        var d = DataClassGuard.EvaluateEnrichment(DataFieldKind.CookieIdentity, DataFieldKind.PersonalPhone, hasProvenConsent: true);
        Assert.False(d.Allowed);
    }

    [Fact] // دادهٔ سازمانی → مجاز و رده Company
    public void Company_data_allowed()
    {
        Assert.Equal(DataClass.Company, DataClassGuard.Classify(DataFieldKind.CompanyDomain));
        Assert.True(DataClassGuard.EvaluateEnrichment(DataFieldKind.CompanyName, DataFieldKind.CompanyDomain, false).Allowed);
    }

    [Fact] // Intent هرگز مدرکِ قطعیِ فرد نیست
    public void Intent_not_person_proof() => Assert.False(DataClassGuard.IsIntentUsableAsPersonProof());
}

public class IntentAndLinkTests
{
    [Fact] // سیگنال هرگز مجوزِ ارسالِ مستقیم نیست
    public void Signal_never_grants_outreach()
    {
        var s = new IntentSignal(Guid.NewGuid(), "buy-business", "review", "دنبال بیزینس فعالم",
            "M&A", "Dubai", "fa", 72, AllowedNextAction.RouteToLandingForm);
        Assert.False(s.GrantsDirectOutreach);
    }

    [Fact] // Tracked Link با Token در URL رد می‌شود
    public void Token_in_url_rejected() =>
        Assert.Throws<ArgumentException>(() => new TrackedLink(Guid.NewGuid(), "c",
            "https://own.com/p?token=abc", "ig", "social", "camp", null));

    [Fact] // Lead Magnet همیشه رضایت پیش از تحویل می‌خواهد
    public void LeadMagnet_requires_consent()
    {
        var m = new LeadMagnet(Guid.NewGuid(), "راهنمای خرید کسب‌وکار دبی", LeadMagnetKind.Pdf, "M&A", "Dubai", "fa");
        Assert.True(m.RequiresConsentBeforeDelivery);
    }
}
