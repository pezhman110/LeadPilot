using LeadPilot.Application.Community;
using LeadPilot.Domain.Community;
using Xunit;

namespace LeadPilot.Tests;

public class IntentScoringTests
{
    [Fact] // سیگنال‌های قوی → امتیازِ بالا + دلایل
    public void Strong_signals_high_score()
    {
        var s = new IntentScoringEngine().Score([
            IntentSignalKind.WantsToBuyBusiness, IntentSignalKind.MentionedBudget,
            IntentSignalKind.StatedCityOrArea, IntentSignalKind.AskedForPricing]);
        Assert.True(s.Score >= 60);
        Assert.Equal("High", s.Urgency);
        Assert.NotEmpty(s.Reasons);
    }

    [Fact] // رقیب/فروشنده → امتیاز پایین می‌آید
    public void Competitor_lowers_score()
    {
        var s = new IntentScoringEngine().Score([
            IntentSignalKind.AskedForPricing, IntentSignalKind.IsSellerOrCompetitor]);
        Assert.True(s.Score < 45);
    }

    [Fact] // امتیاز همیشه ۰..۱۰۰
    public void Score_clamped()
    {
        var s = new IntentScoringEngine().Score([IntentSignalKind.GeneralComment]);
        Assert.InRange(s.Score, 0, 100);
    }
}

public class ResponseQualityGuardTests
{
    private static ResponseDraft Good() => new(
        SpecialistIdentityDisclosed: true, ClaimsToBeCustomer: false, GuaranteesResultOrProfit: false,
        DisparagesCompetitor: false, PressuresForPhone: false, RelevantToQuestion: true,
        IsDuplicateAcrossThreads: false, LinksToOfficialDomainOnly: true);

    [Fact] // پاسخِ شفافِ کارشناس → تأیید
    public void Transparent_response_approved() => Assert.True(ResponseQualityGuard.Check(Good()).Approved);

    [Fact] // ادعای مشتریِ جعلی → رد (نجات‌دهندهٔ دلسوز)
    public void Fake_customer_rejected()
    {
        var d = Good() with { ClaimsToBeCustomer = true, SpecialistIdentityDisclosed = false };
        var r = ResponseQualityGuard.Check(d);
        Assert.False(r.Approved);
        Assert.NotEmpty(r.Problems);
    }

    [Fact] // تضمینِ سود → رد
    public void Profit_guarantee_rejected() =>
        Assert.False(ResponseQualityGuard.Check(Good() with { GuaranteesResultOrProfit = true }).Approved);

    [Fact] // پاسخِ تکراری زیرِ ده‌ها پست → رد
    public void Duplicate_spam_rejected() =>
        Assert.False(ResponseQualityGuard.Check(Good() with { IsDuplicateAcrossThreads = true }).Approved);
}

public class OpportunityTests
{
    private static CommunitySource Source(CommunitySourceStatus st = CommunitySourceStatus.ApprovedForMonitoring)
    {
        var s = new CommunitySource(Guid.NewGuid(), "r/dubai", CommunityPlatform.Reddit, "https://reddit.com/r/dubai",
            "AE", "Dubai", "en", "salon,investment", true, false, true, 100, 90);
        s.Transition(st);
        return s;
    }
    private static RawObservation Obs() => new("r/dubai", "https://reddit.com/x", "p1", "buy business",
        "buying an operating business in Dubai", "en", "M&A", "Dubai", 84, DateTimeOffset.UtcNow);

    [Fact] // فرصت هرگز Contact قابلِ ارسال نیست
    public void Opportunity_never_contactable()
    {
        var r = new OpportunityIngestionService().Ingest(Source(), Obs(), isDuplicate: false);
        Assert.True(r.Ok);
        Assert.False(r.Opportunity!.IsContactable);
    }

    [Fact] // منبعِ بدونِ تأییدِ پایش → ورود رد
    public void Unapproved_source_rejected()
    {
        var r = new OpportunityIngestionService().Ingest(Source(CommunitySourceStatus.Candidate), Obs(), false);
        Assert.False(r.Ok);
    }

    [Fact] // تکراری → رد
    public void Duplicate_rejected() =>
        Assert.False(new OpportunityIngestionService().Ingest(Source(), Obs(), isDuplicate: true).Ok);

    [Fact] // ثبتِ پاسخِ منتشرشده و تبدیل فقط پس از اقدامِ داوطلبانه
    public void Publish_and_convert_lifecycle()
    {
        var o = new OpportunityIngestionService().Ingest(Source(), Obs(), false).Opportunity!;
        o.Assign(Guid.NewGuid());
        o.RecordPublishedResponse("https://reddit.com/x/comment");
        Assert.Equal(OpportunityStatus.Published, o.Status);
        o.ConvertToLead();
        Assert.Equal(OpportunityStatus.ConvertedToLead, o.Status);
    }

    [Fact] // منبع فقط پس از تأیید اجازهٔ پاسخِ عمومی دارد
    public void Source_gating()
    {
        Assert.False(Source(CommunitySourceStatus.ApprovedForMonitoring).CanPublicRespond);
        Assert.True(Source(CommunitySourceStatus.ApprovedForPublicResponse).CanPublicRespond);
    }
}
