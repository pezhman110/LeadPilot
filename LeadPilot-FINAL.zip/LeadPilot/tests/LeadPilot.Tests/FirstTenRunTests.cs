using LeadPilot.Domain.Acquisition;
using Xunit;

namespace LeadPilot.Tests;

public class FirstTenRunTests
{
    private static FirstTenRun NewRun(int target = 10, int maxCand = 100, decimal maxCost = 50m) =>
        new(Guid.NewGuid(), Guid.NewGuid(), "SALON", isCorporateProject: false,
            target, maxCand, maxCost, "manager", DateTimeOffset.UtcNow);

    private static FirstTenRunResult Result(Guid runId, Guid? cp = null) =>
        new(runId, Guid.NewGuid(), cp ?? Guid.NewGuid(), "PHONE", "+9715****4567",
            "instagram_lead_ads", "https://example.com/s/1", "https://example.com/s/1", 92, 0m, DateTimeOffset.UtcNow);

    [Fact] // هدف نامعتبر رد می‌شود
    public void Invalid_target_rejected() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => NewRun(target: 0));

    [Fact] // حداکثر کاندید کمتر از هدف رد می‌شود
    public void MaxCandidates_below_target_rejected() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => NewRun(target: 10, maxCand: 5));

    [Fact] // نتیجهٔ بدون مرجع منبع پذیرفته نمی‌شود
    public void Result_without_source_reference_rejected() =>
        Assert.Throws<ArgumentException>(() => new FirstTenRunResult(
            Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), "PHONE", "+9715****4567",
            "src", sourceReference: "", null, 90, 0m, DateTimeOffset.UtcNow));

    [Fact] // پیش از Start نمی‌تواند نتیجه بپذیرد
    public void Cannot_accept_before_running()
    {
        var run = NewRun();
        Assert.False(run.CanAcceptResult());
    }

    [Fact] // رسیدن به هدف → توقف خودکار (Completed)
    public void Reaching_target_auto_completes()
    {
        var run = NewRun(target: 3);
        run.Queue(50); run.Start(DateTimeOffset.UtcNow);
        for (int i = 0; i < 3; i++)
            run.AddResult(Result(run.Id), DateTimeOffset.UtcNow);
        Assert.Equal(FirstTenRunStatus.Completed, run.Status);
        Assert.Equal(3, run.ResultCount);
    }

    [Fact] // بعد از رسیدن به هدف، نتیجهٔ بیشتر پذیرفته نمی‌شود
    public void No_result_accepted_after_target()
    {
        var run = NewRun(target: 2);
        run.Queue(50); run.Start(DateTimeOffset.UtcNow);
        run.AddResult(Result(run.Id), DateTimeOffset.UtcNow);
        run.AddResult(Result(run.Id), DateTimeOffset.UtcNow);
        Assert.False(run.CanAcceptResult());
        Assert.Throws<InvalidOperationException>(() =>
            run.AddResult(Result(run.Id), DateTimeOffset.UtcNow));
    }

    [Fact] // تکراری در همین اجرا (همان ContactPointId) جزو نتایج شمرده نمی‌شود
    public void Duplicate_in_run_not_counted()
    {
        var run = NewRun(target: 5);
        run.Queue(50); run.Start(DateTimeOffset.UtcNow);
        var cp = Guid.NewGuid();
        run.AddResult(Result(run.Id, cp), DateTimeOffset.UtcNow);
        run.AddResult(Result(run.Id, cp), DateTimeOffset.UtcNow); // همان ContactPoint
        Assert.Equal(1, run.ResultCount);
    }

    [Fact] // کمبود کاندید → CompletedWithShortage
    public void Shortage_marks_completed_with_shortage()
    {
        var run = NewRun(target: 10);
        run.Queue(2); run.Start(DateTimeOffset.UtcNow);
        run.AddResult(Result(run.Id), DateTimeOffset.UtcNow);
        run.CompleteWithShortage("کاندید تمام شد", DateTimeOffset.UtcNow);
        Assert.Equal(FirstTenRunStatus.CompletedWithShortage, run.Status);
        Assert.Equal("کاندید تمام شد", run.FailureReason);
    }

    [Fact] // اتصال حیاتیِ قرمز → Fail (شروع نشدن)
    public void Failed_run_has_reason()
    {
        var run = NewRun();
        run.MarkWaitingForConnections();
        run.Fail("اتصال حیاتی قرمز است", DateTimeOffset.UtcNow);
        Assert.Equal(FirstTenRunStatus.Failed, run.Status);
        Assert.NotNull(run.FailureReason);
    }

    [Fact] // هزینه و شمارش کاندید ثبت می‌شود
    public void Cost_and_counters_tracked()
    {
        var run = NewRun();
        run.Queue(50); run.Start(DateTimeOffset.UtcNow);
        run.RecordCandidateProcessed(wasDuplicate: true, wasInvalid: false, costAed: 2m);
        run.RecordCandidateProcessed(wasDuplicate: false, wasInvalid: true, costAed: 0m);
        Assert.Equal(2, run.CandidatesProcessed);
        Assert.Equal(1, run.DuplicateCount);
        Assert.Equal(1, run.InvalidCount);
        Assert.Equal(2m, run.ConsumedCostAed);
    }
}
