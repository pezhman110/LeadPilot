using LeadPilot.Application.Navigation;
using LeadPilot.Domain.Navigation;
using Xunit;

namespace LeadPilot.Tests;

public class DashboardBlueprintTests
{
    [Fact] // فروشنده فقط آیتم‌های Seller را می‌بیند (نه حاکمیت/تنظیمات)
    public void Seller_sees_subset()
    {
        var menu = DashboardBlueprint.MenuFor(DashboardRole.Seller);
        var keys = menu.SelectMany(g => g.Items).Select(i => i.Key).ToHashSet();
        Assert.Contains("inbox", keys);
        Assert.Contains("agent-workspace", keys);
        Assert.DoesNotContain("connections", keys);   // Admin
        Assert.DoesNotContain("provider-approval", keys); // Manager
    }

    [Fact] // مدیر بیشتر می‌بیند، Admin از همه بیشتر
    public void Role_hierarchy()
    {
        int seller = DashboardBlueprint.MenuFor(DashboardRole.Seller).SelectMany(g => g.Items).Count();
        int manager = DashboardBlueprint.MenuFor(DashboardRole.Manager).SelectMany(g => g.Items).Count();
        int admin = DashboardBlueprint.MenuFor(DashboardRole.Admin).SelectMany(g => g.Items).Count();
        Assert.True(seller < manager);
        Assert.True(manager <= admin);
    }

    [Fact] // به ۷۰ دکمه نمی‌رسیم؛ گروه‌ها معدود و مرتب‌اند
    public void Not_seventy_buttons()
    {
        Assert.True(DashboardBlueprint.AllItems.Count < 40);
        var groups = DashboardBlueprint.MenuFor(DashboardRole.Admin);
        Assert.True(groups.Count <= 8); // ۷ مرحله + تنظیمات
    }

    [Fact] // گروه‌ها به‌ترتیبِ مسیرِ فرآیند‌اند و Settings آخر است
    public void Ordered_by_process_and_settings_last()
    {
        var groups = DashboardBlueprint.MenuFor(DashboardRole.Admin).ToList();
        var orders = groups.Select(g => (int)g.Stage).ToList();
        Assert.Equal(orders.OrderBy(x => x).ToList(), orders);
        Assert.Equal(ProcessStage.Settings, groups.Last().Stage);
    }

    [Fact] // موارد Primary اولِ هر گروه‌اند (کم‌اهمیت‌ها جلوی صفحه نیستند)
    public void Primary_first_in_group()
    {
        foreach (var g in DashboardBlueprint.MenuFor(DashboardRole.Manager))
        {
            var items = g.Items.ToList();
            for (int i = 1; i < items.Count; i++)
                Assert.False(!items[i - 1].IsPrimary && items[i].IsPrimary); // primary قبل از non-primary
        }
    }

    [Fact] // هزینهٔ هر مرحله تخمینی است و مراحلِ اصلی پوشش دارند
    public void Cost_estimates_cover_stages()
    {
        Assert.All(DashboardBlueprint.CostEstimates, c => Assert.True(c.IsIndicativeOnly));
        Assert.Contains(DashboardBlueprint.CostEstimates, c => c.Stage == ProcessStage.Communication);
    }
}
