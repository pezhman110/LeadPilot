using LeadPilot.Application.Content;
using LeadPilot.Domain.Content;
using Xunit;

namespace LeadPilot.Tests;

file sealed class InMemContentRepo : IContentRepository
{
    public readonly List<ContentHeading> Headings = [];
    public readonly List<ContentAsset> Assets = [];
    public readonly List<LandingPage> Landings = [];
    public readonly List<Campaign> Campaigns = [];
    public readonly List<Presentation> Presentations = [];
    public Task AddHeadingAsync(ContentHeading h, CancellationToken ct) { Headings.Add(h); return Task.CompletedTask; }
    public Task<IReadOnlyList<ContentHeading>> ListHeadingsAsync(Guid p, CancellationToken ct) => Task.FromResult<IReadOnlyList<ContentHeading>>(Headings);
    public Task AddAssetAsync(ContentAsset a, CancellationToken ct) { Assets.Add(a); return Task.CompletedTask; }
    public Task<IReadOnlyList<ContentAsset>> ListAssetsAsync(Guid p, CancellationToken ct) => Task.FromResult<IReadOnlyList<ContentAsset>>(Assets);
    public Task AddLandingAsync(LandingPage p, CancellationToken ct) { Landings.Add(p); return Task.CompletedTask; }
    public Task AddCampaignAsync(Campaign c, CancellationToken ct) { Campaigns.Add(c); return Task.CompletedTask; }
    public Task<Campaign?> GetCampaignAsync(Guid id, CancellationToken ct) => Task.FromResult(Campaigns.FirstOrDefault(x => x.Id == id));
    public Task AddPresentationAsync(Presentation p, CancellationToken ct) { Presentations.Add(p); return Task.CompletedTask; }
    public Task<Presentation?> GetPresentationAsync(Guid id, CancellationToken ct) => Task.FromResult(Presentations.FirstOrDefault(x => x.Id == id));
    public Task SaveChangesAsync(CancellationToken ct) => Task.CompletedTask;
}

file sealed class FakeBrain : IAiContentBrain
{
    public Task<GeneratedContent> GenerateAsync(ContentGenerationInput i, CancellationToken ct) =>
        Task.FromResult(new GeneratedContent("copy", "banner", "carousel",
            [new VideoScene(1, "v", "vo", 5)], "podcast script", "brief"));
}

public class ContentTests
{
    [Fact] // غریال: کمبودها را درست پیدا می‌کند
    public async Task Inventory_finds_missing()
    {
        var repo = new InMemContentRepo();
        var svc = new ContentService(repo, new FakeBrain());
        var report = await svc.ReviewInventoryAsync(Guid.NewGuid(), new[] { "ar", "en" }, default);
        Assert.Empty(report.Have);          // هیچ asset تأییدشده‌ای نیست
        Assert.NotEmpty(report.Missing);    // پس همه کمبودند
    }

    [Fact] // تولید محتوا خروجیِ کامل می‌دهد و asset ثبت می‌کند
    public async Task Generate_produces_content_and_registers_asset()
    {
        var repo = new InMemContentRepo();
        var svc = new ContentService(repo, new FakeBrain());
        var g = await svc.GenerateAsync(Guid.NewGuid(), "H", "group", "fa", "prior", "trend", ContentAssetType.Video, default);
        Assert.Equal("copy", g.AdCopy);
        Assert.Single(g.VideoScript);
        Assert.Single(repo.Assets);
        Assert.True(repo.Assets[0].IsAiGenerated);
    }

    [Fact] // کمپین: شروع وضعیت را Running می‌کند
    public async Task Campaign_start_sets_running()
    {
        var repo = new InMemContentRepo();
        var svc = new ContentService(repo, new FakeBrain());
        var landing = await svc.CreateLandingAsync(Guid.NewGuid(), "inv-dubai", "tpl-a", "en", "Invest in Dubai", default);
        var pid = Guid.NewGuid();
        var cid = await svc.CreateCampaignAsync(pid, "C1", CampaignScope.SmallDedicated, landing, default);
        Assert.True(await svc.StartCampaignAsync(cid, default));
        Assert.Equal(CampaignStatus.Running, repo.Campaigns[0].Status);
    }

    [Fact] // پرزنت اختصاصی: اسکریپت می‌گیرد و ارزیابی می‌شود
    public async Task Presentation_builds_and_evaluates()
    {
        var repo = new InMemContentRepo();
        var svc = new ContentService(repo, new FakeBrain());
        var id = await svc.BuildPresentationAsync(Guid.NewGuid(), Guid.NewGuid(), PresenterKind.Ai, "fa",
            "H", "group", "prior", "trend", default);
        Assert.Equal(PresentationStatus.Ready, repo.Presentations[0].Status);
        Assert.True(await svc.EvaluatePresentationAsync(id, 88, default));
        Assert.Equal(88, repo.Presentations[0].QualityScore);
    }

    [Fact] // صفحهٔ فرود همیشه فرم opt-in دارد
    public void Landing_always_has_optin()
    {
        var lp = new LandingPage(Guid.NewGuid(), "slug", "tpl", "fa", "head");
        Assert.True(lp.HasOptInForm);
    }
}
