using LeadPilot.Application.Processing;
using LeadPilot.Domain.Processing;
using Xunit;

namespace LeadPilot.Tests;

public class ProcessingTests
{
    private static ProcessingJob NewJob(ProcessingJobPriority p = ProcessingJobPriority.Normal, int maxAttempts = 4) =>
        new(ProcessingJobTypes.ContactDiscovery, "{\"x\":1}", $"KEY-{Guid.NewGuid():N}", "corr-1",
            p, maxAttempts, DateTimeOffset.UtcNow);

    [Fact] // Job جدید Pending است
    public void New_job_is_pending()
    {
        var j = NewJob();
        Assert.Equal(ProcessingJobStatus.Pending, j.Status);
    }

    [Fact] // Job آینده قبل از ScheduledAt قابل برداشت نیست
    public void Future_job_not_claimable()
    {
        var future = new ProcessingJob(ProcessingJobTypes.Search, "{}", "K1", "c",
            ProcessingJobPriority.Normal, 3, DateTimeOffset.UtcNow.AddHours(1));
        Assert.False(future.CanBeClaimedAt(DateTimeOffset.UtcNow));
    }

    [Fact] // برداشت → Processing، Lease تنظیم می‌شود، AttemptCount++
    public void Claim_sets_processing_and_lease()
    {
        var j = NewJob();
        var now = DateTimeOffset.UtcNow;
        j.Claim("worker-1", now, TimeSpan.FromMinutes(2));
        Assert.Equal(ProcessingJobStatus.Processing, j.Status);
        Assert.Equal("worker-1", j.LockedBy);
        Assert.Equal(1, j.AttemptCount);
        Assert.Equal(now.AddMinutes(2), j.LockedUntilUtc);
    }

    [Fact] // Job قفل‌شده قبل از پایان Lease قابل برداشت نیست؛ بعدش بله (رهاشده)
    public void Locked_job_reclaimable_after_lease_expiry()
    {
        var j = NewJob();
        var now = DateTimeOffset.UtcNow;
        j.Claim("worker-1", now, TimeSpan.FromMinutes(2));
        Assert.False(j.CanBeClaimedAt(now.AddMinutes(1)));  // هنوز اجاره دارد
        Assert.True(j.CanBeClaimedAt(now.AddMinutes(3)));   // اجاره منقضی → رهاشده
    }

    [Fact] // فقط Worker مالک می‌تواند تکمیل کند
    public void Only_owner_can_complete()
    {
        var j = NewJob();
        j.Claim("worker-1", DateTimeOffset.UtcNow, TimeSpan.FromMinutes(2));
        Assert.Throws<InvalidOperationException>(() => j.Complete("worker-2", DateTimeOffset.UtcNow));
        j.Complete("worker-1", DateTimeOffset.UtcNow);
        Assert.Equal(ProcessingJobStatus.Completed, j.Status);
    }

    [Fact] // خطای موقت → RetryScheduled؛ پس از سقف تلاش → DeadLetter
    public void Transient_failure_retries_then_dead_letters()
    {
        var j = NewJob(maxAttempts: 2);
        var now = DateTimeOffset.UtcNow;
        j.Claim("w", now, TimeSpan.FromMinutes(1));         // attempt 1
        j.Fail("w", "ERR", "msg", now, now.AddSeconds(15));
        Assert.Equal(ProcessingJobStatus.RetryScheduled, j.Status);
        j.Claim("w", now.AddMinutes(1), TimeSpan.FromMinutes(1)); // attempt 2 (=max)
        j.Fail("w", "ERR", "msg", now, now.AddSeconds(60));
        Assert.Equal(ProcessingJobStatus.DeadLetter, j.Status);
    }

    [Fact] // فاصلهٔ Retry فزاینده است
    public void Retry_delay_increases()
    {
        var d1 = RetryPolicy.CalculateDelay(1);
        var d3 = RetryPolicy.CalculateDelay(3);
        Assert.True(d3 > d1);
    }

    [Fact] // Freeze/Unfreeze
    public void Freeze_then_unfreeze()
    {
        var j = NewJob();
        j.Freeze();
        Assert.Equal(ProcessingJobStatus.Frozen, j.Status);
        j.Unfreeze(DateTimeOffset.UtcNow);
        Assert.Equal(ProcessingJobStatus.RetryScheduled, j.Status);
    }

    [Fact] // Idempotency: نوع Job نامعتبر رد می‌شود
    public void Invalid_job_rejects()
    {
        Assert.Throws<ArgumentException>(() => new ProcessingJob("", "{}", "K", "c",
            ProcessingJobPriority.Normal, 3, DateTimeOffset.UtcNow));
        Assert.Throws<ArgumentOutOfRangeException>(() => new ProcessingJob("T", "{}", "K", "c",
            ProcessingJobPriority.Normal, 999, DateTimeOffset.UtcNow));
    }
}
