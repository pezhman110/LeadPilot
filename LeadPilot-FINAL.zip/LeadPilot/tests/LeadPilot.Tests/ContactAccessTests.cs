using LeadPilot.Application.ContactAccess;
using LeadPilot.Domain.Consent;
using Xunit;

namespace LeadPilot.Tests;

file sealed class FakeAudit : IContactAccessAudit
{
    public int RevealCount;
    public void AddRevealAudit(string actorId, Guid contactId, string reason) => RevealCount++;
}

public class ContactAccessTests
{
    private static ProtectedContactPoint Contact() =>
        new(Guid.NewGuid(), ContactChannel.Phone, "enc", "partner", "basis", "AE");

    [Fact] // مدیر مجاز حتی روی Hidden می‌بیند، با Audit، ولی این «استفادهٔ عملیاتی» نیست
    public void Manager_sees_hidden_with_audit()
    {
        var audit = new FakeAudit();
        var svc = new ContactAccessService(audit);
        var c = Contact(); // Hidden
        var d = svc.Authorize(new ContactAccessRequest("mgr", true, "review"), c);
        Assert.True(d.IsAllowed);
        Assert.Equal("MANAGER_CASE_REVIEW", d.DecisionCode);
        Assert.False(d.IsOperationalUse);
        Assert.Equal(1, audit.RevealCount);
    }

    [Fact] // مدیر مجاز حتی روی Suppressed هم می‌بیند (اصلاح امنیتی)
    public void Manager_sees_suppressed()
    {
        var svc = new ContactAccessService(new FakeAudit());
        var c = Contact(); c.Suppress();
        var d = svc.Authorize(new ContactAccessRequest("mgr", true, "review"), c);
        Assert.True(d.IsAllowed);
        Assert.Equal("MANAGER_CASE_REVIEW", d.DecisionCode);
    }

    [Fact] // مدیر مجاز حتی روی ManagerBlocked هم می‌بیند
    public void Manager_sees_blocked()
    {
        var svc = new ContactAccessService(new FakeAudit());
        var c = Contact(); c.MakeUsableAfterConsent(); c.ManagerBlock("hold");
        var d = svc.Authorize(new ContactAccessRequest("mgr", true, "review"), c);
        Assert.True(d.IsAllowed);
    }

    [Fact] // فروشنده روی Hidden رد می‌شود (رضایت نیامده)
    public void Seller_denied_on_hidden()
    {
        var svc = new ContactAccessService(new FakeAudit());
        var d = svc.Authorize(new ContactAccessRequest("seller", false, "call"), Contact());
        Assert.False(d.IsAllowed);
        Assert.Equal("NOT_CONSENTED", d.DecisionCode);
    }

    [Fact] // فروشنده روی Usable مجاز است (استفادهٔ عملیاتی)
    public void Seller_allowed_on_usable()
    {
        var svc = new ContactAccessService(new FakeAudit());
        var c = Contact(); c.MakeUsableAfterConsent();
        var d = svc.Authorize(new ContactAccessRequest("seller", false, "call"), c);
        Assert.True(d.IsAllowed);
        Assert.True(d.IsOperationalUse);
    }

    [Fact] // فروشنده روی ManagerBlocked رد می‌شود
    public void Seller_denied_on_blocked()
    {
        var svc = new ContactAccessService(new FakeAudit());
        var c = Contact(); c.MakeUsableAfterConsent(); c.ManagerBlock("hold");
        var d = svc.Authorize(new ContactAccessRequest("seller", false, "call"), c);
        Assert.False(d.IsAllowed);
        Assert.Equal("MANAGER_BLOCKED", d.DecisionCode);
    }
}
