using LeadPilot.Application.Partners;
using LeadPilot.Domain.Partners;
using Xunit;

namespace LeadPilot.Tests;

public class PartnerTests
{
    [Fact] // بازه‌های طبقه‌بندی مبلغ درست‌اند
    public void Deal_tiers_match_declared_ranges()
    {
        Assert.Equal(DealTier.InvestmentLow, DealClassifier.Classify(DealKind.Investment, 100_000m));
        Assert.Equal(DealTier.InvestmentMid, DealClassifier.Classify(DealKind.Investment, 1_000_000m));
        Assert.Equal(DealTier.InvestmentHigh, DealClassifier.Classify(DealKind.Investment, 40_000_000m));
        Assert.Equal(DealTier.Purchase, DealClassifier.Classify(DealKind.Purchase, 5_000_000m));
        Assert.Equal(DealTier.BusinessSale, DealClassifier.Classify(DealKind.BusinessSale, 999_000_000m));
    }

    [Fact] // فروش بیزینس تعهد ۳ ماهه دارد
    public void Business_sale_has_three_month_commitment() =>
        Assert.True(DealClassifier.HasThreeMonthCommitment(DealTier.BusinessSale));

    [Fact] // زبان کاورشده vs کاورنشده
    public void Language_coverage_is_correct()
    {
        Assert.True(LanguageCoverage.IsCovered("fa"));
        Assert.True(LanguageCoverage.IsCovered("tr"));
        Assert.False(LanguageCoverage.IsCovered("ru"));
        Assert.Equal(ContactMode.AiOnly, LanguageCoverage.ModeFor("zh"));
        Assert.Equal(ContactMode.ExpertOrAi, LanguageCoverage.ModeFor("ar"));
    }

    [Fact] // توافق فقط با تأیید مدیر + قرارداد فعال می‌شود
    public void Agreement_activates_only_with_manager_and_contract()
    {
        var a = new PartnerAgreement(Guid.NewGuid(), 7.5m, "5% each side");
        Assert.Equal(AgreementStatus.Draft, a.Status);
        Assert.Throws<ArgumentException>(() => a.Activate("", "C-1"));
        a.Activate("Manager", "CONTRACT-2026-01");
        Assert.True(a.ApprovedByManager);
        Assert.Equal(AgreementStatus.Active, a.Status);
    }

    [Fact] // پیشنهادِ لید: همکارِ هم‌زبان با نمرهٔ بالا اول می‌شود
    public void Recommender_prefers_language_and_performance()
    {
        var strong = new Partner("Sara", PartnerType.Expert, 92);
        strong.AddLanguage("ar"); strong.AddSkill("investment");
        var weak = new Partner("Ali", PartnerType.Salesperson, 55);
        weak.AddLanguage("en");

        var rec = new AssignmentRecommender();
        var lead = new LeadContext("ar", DealTier.InvestmentHigh, 95);
        var result = rec.Recommend(lead, [weak, strong]);

        Assert.Equal("Sara", result[0].PartnerName);
        Assert.True(result[0].MatchScore > result[1].MatchScore);
    }

    [Fact] // نمرهٔ همکار خارج از بازه رد می‌شود
    public void Partner_rejects_invalid_score() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new Partner("X", PartnerType.Agent, 130));
}
