using LeadPilot.Domain.Communications;
using LeadPilot.Application.Communications;
using Xunit;

namespace LeadPilot.Tests;

public class OutreachGateTests
{
    private static OutreachAttempt Make(ChannelConsentStatus consent, bool suppressed = false, bool onList = false) =>
        OutreachAttempt.Create(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(),
            CommunicationChannel.WhatsApp, OutreachMode.Manual, Guid.NewGuid(), "tmpl:1",
            consent, suppressed, onList);

    [Fact] // رضایتِ Granted → قابلِ ارسال
    public void Granted_is_sendable()
    {
        var a = Make(ChannelConsentStatus.Granted);
        Assert.True(a.IsSendable);
        Assert.Equal(OutreachResult.Pending, a.Result);
    }

    [Fact] // بدونِ رضایتِ Granted → مسدود (برای Audit ثبت می‌شود)
    public void Non_granted_is_blocked()
    {
        foreach (var s in new[]{ChannelConsentStatus.Unknown, ChannelConsentStatus.Invited,
                                 ChannelConsentStatus.Denied, ChannelConsentStatus.Withdrawn, ChannelConsentStatus.Expired})
        {
            var a = Make(s);
            Assert.False(a.IsSendable);
            Assert.Equal(OutreachResult.BlockedByGuard, a.Result);
        }
    }

    [Fact] // Suppressed/opt-out حتی با رضایت → مسدود
    public void Suppressed_is_blocked_even_if_granted()
    {
        var a = Make(ChannelConsentStatus.Granted, suppressed: true);
        Assert.False(a.IsSendable);
        Assert.Equal(OutreachResult.BlockedByGuard, a.Result);
    }

    [Fact] // opt-out list → مسدود
    public void On_suppression_list_blocked() =>
        Assert.False(Make(ChannelConsentStatus.Granted, onList: true).IsSendable);

    [Fact] // چرخهٔ ارسال: Sent → Delivered → Replied
    public void Send_lifecycle()
    {
        var a = Make(ChannelConsentStatus.Granted);
        a.MarkSent(); Assert.Equal(OutreachResult.Sent, a.Result);
        a.MarkDelivered(); Assert.Equal(OutreachResult.Delivered, a.Result);
        a.MarkReplied(); Assert.Equal(OutreachResult.Replied, a.Result);
    }
}

public class InstagramCommentAutomationTests
{
    private static InstagramCommentRule Rule(string kw, OutreachMode mode, bool enabled = true)
    {
        var r = new InstagramCommentRule(Guid.NewGuid(), "قیمت", kw, "reply:1", "dm:1", mode);
        if (enabled) r.Enable();
        return r;
    }

    [Fact] // کامنتِ منطبق در حالت خودکار → پاسخِ خودکار
    public void Match_auto()
    {
        var d = new InstagramCommentAutomationService().Evaluate([Rule("قیمت", OutreachMode.Automatic)], "قیمت چنده؟");
        Assert.True(d.Matched);
        Assert.Equal(OutreachMode.Automatic, d.Mode);
    }

    [Fact] // کامنتِ منطبق در حالت دستی → صفِ تأییدِ کارشناس
    public void Match_manual()
    {
        var d = new InstagramCommentAutomationService().Evaluate([Rule("قیمت", OutreachMode.Manual)], "قیمت؟");
        Assert.True(d.Matched);
        Assert.Equal(OutreachMode.Manual, d.Mode);
    }

    [Fact] // بدونِ تطبیق → هیچ اقدامی
    public void No_match()
    {
        var d = new InstagramCommentAutomationService().Evaluate([Rule("قیمت", OutreachMode.Automatic)], "سلام");
        Assert.False(d.Matched);
    }

    [Fact] // قاعدهٔ غیرفعال تطبیق نمی‌دهد
    public void Disabled_rule_no_match()
    {
        var d = new InstagramCommentAutomationService().Evaluate([Rule("قیمت", OutreachMode.Automatic, enabled: false)], "قیمت؟");
        Assert.False(d.Matched);
    }
}
