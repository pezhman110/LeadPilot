using LeadPilot.Domain.Signals;
using Xunit;

namespace LeadPilot.Tests;

public class SearchRunTests
{
    [Fact]
    public void New_run_is_running()
    {
        var r = new SearchRun(Guid.NewGuid());
        Assert.Equal(SearchRunStatus.Running, r.Status);
    }

    [Fact]
    public void Pause_then_resume()
    {
        var r = new SearchRun(Guid.NewGuid());
        r.Pause();
        Assert.Equal(SearchRunStatus.Paused, r.Status);
        r.Resume();
        Assert.Equal(SearchRunStatus.Running, r.Status);
    }

    [Fact]
    public void Cannot_resume_when_running()
    {
        var r = new SearchRun(Guid.NewGuid());
        Assert.Throws<InvalidOperationException>(() => r.Resume());
    }

    [Fact]
    public void Complete_sets_timestamp()
    {
        var r = new SearchRun(Guid.NewGuid());
        r.Complete();
        Assert.Equal(SearchRunStatus.Completed, r.Status);
        Assert.NotNull(r.CompletedAtUtc);
    }

    [Fact]
    public void Fail_records_error()
    {
        var r = new SearchRun(Guid.NewGuid());
        r.Fail("boom");
        Assert.Equal(SearchRunStatus.Failed, r.Status);
        Assert.Equal("boom", r.Error);
    }

    [Fact]
    public void Counters_increment()
    {
        var r = new SearchRun(Guid.NewGuid());
        r.CountQuery(); r.CountFound(); r.CountFound(); r.CountDuplicate(); r.CountBlocked(); r.CountProcessed();
        Assert.Equal(1, r.QueriesExecuted);
        Assert.Equal(2, r.RawSignalsFound);
        Assert.Equal(1, r.Duplicates);
        Assert.Equal(1, r.Blocked);
        Assert.Equal(1, r.Processed);
    }

    [Fact]
    public void Default_profile_has_six_languages_and_safe_sources()
    {
        var p = ProjectSearchProfile.DefaultDubaiInvestor(Guid.NewGuid());
        Assert.Equal(6, p.LanguageCodes.Count);
        Assert.Contains(LeadPilot.Domain.Common.SourceType.OptIn, p.AllowedSources);
        Assert.DoesNotContain(LeadPilot.Domain.Common.SourceType.Unknown, p.AllowedSources);
    }
}
